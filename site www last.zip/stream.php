<?php
declare(strict_types=1);

require_once __DIR__ . '/inc/media.php';

$trackId = (string)($_GET['id'] ?? '');
$track = site_find_track($trackId);
if (!$track) {
    http_response_code(404);
    exit('Track not found.');
}

$file = (string)($track['audio_file'] ?? '');
if ($file === '' || !is_file($file) || !is_readable($file)) {
    http_response_code(404);
    exit('Audio file missing.');
}

$size = filesize($file);

// Detection du MIME et de l'extension depuis le fichier reel
$ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
$mimeMap = [
    'mp3'  => 'audio/mpeg',
    'wav'  => 'audio/wav',
    'ogg'  => 'audio/ogg',
    'm4a'  => 'audio/mp4',
    'aac'  => 'audio/aac',
];
$mime = $mimeMap[$ext] ?? 'application/octet-stream';

$start = 0;
$end = $size - 1;
$status = 200;

if (!headers_sent()) {
    header('Content-Type: ' . $mime);
    header('Accept-Ranges: bytes');
    header('X-Content-Type-Options: nosniff');
    header('X-Robots-Tag: noindex, nofollow');
    header('Cache-Control: private, no-store, no-cache, must-revalidate, max-age=0');
    header('Pragma: no-cache');
    header('Expires: 0');
    $safeName = preg_replace('/[^a-z0-9_-]+/i', '-', $trackId);
    $safeName = $safeName !== null && $safeName !== '' ? trim($safeName, '-') : 'track';
    header('Content-Disposition: inline; filename="' . $safeName . '.' . ($ext ?: 'bin') . '"');
}

if (isset($_SERVER['HTTP_RANGE']) && preg_match('/bytes=(\d*)-(\d*)/', (string)$_SERVER['HTTP_RANGE'], $matches)) {
    if ($matches[1] !== '') {
        $start = (int)$matches[1];
    }
    if ($matches[2] !== '') {
        $end = (int)$matches[2];
    }
    if ($end >= $size) {
        $end = $size - 1;
    }
    if ($start > $end || $start < 0) {
        header('Content-Range: bytes */' . $size);
        http_response_code(416);
        exit;
    }
    $status = 206;
}

$length = $end - $start + 1;
http_response_code($status);
header('Content-Length: ' . (string)$length);
if ($status === 206) {
    header('Content-Range: bytes ' . $start . '-' . $end . '/' . $size);
}

@set_time_limit(0);
while (ob_get_level() > 0) { @ob_end_clean(); }

$handle = fopen($file, 'rb');
if ($handle === false) {
    http_response_code(500);
    exit('Unable to open file.');
}

fseek($handle, $start);
$remaining = $length;
while (!feof($handle) && $remaining > 0) {
    $chunk = fread($handle, min(8192, $remaining));
    if ($chunk === false) {
        break;
    }
    echo $chunk;
    @ob_flush();
    flush();
    $remaining -= strlen($chunk);
    // Stop si le client a fermé la connexion (économise CPU)
    if (connection_aborted()) break;
}
fclose($handle);
