Dossier /media_private/fragments/

Fichiers audio PRIVES pour le streaming des fragments via /stream.php.

Format recommande : MP3 de bonne qualite, exporte depuis le DAW choisi.
Nom attendu : {slug}.mp3

Exemple :
  /media_private/fragments/vague-du-matin.mp3

Ne pas promettre ici de fichier cache ou de livraison automatique.
