Dossier /media_private/ - fichiers audio non publics

Le navigateur ne doit jamais charger un fichier directement ici.
Les ecoutes passent uniquement par /stream.php?id={slug}.

Organisation :
  /media_private/fragments/{slug}.mp3
  /media_private/sessions/{slug}.mp3
  /media_private/wav/{slug}.wav
