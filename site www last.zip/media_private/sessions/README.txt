Dossier /media_private/sessions/

Fichiers audio PRIVES pour le streaming des sessions via /stream.php.

Format recommande : MP3 de bonne qualite, exporte depuis le DAW choisi.
Nom attendu : {slug}.mp3

Exemple :
  /media_private/sessions/session-longue.mp3

Ne pas promettre ici de fichier cache ou de livraison automatique.
