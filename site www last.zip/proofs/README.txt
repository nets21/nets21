Dossier /proofs/ots/ — preuves OpenTimestamps publiques

Convention simple du site :

- /proofs/ots/vague-du-matin.ots
- /proofs/ots/session-longue.ots

But :

- relier un morceau ou un master a une preuve de date technique
- rendre la preuve visible depuis le site sans l'alourdir

Rappel important :

- OpenTimestamps aide a montrer qu'un fichier existait deja avant une certaine date
- cela ne remplace pas a lui seul une preuve complete d'auteur, de contrat ou de droit

Les pieces audio restent organisees a part :

- fichiers audio prives : /media_private/
- ecoute publique : /stream.php?id={slug}
- preuve de date : /proofs/ots/
