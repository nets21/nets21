<?php
declare(strict_types=1);
require_once __DIR__ . '/inc/site.php';
require_once __DIR__ . '/inc/media.php';
$title = $site['brand_main'] . ' :: fragments';

$fragmentGroups = [];
foreach (($content['fragments'] ?? []) as $item) {
  $originType = (string)($item['origin_type'] ?? 'construction');
  $originLabel = trim((string)($item['origin_label'] ?? ''));

  if ($originType === 'bonus') {
    $groupKey = 'bonus';
    $groupTitle = 'Titres bonus';
  } elseif ($originType === 'cd') {
    $groupKey = 'cd:' . ($originLabel !== '' ? $originLabel : 'autres');
    $groupTitle = $originLabel !== '' ? $originLabel : 'Autres CD';
  } else {
    $groupKey = 'construction';
    $groupTitle = 'Morceaux';
  }

  if (!isset($fragmentGroups[$groupKey])) {
    $fragmentGroups[$groupKey] = ['title' => $groupTitle, 'items' => []];
  }
  $fragmentGroups[$groupKey]['items'][] = $item;
}

ob_start(); ?>

<div class="panel tone-red">
  <div class="portal-mini">
    <span class="portal-dot red">●</span><span>fragments</span>
    <span class="portal-sep">//</span>
    <span class="portal-dot blue">●</span><span>sessions</span>
    <span class="portal-sep">//</span>
    <span class="portal-name"><?= site_h($content['brand_poetic']) ?></span>
  </div>
  <h1>Écouter les fragments</h1><div class="prose"><?php site_paragraphs($content['fragments_intro_lines']); ?></div>

  <?php foreach ($fragmentGroups as $group): ?>
    <section class="track-group">
      <h2 class="track-group-title"><?= site_h($group['title']) ?></h2>
      <div class="list">
        <?php foreach ($group['items'] as $item): ?>
          <?php $full = site_find_track((string)$item['id']); ?>
          <?php $_ots = $full ? track_opentimestamps_url($full) : ''; ?>
          <?php $trackNote = trim((string)($full['track_note'] ?? $full['player_subtitle'] ?? $item['track_note'] ?? '')); ?>
          <?php $_abletonSession = $full ? track_ableton_session_url($full) : ''; ?>
          <?php $_abletonSessionLabel = $full ? (string)($full['ableton_session_label'] ?? 'Session Ableton avec ce morceau') : 'Session Ableton avec ce morceau'; ?>
          <div class="row">
            <img class="track-cover-thumb" src="<?= site_h(track_cover_url($full ?: $item)) ?>" alt="" loading="lazy">
            <div class="when"><?= site_h($item['year']) ?></div>
            <div class="what">
              <div class="title"><?= site_h($item['title']) ?></div>
              <div class="sub"><?= site_h($item['subtitle']) ?></div>
              <?php if ($trackNote !== ''): ?>
                <details class="track-note"><summary>À propos de ce morceau</summary><div style="white-space: pre-wrap; line-height: 1.7;"><?= site_h($trackNote) ?></div></details>
              <?php endif; ?>
              <?php if ($_abletonSession !== ''): ?>
                <div class="track-note">Session Ableton distincte : ce morceau y existe comme piste.</div>
              <?php endif; ?>
            </div>
            <div class="actions">
              <button type="button" class="btn small js-track" data-track-id="<?= site_h($item['id']) ?>">ecouter</button>
              <?php if ($_abletonSession !== ''): ?>
                <a class="session-link" href="<?= site_h($_abletonSession) ?>" download><?= site_h($_abletonSessionLabel) ?></a>
              <?php endif; ?>
              <?php if ($_ots !== ''): ?>
                <a class="proof-link" href="/preuves.php#<?= site_h($full['slug'] ?? $item['id']) ?>">[ preuve de date ]</a>
              <?php endif; ?>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    </section>
  <?php endforeach; ?>

  <div class="cta">
    <a class="btn" href="/listen.php">Ecoute & soutien</a>
    <a class="btn ghost" href="/sessions.php">Revenir au temps long</a>
  </div>
</div>

<?php $page_content = ob_get_clean(); include __DIR__ . '/inc/layout.php';
