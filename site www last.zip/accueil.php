<?php
declare(strict_types=1);
header('Location: /preferences.php', true, 302);
exit;
