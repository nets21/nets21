<?php
declare(strict_types=1);
require_once __DIR__ . '/inc/site.php';
require_once __DIR__ . '/inc/media.php';

$title = $site['brand_main'] . ' :: preuves de date';
$tracks = array_values(array_filter(array_map('nets_track_resolve', $content['discovery_tracks'] ?? []), 'track_has_opentimestamps'));
ob_start(); ?>

<div class="panel subtle">
  <div class="portal-mini">
    <span class="portal-dot blue">●</span><span>preuves</span>
    <span class="portal-sep">//</span>
    <span class="portal-dot red">●</span><span>source</span>
    <span class="portal-sep">//</span>
    <span class="portal-name"><?= site_h($content['brand_poetic']) ?></span>
  </div>
  <h1>Preuves de date</h1>
  <div class="prose">
    <p>Cette page rassemble les preuves OpenTimestamps rattachees a certaines pieces du site.</p>
    <p>Dans cet esprit, OpenTimestamps sert a montrer qu'un fichier existait deja avant une certaine date. Cela aide pour l'anteriorite technique.</p>
    <p>Ce n'est pas a lui seul un certificat absolu d'auteur, ni une decision de justice. C'est une couche de datation publique et verifiable.</p>
  </div>
</div>

<div class="panel">
  <h2>Pieces reliees a une preuve</h2>
  <?php if (!$tracks): ?>
    <p class="meta">Aucune preuve de date n'est encore reliee publiquement a un morceau.</p>
  <?php else: ?>
    <div class="list compact-list">
      <?php foreach ($tracks as $track): ?>
        <?php $_ots = track_opentimestamps_url($track); ?>
        <div class="row track-row tone-<?= ($track['kind'] ?? 'fragment') === 'session' ? 'blue' : 'red' ?>" id="<?= site_h($track['slug'] ?? $track['id']) ?>">
          <img class="track-cover-thumb" src="<?= site_h(track_cover_url($track)) ?>" alt="" loading="lazy">
          <div class="when">
            <span class="kind-dot <?= ($track['kind'] ?? 'fragment') === 'session' ? 'blue' : 'red' ?>">●</span>
            <?= site_h((string)($track['year'] ?? '—')) ?>
          </div>
          <div class="what">
            <div class="title"><?= site_h((string)($track['title'] ?? ($track['slug'] ?? 'morceau'))) ?></div>
            <div class="sub"><?= site_h((string)($track['subtitle'] ?? '')) ?></div>
            <?php if (!empty($track['ots_note'])): ?>
              <div class="sub"><?= site_h((string)$track['ots_note']) ?></div>
            <?php endif; ?>
          </div>
          <div class="actions">
            <button type="button" class="btn small js-track" data-track-id="<?= site_h((string)($track['id'] ?? '')) ?>">ecouter</button>
            <?php if ($_ots !== ''): ?>
              <a class="proof-link" href="<?= site_h($_ots) ?>" target="_blank" rel="noopener">[ fichier .ots ↗ ]</a>
            <?php endif; ?>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
</div>

<div class="panel subtle">
  <h2>Usage sobre</h2>
  <ul class="info-list">
    <li>preuve de date technique publiee depuis le site</li>
    <li>coherence avec les morceaux, sessions et envois plus proches de la source</li>
    <li>pas de promesse juridique excessive : juste une trace datable et verifiable</li>
  </ul>
</div>

<?php $page_content = ob_get_clean(); include __DIR__ . '/inc/layout.php';
