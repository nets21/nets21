<?php
declare(strict_types=1);
require_once __DIR__ . '/inc/site.php';
$title = 'Mon parcours musical';
ob_start(); ?>
<section class="panel bio-page"><h1><?= site_h($content['bio_title']) ?></h1><p class="lede"><?= site_h($content['bio_intro']) ?></p><div class="prose"><?php site_paragraphs($content['bio_lines']); ?></div></section>
<section class="panel subtle"><h2>Mastering à distance — projet</h2><div class="prose"><?php site_paragraphs($content['mastering_lines']); ?></div></section>
<div class="cta"><a class="btn" href="/fragments.php">Les fragments</a><a class="btn ghost" href="/sessions.php">Les sessions</a><a class="btn ghost" href="/about.php">À propos</a></div>
<?php $page_content = ob_get_clean(); include __DIR__ . '/inc/layout.php';
