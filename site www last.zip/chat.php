<?php
declare(strict_types=1);
require_once __DIR__ . '/inc/site.php';
require_once __DIR__ . '/inc/db.php';

require_once __DIR__ . '/inc/security.php';
site_session_start('NETSGBSESSID');
if (empty($_SESSION['guestbook_csrf'])) {
  $_SESSION['guestbook_csrf'] = bin2hex(random_bytes(16));
}

$labelOptions = guestbook_label_options();
$labelDescriptions = guestbook_label_descriptions();
$selectedLabel = guestbook_normalize_label((string)($_POST['label'] ?? 'presence'));
$statusMessage = null;
if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
  if (!hash_equals($_SESSION['guestbook_csrf'] ?? '', (string)($_POST['csrf'] ?? ''))) {
    http_response_code(400);
    exit('Bad request');
  }
  if (!empty($_POST['website'] ?? '')) {
    header('Location: /chat.php');
    exit;
  }
  $name = (string)($_POST['name'] ?? '');
  $email = (string)($_POST['email'] ?? '');
  $body = (string)($_POST['body'] ?? '');
  $posted = guestbook_post($name, $body, $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0', $selectedLabel, $email);
  $statusMessage = $posted
    ? 'Merci pour ces quelques mots. Votre message a bien été reçu. Il sera visible sur cette page après validation.'
    : 'Le message n’a pas pu être enregistré pour le moment. Vérifiez le contenu, l’email éventuel, ou attendez un peu avant de réessayer.';
}

$entries = guestbook_public_entries();
$title = $site['brand_main'] . ' :: presences';
ob_start(); ?>
<div class="panel">
  <h1>Présences</h1>
  <p class="lede"><?= site_h($content['guestbook_intro']) ?></p>
  <p class="meta"><?= site_h($content['guestbook_callout']) ?></p>
</div>

<div class="split single-mobile">
  <div class="panel subtle">
    <h2>Laisser une présence</h2>
    <?php if ($statusMessage): ?>
      <div class="notice"><?= site_h($statusMessage) ?></div>
    <?php endif; ?>
    <form method="post" class="guestbook-form" autocomplete="off" data-ajax-main="1">
      <input type="hidden" name="csrf" value="<?= site_h($_SESSION['guestbook_csrf']) ?>" />
      <input type="text" name="website" class="hp" tabindex="-1" autocomplete="off" aria-hidden="true" />
      <label>
        <span class="label">Nom ou pseudo</span>
        <input type="text" name="name" maxlength="40" required />
      </label>
      <label>
        <span class="label">Email privé, facultatif</span>
        <input type="email" name="email" maxlength="160" autocomplete="email" />
        <span class="field-help">Non publié. Sert à une réponse privée et accompagne la notification envoyée à la boîte du site.</span>
      </label>
      <label>
        <span class="label">Boîte à lettres</span>
        <select name="label" required>
          <?php foreach ($labelOptions as $labelKey => $labelText): ?>
            <option value="<?= site_h($labelKey) ?>"<?= $selectedLabel === $labelKey ? ' selected' : '' ?>><?= site_h($labelText) ?></option>
          <?php endforeach; ?>
        </select>
        <span class="field-help"><?= site_h($labelDescriptions[$selectedLabel] ?? $labelDescriptions['presence']) ?></span>
      </label>
      <label>
        <span class="label">Message</span>
        <textarea name="body" rows="6" maxlength="1200" required></textarea>
      </label>
      <button type="submit" class="btn-form">envoyer</button>
    </form>
  </div>

  <div class="panel subtle"><h2>Échanger · 7J</h2><p>Pour échanger directement, rejoignez le salon. Chaque message y apparaît dès son envoi et reste visible pendant sept jours.</p><a class="btn" href="/salon.php">Entrer dans le salon</a></div>
</div>

<div class="panel">
  <h2>Présences publiées</h2>
  <?php if (!$entries): ?>
    <p class="meta">Aucune présence publiée pour le moment.</p>
  <?php else: ?>
    <div class="guestbook-entries">
      <?php foreach ($entries as $entry): ?>
        <article class="entry">
          <div class="entry-head">
            <strong><?= site_h($entry['name']) ?></strong>
            <?php $entryLabel = guestbook_entry_label($entry); ?>
            <span class="entry-head-side">
              <span class="label-chip label-<?= site_h($entryLabel) ?>"><?= site_h(guestbook_label_text($entryLabel)) ?></span>
              <span class="meta"><?= date('Y-m-d H:i', (int)$entry['approved_at']) ?></span>
            </span>
          </div>
          <p><?= nl2br(site_h($entry['body'])) ?></p>
          <?php if (!empty($entry['reply_body'])): ?>
            <div class="entry-reply">
              <div class="meta">Réponse du site</div>
              <p><?= nl2br(site_h((string)$entry['reply_body'])) ?></p>
            </div>
          <?php endif; ?>
        </article>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
</div>
<?php $page_content = ob_get_clean(); include __DIR__ . '/inc/layout.php';
