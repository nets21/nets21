<?php
declare(strict_types=1);

require_once __DIR__ . '/inc/site.php';
require_once __DIR__ . '/inc/security.php';
require_once __DIR__ . '/inc/week_chat.php';
require_once __DIR__ . '/inc/chat_translation.php';

site_session_start('NETSWEEKCHAT');
if (empty($_SESSION['week_chat_csrf'])) {
  $_SESSION['week_chat_csrf'] = bin2hex(random_bytes(24));
}

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
  if (!hash_equals((string)($_SESSION['week_chat_csrf'] ?? ''), (string)($_POST['csrf'] ?? ''))) {
    http_response_code(400);
    exit('Bad request');
  }

  if (!empty($_POST['website'] ?? '')) {
    header('Location: /salon.php');
    exit;
  }

  $posted = week_chat_post((string)($_POST['name'] ?? ''), (string)($_POST['body'] ?? ''));
  if ($posted) {
    $_SESSION['week_chat_csrf'] = bin2hex(random_bytes(24));
    $_SESSION['week_chat_flash'] = 'Votre message est publié. Il restera visible pendant sept jours.';
  } else {
    $_SESSION['week_chat_flash'] = 'Envoi refusé : attendez un peu avant de réessayer. Le message peut être vide, déjà envoyé, ou le salon peut être plein.';
  }
  header('Location: /salon.php#salon-messages');
  exit;
}

$flash = (string)($_SESSION['week_chat_flash'] ?? '');
unset($_SESSION['week_chat_flash']);
$messages = week_chat_messages();
$title = $site['brand_main'] . ' :: salon sept jours';
ob_start(); ?>

<section class="panel week-chat-intro">
  <div class="library-eyebrow"><span class="library-live-dot" aria-hidden="true"></span>salon ephemere</div>
  <h1><?= site_h((string)$content['chat_beta_title']) ?></h1>
  <div class="prose">
    <?php foreach (($content['chat_beta_lines'] ?? []) as $line): ?>
      <p><?= site_h((string)$line) ?></p>
    <?php endforeach; ?>
  </div>
  <div class="week-chat-rules">
    <span>pseudo seulement</span>
    <span>pas d adresse e-mail</span>
    <span>pas d IP conservee dans le salon</span>
    <span>expiration : 7 jours</span>
  </div>
</section>



<div class="week-chat-layout">
  <section class="panel subtle week-chat-compose">
    <div class="kicker">Ecrire</div>
    <h2>Ajouter un message</h2>
    <?php if ($flash !== ''): ?><div class="notice"><?= site_h($flash) ?></div><?php endif; ?>
    <form method="post" action="/salon.php" autocomplete="off" class="week-chat-form">
      <input type="hidden" name="csrf" value="<?= site_h((string)$_SESSION['week_chat_csrf']) ?>">
      <input type="text" name="website" class="hp" tabindex="-1" autocomplete="off" aria-hidden="true">
      <label>
        <span class="label">Nom ou pseudo</span>
        <input type="text" name="name" maxlength="36" required>
      </label>
      <label>
        <span class="label">Message</span>
        <textarea name="body" rows="6" maxlength="600" required></textarea>
        <span class="field-help">600 caracteres maximum. Le texte ne sera plus affiche apres sept jours. Lorsque la traduction est active, le texte public peut être transmis à Microsoft Translator ; le site ne transmet pas votre pseudo avec lui.</span>
      </label>
      <button type="submit" class="btn-form">envoyer dans le salon</button>
    </form>
  </section>

  <section class="panel week-chat-thread" id="salon-messages" aria-label="Messages du salon" data-week-chat>
    <div data-chat-translation data-csrf="<?= site_h((string)$_SESSION['week_chat_csrf']) ?>" data-enabled="<?= chat_translation_ready() ? '1' : '0' ?>">
      <label><span class="label">Langue de lecture</span>
        <select data-chat-language aria-label="Langue de lecture"<?= chat_translation_ready() ? '' : ' disabled' ?>>
          <option value="">Textes originaux</option>
          <?php foreach (chat_translation_languages() as $code => $label): ?>
            <option value="<?= site_h($code) ?>"><?= site_h($label) ?></option>
          <?php endforeach; ?>
        </select>
      </label>
      <p class="meta" data-chat-translation-status aria-live="polite"><?= chat_translation_ready() ? 'Traduction automatique ; l’original reste accessible. Une traduction peut se tromper.' : 'La traduction automatique est en préparation. Les messages restent dans leur langue originale.' ?></p>
    </div>
    <div class="week-chat-thread-head">
      <div>
        <div class="kicker">Maintenant</div>
        <h2><?= count($messages) ?> message<?= count($messages) === 1 ? '' : 's' ?></h2>
      </div>
      <a class="btn ghost small" href="/salon.php#salon-messages">actualiser</a>
    </div>
    <div class="week-chat-bot" role="note">
      <span class="week-chat-bot-light" aria-hidden="true"></span>
      <div><strong>robot anti-cassure actif</strong><span>Il masque les gros mots sans bannir automatiquement la personne.</span></div>
    </div>
    <div class="week-chat-muted-summary" data-week-chat-muted-summary hidden aria-live="polite">
      <span data-week-chat-muted-count></span>
      <button type="button" class="btn ghost small" data-week-chat-unmute-all>tout reafficher</button>
    </div>
    <?php if ($messages === []): ?>
      <div class="week-chat-empty">
        <strong>Le salon est calme.</strong>
        <span>Le premier message peut simplement dire quel son est reste.</span>
      </div>
    <?php else: ?>
      <div class="week-chat-messages">
        <?php foreach ($messages as $message): ?>
          <?php $authorKey = week_chat_author_key((string)$message['name']); ?>
          <?php $isModerated = !empty($message['moderated']); ?>
          <article class="week-chat-message<?= $isModerated ? ' is-moderated' : '' ?>" data-week-chat-message data-chat-id="<?= (int)$message['id'] ?>" data-chat-moderated="<?= $isModerated ? '1' : '0' ?>" data-author-key="<?= site_h($authorKey) ?>">
            <header>
              <strong data-week-chat-author><?= site_h((string)$message['name']) ?></strong>
              <time datetime="<?= date('c', (int)$message['created_at']) ?>"><?= date('d/m H:i', (int)$message['created_at']) ?></time>
            </header>
            <p data-chat-body dir="auto"><?= site_h((string)$message['body']) ?></p>
            <?php if ($isModerated): ?>
              <div class="week-chat-warning">
                <strong>Robot anti-cassure</strong>
                <span>Cet utilisateur ne vous dit pas de bonnes choses. Si vous voulez, vous pouvez ne plus voir ce qu'il ecrit.</span>
                <button type="button" class="week-chat-mute" data-week-chat-mute="<?= site_h($authorKey) ?>">ne plus voir ce pseudo</button>
              </div>
            <?php endif; ?>
            <footer><?= site_h(week_chat_remaining_label((int)($message['expires_at'] ?? ((int)$message['created_at'] + NETS_WEEK_CHAT_RETENTION_SECONDS)))) ?></footer>
          </article>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </section>
</div>

<section class="panel subtle week-chat-footnote">
  <p><strong>Ce salon est different des Presences.</strong> Ici, le message est public immediatement et ephemere. Le robot anti-cassure masque les mots grossiers ; chaque visiteur peut ensuite cacher ce pseudo seulement sur son propre appareil.</p>
  <a class="btn ghost" href="/chat.php">Aller aux Presences</a>
</section>

<section class="panel subtle week-chat-footnote">
  <div class="kicker">Direction future</div>
  <h2><?= site_h((string)$content['chat_future_title']) ?></h2>
  <div class="prose">
    <?php foreach (($content['chat_future_lines'] ?? []) as $line): ?>
      <p><?= site_h((string)$line) ?></p>
    <?php endforeach; ?>
  </div>
</section>
<?php $page_content = ob_get_clean(); include __DIR__ . '/inc/layout.php';
