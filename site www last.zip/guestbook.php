<?php
declare(strict_types=1);

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
  require __DIR__ . '/chat.php';
  exit;
}

header('Location: /chat.php', true, 301);
exit;
