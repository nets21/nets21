<?php
declare(strict_types=1);
require_once __DIR__ . '/inc/site.php';
$title = $site['brand_main'] . ' :: entree';
?>
<!doctype html>
<html lang="fr">
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1"/>
<title><?= site_h($title) ?></title>
<meta name="description" content="<?= site_h($site['meta_description']) ?>"/>
<meta name="robots" content="noindex,nofollow,noarchive,noimageindex"/>
<meta name="theme-color" content="#040909"/>
<link rel="stylesheet" href="/assets/apercu-sas.css"/>
<link rel="icon" href="/assets/favicon.svg" type="image/svg+xml"/>
</head>
<body>
  <main class="sas-stage sas-jewel-stage">
    <section class="sas-choice" aria-label="Choisir une entree d'ecoute">
      <div class="sas-heading">
        <span class="sas-brand">NETS-MUSIQUE.DIGITAL</span>
        <span class="sas-origin">deux accords d'entree</span>
      </div>

      <div class="sas-gems" aria-label="Choix rouge ou bleu">
        <a class="sas-gem sas-gem-blue" href="/sessions.php">
          <span class="gem-core" aria-hidden="true">
            <svg class="gem-harp" viewBox="0 0 180 180" focusable="false">
              <path class="harp-body" d="M42 150 C50 76 75 26 134 22 C108 46 98 86 100 150"/>
              <path class="harp-base" d="M34 150 H122"/>
              <path class="harp-neck" d="M66 42 C90 28 112 27 134 22"/>
              <path class="harp-string" d="M70 48 L58 148"/>
              <path class="harp-string" d="M84 42 L72 148"/>
              <path class="harp-string" d="M98 37 L86 148"/>
              <path class="harp-string" d="M112 31 L100 148"/>
              <path class="harp-string" d="M126 25 L114 148"/>
            </svg>
          </span>
          <span class="gem-label">BLEU</span>
          <span class="gem-title">sessions</span>
        </a>
        <a class="sas-gem sas-gem-red" href="/fragments.php">
          <span class="gem-core" aria-hidden="true">
            <svg class="gem-harp" viewBox="0 0 180 180" focusable="false">
              <path class="harp-body" d="M42 150 C50 76 75 26 134 22 C108 46 98 86 100 150"/>
              <path class="harp-base" d="M34 150 H122"/>
              <path class="harp-neck" d="M66 42 C90 28 112 27 134 22"/>
              <path class="harp-string" d="M70 48 L58 148"/>
              <path class="harp-string" d="M84 42 L72 148"/>
              <path class="harp-string" d="M98 37 L86 148"/>
              <path class="harp-string" d="M112 31 L100 148"/>
              <path class="harp-string" d="M126 25 L114 148"/>
            </svg>
          </span>
          <span class="gem-label">ROUGE</span>
          <span class="gem-title">fragments</span>
        </a>
      </div>

      <p class="sas-subtitle">Un choix simple : bleu pour les sessions, rouge pour les fragments.</p>
    </section>
  </main>
</body>
</html>