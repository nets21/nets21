<?php
declare(strict_types=1);

function site_visits_initial_store(): array {
  return [
    'total' => 0,
    'days' => [],
    'pages' => [],
    'last_at' => 0,
  ];
}

function site_visits_normalize_store(mixed $data): array {
  if (!is_array($data)) {
    return site_visits_initial_store();
  }

  $days = [];
  foreach ((array)($data['days'] ?? []) as $day => $count) {
    if (is_string($day) && preg_match('~^\d{4}-\d{2}-\d{2}$~', $day)) {
      $days[$day] = max(0, (int)$count);
    }
  }

  $pages = [];
  foreach ((array)($data['pages'] ?? []) as $path => $count) {
    if (is_string($path) && str_starts_with($path, '/')) {
      $pages[$path] = max(0, (int)$count);
    }
  }

  return [
    'total' => max(0, (int)($data['total'] ?? 0)),
    'days' => $days,
    'pages' => $pages,
    'last_at' => max(0, (int)($data['last_at'] ?? 0)),
  ];
}

function site_visits_storage_path(): string {
  $dir = __DIR__ . '/../data';
  if (!is_dir($dir)) {
    @mkdir($dir, 0755, true);
  }

  $path = $dir . '/visits.json';
  if (!is_file($path)) {
    $json = json_encode(site_visits_initial_store(), JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
    if ($json !== false) {
      @file_put_contents($path, $json . PHP_EOL, LOCK_EX);
    }
  }

  return $path;
}

function site_visits_record(string $requestPath): void {
  static $recorded = false;
  if ($recorded) {
    return;
  }
  $recorded = true;

  if (strtoupper((string)($_SERVER['REQUEST_METHOD'] ?? 'GET')) !== 'GET') {
    return;
  }

  $userAgent = (string)($_SERVER['HTTP_USER_AGENT'] ?? '');
  if ($userAgent !== '' && preg_match('~bot|crawler|spider|slurp|bingpreview|facebookexternalhit|curl|wget~i', $userAgent)) {
    return;
  }

  $path = parse_url($requestPath, PHP_URL_PATH);
  $path = is_string($path) && $path !== '' ? $path : '/';
  if (preg_match('~^/(?:admin|atelier|coulisses|membre|member)(?:[/.]|$)~i', $path)) {
    return;
  }

  $handle = @fopen(site_visits_storage_path(), 'c+');
  if ($handle === false) {
    return;
  }

  try {
    if (!flock($handle, LOCK_EX)) {
      return;
    }

    rewind($handle);
    $raw = stream_get_contents($handle);
    $store = site_visits_normalize_store(json_decode((string)$raw, true));
    $day = date('Y-m-d');

    $store['total']++;
    $store['days'][$day] = (int)($store['days'][$day] ?? 0) + 1;
    $store['pages'][$path] = (int)($store['pages'][$path] ?? 0) + 1;
    $store['last_at'] = time();

    $json = json_encode($store, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
    if ($json !== false) {
      rewind($handle);
      ftruncate($handle, 0);
      fwrite($handle, $json . PHP_EOL);
      fflush($handle);
    }
  } finally {
    @flock($handle, LOCK_UN);
    fclose($handle);
  }
}

function site_visits_stats(): array {
  $store = site_visits_initial_store();
  $handle = @fopen(site_visits_storage_path(), 'rb');

  if ($handle !== false) {
    try {
      if (flock($handle, LOCK_SH)) {
        rewind($handle);
        $store = site_visits_normalize_store(json_decode((string)stream_get_contents($handle), true));
      }
    } finally {
      @flock($handle, LOCK_UN);
      fclose($handle);
    }
  }

  $today = date('Y-m-d');
  $from = date('Y-m-d', strtotime('-6 days'));
  $lastSevenDays = 0;
  foreach ($store['days'] as $day => $count) {
    if ($day >= $from && $day <= $today) {
      $lastSevenDays += (int)$count;
    }
  }

  $pages = $store['pages'];
  arsort($pages, SORT_NUMERIC);
  $topPage = array_key_first($pages);

  return [
    'total' => (int)$store['total'],
    'today' => (int)($store['days'][$today] ?? 0),
    'last_7_days' => $lastSevenDays,
    'pages' => $pages,
    'top_page' => is_string($topPage) ? $topPage : '',
    'top_page_count' => is_string($topPage) ? (int)$pages[$topPage] : 0,
    'last_at' => (int)$store['last_at'],
  ];
}