<?php
declare(strict_types=1);

/*
 * Overrides éditables depuis l'atelier.
 *
 * Deux fichiers JSON, dans /data/ :
 *   - content-overrides.json  : textes du site (titres, paragraphes, listes)
 *   - tracks-overrides.json   : liste des morceaux (fragments + sessions)
 *
 * Tant que les fichiers n'existent pas ou sont vides, le site utilise
 * les valeurs par défaut de inc/content.php. Rien ne casse.
 */

if (!function_exists('content_overrides_dir')) {
  function content_overrides_dir(): string {
    $candidates = [__DIR__ . '/../data'];

    if (DIRECTORY_SEPARATOR === '\\') {
      $userProfile = getenv('USERPROFILE') ?: (string)($_SERVER['USERPROFILE'] ?? '');
      if ($userProfile !== '') {
        $candidates[] = rtrim($userProfile, "\\/") . '\\Documents\\nets-musique-overrides';
      }
    }

    $tmp = rtrim(sys_get_temp_dir(), "\\/");
    if ($tmp !== '') {
      $candidates[] = $tmp . DIRECTORY_SEPARATOR . 'nets-musique-overrides';
    }

    foreach ($candidates as $dir) {
      if (!is_dir($dir)) {
        @mkdir($dir, 0775, true);
      }
      if (is_dir($dir) && is_writable($dir)) {
        return $dir;
      }
    }

    return __DIR__ . '/../data';
  }
}

if (!function_exists('content_overrides_base_dir')) {
  function content_overrides_base_dir(): string {
    return __DIR__ . '/../data';
  }
}

if (!function_exists('content_overrides_path')) {
  function content_overrides_path(): string {
    return content_overrides_dir() . '/content-overrides.json';
  }
}

if (!function_exists('tracks_overrides_path')) {
  function tracks_overrides_path(): string {
    return content_overrides_dir() . '/tracks-overrides.json';
  }
}

if (!function_exists('content_read_overrides')) {
  function content_read_overrides(): array {
    $paths = array_unique([
      content_overrides_path(),
      content_overrides_base_dir() . '/content-overrides.json',
    ]);
    foreach ($paths as $f) {
      if (!is_file($f)) continue;
      $raw = @file_get_contents($f);
      if (!$raw) continue;
      $data = json_decode($raw, true);
      if (is_array($data)) return $data;
    }
    return [];
  }
}

if (!function_exists('content_write_overrides')) {
  function content_write_overrides(array $data): bool {
    $f = content_overrides_path();
    $tmp = $f . '.tmp.' . bin2hex(random_bytes(4));
    $json = json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
    if ($json === false) return false;
    if (file_put_contents($tmp, $json, LOCK_EX) === false) return false;
    return rename($tmp, $f);
  }
}

if (!function_exists('tracks_read_overrides')) {
  function tracks_read_overrides(): array {
    $paths = array_unique([
      tracks_overrides_path(),
      content_overrides_base_dir() . '/tracks-overrides.json',
    ]);
    foreach ($paths as $f) {
      if (!is_file($f)) continue;
      $raw = @file_get_contents($f);
      if (!$raw) continue;
      $data = json_decode($raw, true);
      if (is_array($data)) return $data;
    }
    return [];
  }
}

if (!function_exists('tracks_write_overrides')) {
  function tracks_write_overrides(array $data): bool {
    $f = tracks_overrides_path();
    $tmp = $f . '.tmp.' . bin2hex(random_bytes(4));
    $json = json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
    if ($json === false) return false;
    if (file_put_contents($tmp, $json, LOCK_EX) === false) return false;
    return rename($tmp, $f);
  }
}

/**
 * Applique les overrides au tableau $content.
 * - Pour les textes simples ou tableaux (listes) : clé → valeur override
 * - Pour les morceaux : si des tracks-overrides.json existent, ils remplacent discovery_tracks
 */
if (!function_exists('content_apply_overrides')) {
  function content_apply_overrides(array $content): array {
    $overrides = content_read_overrides();
    foreach ($overrides as $key => $value) {
      // on n'écrase que si la clé existe déjà (sécurité) ET si la valeur est non-vide
      if (array_key_exists($key, $content) && $value !== null) {
        $content[$key] = $value;
      }
    }
    $tracks = tracks_read_overrides();
    if (!empty($tracks) && is_array($tracks)) {
      // on conserve les audio_file par défaut des pistes de même id
      $defaults_by_id = [];
      foreach (($content['discovery_tracks'] ?? []) as $t) {
        if (!empty($t['id'])) $defaults_by_id[$t['id']] = $t;
      }
      $library = [];
      foreach ($tracks as $t) {
        if (empty($t['id'])) continue;
        $base = $defaults_by_id[$t['id']] ?? [];
        $record = array_merge($base, $t);
        if (!array_key_exists('active', $record)) {
          $record['active'] = true;
        }
        if (!array_key_exists('locked', $record)) {
          $record['locked'] = true;
        }
        $library[] = $record;
      }
      $content['track_library'] = $library;
      $content['discovery_tracks'] = array_values(array_filter(
        $library,
        static fn(array $track): bool => !empty($track['active'])
      ));
    } else {
      $content['track_library'] = $content['discovery_tracks'] ?? [];
      $content['discovery_tracks'] = array_values(array_filter(
        $content['track_library'],
        static fn(array $track): bool => !array_key_exists('active', $track) || !empty($track['active'])
      ));
    }

    foreach (['track_library', 'discovery_tracks'] as $collectionKey) {
      foreach (($content[$collectionKey] ?? []) as $index => $track) {
        if (($track['id'] ?? '') === 'fragment_001') {
          $content[$collectionKey][$index]['track_note'] = (string)($content['first_track_note'] ?? '');
        }
      }
    }

    // Les pages fragments/sessions suivent le même ordre que l'atelier.
    if (isset($content['track_library']) && is_array($content['discovery_tracks'] ?? null)) {
      $content['fragments'] = [];
      $content['sessions'] = [];
      foreach ($content['discovery_tracks'] as $track) {
        if (empty($track['id'])) continue;
        $item = [
          'id' => (string)$track['id'],
          'year' => (string)($track['year'] ?? ''),
          'title' => (string)($track['title'] ?? ''),
          'subtitle' => (string)($track['subtitle'] ?? ''),
          'session_mode' => (string)($track['session_mode'] ?? 'hybrid'),
          'origin_type' => (string)($track['origin_type'] ?? 'construction'),
          'origin_label' => (string)($track['origin_label'] ?? ''),
          'cover' => (string)($track['cover'] ?? ''),
          'support_url' => (string)($track['support_url'] ?? ''),
          'player_subtitle' => (string)($track['player_subtitle'] ?? ''),
          'track_note' => (string)($track['track_note'] ?? ''),
        ];
        if (($track['kind'] ?? 'fragment') === 'session') {
          $content['sessions'][] = $item;
        } else {
          $content['fragments'][] = $item;
        }
      }
    }
    return $content;
  }
}
