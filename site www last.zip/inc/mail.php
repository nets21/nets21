<?php
declare(strict_types=1);

require_once __DIR__ . '/site.php';

function site_mail_header_text(string $value, int $limit = 120): string {
  $value = trim((string)preg_replace('~[\r\n]+~', ' ', $value));
  if (function_exists('mb_substr')) {
    return (string)mb_substr($value, 0, $limit);
  }
  return substr($value, 0, $limit);
}

function site_guestbook_mailbox_address(string $labelKey): ?string {
  global $site;

  $labelKey = strtolower(trim($labelKey));
  $labelKey = (string)preg_replace('~[^a-z0-9_-]~', '', $labelKey);
  $mailboxes = is_array($site['guestbook_mailboxes'] ?? null)
    ? $site['guestbook_mailboxes']
    : [];
  $candidate = (string)($mailboxes[$labelKey] ?? $site['contact_email'] ?? '');
  $email = filter_var($candidate, FILTER_VALIDATE_EMAIL);
  if (is_string($email) && $email !== '') {
    return $email;
  }

  $fallback = filter_var((string)($site['contact_email'] ?? ''), FILTER_VALIDATE_EMAIL);
  return is_string($fallback) && $fallback !== '' ? $fallback : null;
}

function site_guestbook_mail_payload(array $entry): ?array {
  global $site;

  $name = site_mail_header_text((string)($entry['name'] ?? 'visiteur'), 40);
  if ($name === '') {
    $name = 'visiteur';
  }

  $labelKey = strtolower(trim((string)($entry['label'] ?? 'presence')));
  $labelKey = (string)preg_replace('~[^a-z0-9_-]~', '', $labelKey);
  if ($labelKey === '') {
    $labelKey = 'presence';
  }
  $label = '@' . $labelKey;

  $to = site_guestbook_mailbox_address($labelKey);
  if ($to === null) {
    return null;
  }
  $from = filter_var((string)($site['contact_email'] ?? ''), FILTER_VALIDATE_EMAIL);
  if (!is_string($from) || $from === '') {
    $from = $to;
  }

  $replyTo = filter_var((string)($entry['email'] ?? ''), FILTER_VALIDATE_EMAIL);
  if (!is_string($replyTo) || $replyTo === '') {
    $replyTo = $from;
  }

  $subjectText = '[nets-musique][' . $label . '] Nouveau message de ' . $name;
  $subject = function_exists('mb_encode_mimeheader')
    ? mb_encode_mimeheader($subjectText, 'UTF-8', 'B', "\r\n")
    : $subjectText;

  $createdAt = max(0, (int)($entry['created_at'] ?? 0));
  $date = $createdAt > 0 ? date('d/m/Y H:i', $createdAt) : date('d/m/Y H:i');
  $privateEmail = filter_var((string)($entry['email'] ?? ''), FILTER_VALIDATE_EMAIL);
  $privateEmailLine = is_string($privateEmail) && $privateEmail !== '' ? $privateEmail : 'non indique';

  $body = implode("\r\n", [
    'Nouveau message depuis nets-musique.digital',
    '',
    'Boite a lettres : ' . $label,
    'Nom ou pseudo : ' . $name,
    'Email prive : ' . $privateEmailLine,
    'Date : ' . $date,
    '',
    'Message :',
    trim((string)($entry['body'] ?? '')),
    '',
    'Coulisses : https://nets-musique.digital/coulisses-presences.php',
  ]);

  $headers = implode("\r\n", [
    'From: nets-musique.digital <' . $from . '>',
    'Reply-To: ' . $replyTo,
    'MIME-Version: 1.0',
    'Content-Type: text/plain; charset=UTF-8',
    'Content-Transfer-Encoding: 8bit',
    'Auto-Submitted: auto-generated',
    'X-Auto-Response-Suppress: All',
    'X-Nets-Mailbox: ' . $labelKey,
  ]);

  return [
    'to' => $to,
    'subject' => $subject,
    'body' => $body,
    'headers' => $headers,
  ];
}

function site_send_guestbook_notification(array $entry): bool {
  if (!function_exists('mail')) {
    return false;
  }

  $payload = site_guestbook_mail_payload($entry);
  if ($payload === null) {
    return false;
  }

  try {
    return @mail($payload['to'], $payload['subject'], $payload['body'], $payload['headers']);
  } catch (Throwable) {
    return false;
  }
}
