<?php
declare(strict_types=1);

require_once __DIR__ . '/security.php';
site_send_security_headers();
require_once __DIR__ . '/content.php';
require_once __DIR__ . '/content_overrides.php';
// Les valeurs éditées depuis l'atelier remplacent celles de content.php
$content = content_apply_overrides($content);

$site = [
  'brand_main' => 'nets-musique.digital',
  'brand_secondary' => 'born-a-gain',
  'artist_name' => 'netS - Spraycan',
  'artist_credit' => 'netS',
  'artist_roles' => 'composition, guitare, percussions, piano, production, mastering, écrêtage',
  'artist_statement' => 'Projet musical indépendant porté de bout en bout : écriture, jeu, guitare, percussions, piano, mise en son, mastering, écrêtage et présence en ligne.',
  'site_title_default' => 'bibliotheque temporaire // netS // born-a-gain',
  'meta_description' => 'Musiques originales de netS, écoute libre, albums, session longue et salon éphémère : un lieu d’échange malgré la distance.',
  'logo_text' => 'NETS-MUSIQUE.DIGITAL :: BIBLIOTHEQUE TEMPORAIRE',
  'ascii_title' => <<<'ASCII'
 _   _ _______ _____   _____      __  __ _   _  ____ ___  ____  _   _ _____
| \ | | ____\ \ / / | |  __ \    |  \/  | | | |/ ___/ _ \|  _ \| \ | |_   _|
|  \| |  _|  \ V /| | | |__) |   | |\/| | | | | |  | | | | |_) |  \| | | |
| |\  | |___  | | | | |  _  /    | |  | | |_| | |__| |_| |  _ <| |\  | | |
|_| \_|_____| |_| |_| |_| \_\    |_|  |_|\___/ \____\___/|_| \_\_| \_| |_|

         nets-musique.digital  //  born-a-gain  //  écoute persistante
ASCII,
  'hero_title' => 'Musiques originales, sessions et fragments portés par l’écoute.',
  'hero_lede' => 'Un premier morceau en avant, six autres autour, un lecteur qui reste en place, puis un contact par e-mail pour prolonger l’écoute.',
  'about_intro' => 'nets est un nom transmis. born-a-gain est l’élan brut. Le site réunit les deux dans un cadre plus lisible : une présence d’artiste simple, mais tenue, centrée sur la musique elle-même.',
  'about_body' => 'La musique circule entre électronique, jeu instrumental, captation longue, mastering, écrêtage et finition sonore. Le projet reste artisanal dans le bon sens du terme : écrit, joué, produit et mis en ligne avec exigence, sans lourdeur inutile.',
  'contact_email' => 'aurelien@nets-musique.digital',
  'guestbook_mailboxes' => [
    'presence' => 'presence@nets-musique.digital',
    'ecoute' => 'ecoute@nets-musique.digital',
    'question' => 'question@nets-musique.digital',
    'idee' => 'idee@nets-musique.digital',
    'constructif' => 'constructif@nets-musique.digital',
    'contact' => 'contact@nets-musique.digital',
  ],
  'support_title' => 'Soutien, contact, écoutes directes',
  'support_text' => 'Le soutien accompagne un projet musical indépendant porté seul : composition, instruments, électronique, mastering, écrêtage, fabrication sonore et mise en ligne. Il peut aussi ouvrir des échanges plus directs autour des morceaux et des envois ciblés, sans promesse automatique de téléchargement.',
  'buymeacoffee_url' => 'https://Ko-fi.com/nets192_red_and_yellow',
  'support_image' => '/assets/buy-me-a-coffee-electro.png',
  'professional_notice' => 'Projet indépendant porté, composé, joué, produit, masterisé, écrêté et mis en ligne par netS.',
  'session_price' => 'soutien libre',
  'fragment_price' => 'soutien libre',
  'session_duration' => '~1h',
  'fragment_duration' => 'environ 5 min',
'admin_user' => 'atelier',
'admin_password_hash' => '$2y$12$ueKOf74L9UWK6tZQoRW/w.WYIacxNBKIac71LhorC4mqQyBimH.R6',
  'admin_login_path' => '/coulisses.php',
  'admin_home_path' => '/coulisses-espace.php',
  'admin_guestbook_path' => '/coulisses-presences.php',
  'admin_tracks_path' => '/coulisses-sons.php',
  'admin_texts_path' => '/coulisses-textes.php',
  'admin_notes_path' => '/coulisses-notes.php',
  'admin_members_path' => '/coulisses-membres.php',
  'admin_cubes_path' => '/coulisses-cubes.php',
  'member_path' => '/membre.php',
  'member_logout_path' => '/membre-sortie.php',
  'admin_logout_path' => '/coulisses-sortie.php',
  'footer_text' => 'Musique, écoute libre et lieu d’échange malgré la distance — du plus loin au plus près, sans être proche.',
];

$site['meta_description'] = 'Musiques originales de netS, écoute libre, albums, session longue et salon éphémère : un lieu d’échange malgré la distance.';
$site['footer_text'] = 'Musique, écoute libre et lieu d’échange malgré la distance — du plus loin au plus près, sans être proche.';

if (!function_exists('site_h')) {
  function site_h(?string $value): string {
    return htmlspecialchars((string)$value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
  }
}

if (!function_exists('site_path')) {
  function site_path(string $key, string $fallback = '/'): string {
    global $site;
    $value = $site[$key] ?? $fallback;
    return is_string($value) && $value !== '' ? $value : $fallback;
  }
}

if (!function_exists('site_social_links')) {
  /**
   * @return array<int, array{label:string,url:string}>
   */
  function site_social_links(): array {
    global $content;
    $links = [];
    foreach ((array)($content['social_links'] ?? []) as $line) {
      $line = trim((string)$line);
      if ($line === '') {
        continue;
      }
      $parts = array_map('trim', explode('|', $line, 2));
      if (count($parts) !== 2 || $parts[0] === '' || $parts[1] === '') {
        continue;
      }
      if (!preg_match('~^https?://~i', $parts[1])) {
        continue;
      }
      $links[] = ['label' => $parts[0], 'url' => $parts[1]];
    }
    return $links;
  }
}

if (!function_exists('site_default_track_cover_url')) {
  function site_default_track_cover_url(): string {
    return '/assets/covers/default.svg';
  }
}

if (!function_exists('site_track_cover_url')) {
  function site_track_cover_url(array $track): string {
    $cover = trim((string)($track['cover'] ?? ''));
    if ($cover !== '' && preg_match('~^/assets/covers/[a-zA-Z0-9._/-]+\.(?:avif|gif|jpe?g|png|svg|webp)$~i', $cover)) {
      return $cover;
    }

    $originLabel = trim((string)($track['origin_label'] ?? ''));
    if ($originLabel !== '' && preg_match('~^la\s+paix\s+de\s+netsa(?:h)?$~iu', $originLabel)) {
      return '/assets/covers/la-paix-de-netsa.webp';
    }

    return site_default_track_cover_url();
  }
}

if (!function_exists('site_playlist')) {
  /**
   * @return array<int, array<string,string>>
   */
  function site_playlist(): array {
    global $content;
    return array_values(array_map(static function (array $track): array {
      // Normalise les paroles écrites pour le front
      $words = [];
      foreach ((array)($track['spoken_words'] ?? []) as $w) {
        if (!is_array($w)) continue;
        $tc = (float)($w['t'] ?? 0);   // timecode en secondes
        $du = (float)($w['d'] ?? 6);   // durée d'apparition en secondes (défaut 6)
        $tx = trim((string)($w['text'] ?? ''));
        if ($tx === '') continue;
        $words[] = ['t' => $tc, 'd' => $du, 'text' => $tx];
      }
      // Tri chronologique
      usort($words, static fn($a, $b) => $a['t'] <=> $b['t']);
      $supportUrl = trim((string)($track['support_url'] ?? ''));
      if ($supportUrl === '' || !preg_match('~^https?://~i', $supportUrl)) {
        $supportUrl = (string)($GLOBALS['site']['buymeacoffee_url'] ?? '');
      }
      return [
        'id' => (string)($track['id'] ?? ''),
        'title' => (string)($track['title'] ?? ''),
        'subtitle' => (string)($track['subtitle'] ?? ''),
        'track_note' => (string)($track['track_note'] ?? ''),
        'player_subtitle' => (string)($track['player_subtitle'] ?? ''),
        'playback_gain_db' => (float)($track['playback_gain_db'] ?? 0.0),
        'audio' => '/stream.php?id=' . rawurlencode((string)($track['id'] ?? '')),
        'kind' => (string)($track['kind'] ?? ''),
        'session_mode' => (string)($track['session_mode'] ?? 'hybrid'),
        'cover' => site_track_cover_url($track),
        'support_url' => $supportUrl,
        'words' => $words,
      ];
    }, $content['discovery_tracks'] ?? []));
  }
}

function site_paragraphs(array $lines): void { foreach ($lines as $line) { echo "<p>" . nl2br(site_h((string)$line)) . "</p>"; } }
