<?php
declare(strict_types=1);
require_once __DIR__ . '/site.php';
require_once __DIR__ . '/visits.php';
site_visits_record((string)($_SERVER['REQUEST_URI'] ?? '/'));
$playlistJson = json_encode(site_playlist(), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
$currentPath = strtok($_SERVER['REQUEST_URI'] ?? '/', '?') ?: '/';
$hidePlayer = !empty($hide_player);
$socialLinks = site_social_links();
$presenceSignalState = trim((string)($content['presence_signal_state'] ?? ''));
$presenceSignalLabel = trim((string)($content['presence_signal_label'] ?? 'dans la toile'));
$presenceSignalNote = trim((string)($content['presence_signal_note'] ?? ''));
$defaultCoverUrl = site_default_track_cover_url();
$appVersion = @filemtime(__DIR__ . '/../assets/app.js') ?: 1;
?>
<!doctype html>
<html lang="fr">
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1"/>
<title><?= site_h($title ?? $site['site_title_default']) ?></title>
<meta name="description" content="<?= site_h($site['meta_description']) ?>"/>
<meta name="author" content="<?= site_h($site['artist_name']) ?>"/>
<meta name="robots" content="noindex,nofollow,noarchive,noimageindex"/>
<meta name="theme-color" content="#071522"/>
<link rel="stylesheet" href="/assets/style.css"/>
<link rel="icon" href="/assets/favicon.svg" type="image/svg+xml"/>
<meta property="og:site_name" content="<?= site_h($site['brand_main']) ?>"/>
<meta property="og:title" content="<?= site_h($site['site_title_default']) ?>"/>
<meta property="og:description" content="<?= site_h($site['meta_description']) ?>"/>
<meta property="og:type" content="website"/>
<meta property="og:locale" content="fr_FR"/>
<meta name="twitter:card" content="summary"/>
<link rel="stylesheet" href="/assets/chat-translation.css?v=1">
</head>
<body<?= $hidePlayer ? ' class="no-player"' : '' ?>>
<div class="wrapper site-shell">
  <header class="header">
    <div>
      <div class="logo"><?= site_h($site['logo_text']) ?></div>
      <div class="meta brand-subline"><?= site_h($site['artist_credit']) ?> · <?= site_h($site['artist_roles']) ?></div>
    </div>
    <nav class="menu" aria-label="Navigation principale">
      <a href="/bibliotheque.php">Écouter</a><a href="/salon.php">Échanger · 7J</a><a href="/about.php">Le projet</a><a href="/listen.php">Écoute & soutien</a>
    </nav>
  </header>

  <?php if ($presenceSignalState !== ''): ?>
    <section class="presence-signal" aria-label="Signal de présence">
      <span class="presence-signal-dot" aria-hidden="true"></span>
      <span class="presence-signal-main"><?= site_h($presenceSignalLabel) ?> : <?= site_h($presenceSignalState) ?></span>
      <?php if ($presenceSignalNote !== ''): ?>
        <span class="presence-signal-note"><?= site_h($presenceSignalNote) ?></span>
      <?php endif; ?>
    </section>
  <?php endif; ?>

  <main id="site-main">
    <?= $page_content ?? '' ?>
  </main>

  <?php if (!$hidePlayer): ?>
    <section class="panel player-dock" id="player-dock" aria-label="Lecteur global">
      <div class="player-topline">Lecteur global</div>
      <div class="player-grid">
        <img class="player-cover" id="player-cover" src="<?= site_h($defaultCoverUrl) ?>" data-default-cover="<?= site_h($defaultCoverUrl) ?>" alt="Jaquette neutre du site"/>
        <div class="player-details">
          <div id="player-kind" class="player-kind">écoute</div>
          <div id="player-title" class="player-title">Sélectionne un morceau</div>
          <div id="player-subtitle" class="player-subtitle">Ecouter, c'est parfois jouer avec nous.</div>
          <img class="player-vibration" src="/assets/listening-ricochet.svg" alt="" aria-hidden="true" loading="lazy">
          <a class="player-support" id="player-support" href="<?= site_h($site['buymeacoffee_url']) ?>" target="_blank" rel="noopener">M’offrir un café</a>
        </div>
        <div class="player-controls">
          <button type="button" class="player-btn main" id="player-toggle">lecture</button>
          <button type="button" class="player-btn" id="player-prev" aria-label="Morceau précédent">←</button>
          <button type="button" class="player-btn" id="player-next" aria-label="Morceau suivant">→</button>
          <!-- Vu-mètre "escaliers" : large et chaud en bas, se rétrécit vers le haut -->
          <div class="player-vu" id="player-vu" aria-hidden="true" title="vu-mètre">
            <span class="vu-bar" data-level="1"></span>
            <span class="vu-bar" data-level="2"></span>
            <span class="vu-bar" data-level="3"></span>
            <span class="vu-bar" data-level="4"></span>
            <span class="vu-bar" data-level="5"></span>
            <span class="vu-bar" data-level="6"></span>
            <span class="vu-bar" data-level="7"></span>
            <span class="vu-bar" data-level="8"></span>
            <span class="vu-bar" data-level="9"></span>
            <span class="vu-bar" data-level="10"></span>
            <span class="vu-bar" data-level="11"></span>
            <span class="vu-bar" data-level="12"></span>
          </div>
        </div>
      </div>
      <!-- Zone des paroles écrites : apparaît quand un mot est actif, sinon vide -->
      <details id="player-info" hidden><summary>À propos de ce morceau</summary><div id="player-info-text" style="white-space: pre-wrap; line-height: 1.7; margin: 1rem 0;"></div></details>
      <div class="player-words" id="player-words" aria-live="polite"></div>
      <div class="player-progress-wrap">
        <div class="player-progress" aria-hidden="true">
          <span id="player-progress-bar"></span>
          <!-- Marqueurs subtils des paroles écrites — injectés par JS -->
          <div class="player-word-marks" id="player-word-marks" aria-hidden="true"></div>
        </div>
        <div class="player-time"><span id="player-time-current">00:00</span><span id="player-time-total">00:00</span></div>
      </div>
      <audio id="global-player" preload="metadata"></audio>
    </section>
  <?php endif; ?>

  <?php if ($socialLinks !== []): ?>
    <section class="panel subtle social-panel" aria-label="Réseaux choisis">
      <h2>Réseaux choisis</h2>
      <p class="meta"><?= site_h((string)($content['social_intro'] ?? '')) ?></p>
      <div class="cta social-links">
        <?php foreach ($socialLinks as $link): ?>
          <a class="btn ghost" href="<?= site_h($link['url']) ?>" target="_blank" rel="nofollow noopener noreferrer"><?= site_h($link['label']) ?></a>
        <?php endforeach; ?>
      </div>
    </section>
  <?php endif; ?>

  <footer class="panel" role="contentinfo">
    <div class="meta">© <?= date('Y') ?> <?= site_h($site['brand_main']) ?> — <?= site_h($site['footer_text']) ?></div>
    <div class="meta footer-links"><a href="/confidentialite.php">Confidentialité sobre</a></div>
  </footer>
</div>
<?php if (!$hidePlayer): ?>
  <script id="site-playlist-data" type="application/json"><?= $playlistJson ?: '[]' ?></script>
  <script src="/assets/app.js?v=<?= (int)$appVersion ?>"></script>
<?php endif; ?>
<script src="/assets/chat-translation.js?v=1"></script>
</body>
</html>
