<?php
declare(strict_types=1);

require_once __DIR__ . '/site.php';

/**
 * Build a filesystem-safe slug from a title or id.
 */
function nets_slugify(string $s): string {
    $s = trim($s);
    $s = @iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $s);
    $s = strtolower((string)$s);
    $s = preg_replace('/[^a-z0-9_\-]+/', '-', $s) ?? '';
    return trim($s, '-_');
}

function nets_project_root(): string {
    return dirname(__DIR__);
}

function nets_project_file(string $relativePath): string {
    $relativePath = str_replace('\\', '/', trim($relativePath));
    if ($relativePath === ''
        || str_starts_with($relativePath, '/')
        || str_contains($relativePath, '..')
        || !preg_match('~^[a-zA-Z0-9._/-]+$~', $relativePath)) {
        return '';
    }

    return nets_project_root() . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $relativePath);
}

function nets_project_relative_file(string $path): string {
    $realPath = realpath($path);
    if ($realPath !== false) {
        $path = $realPath;
    }
    $root = rtrim(str_replace('\\', '/', nets_project_root()), '/') . '/';
    $normalized = str_replace('\\', '/', $path);
    if (!str_starts_with(strtolower($normalized), strtolower($root))) {
        return '';
    }

    $relative = substr($normalized, strlen($root));
    return nets_project_file($relative) !== '' ? $relative : '';
}

function nets_track_is_active(array $track): bool {
    return !array_key_exists('active', $track) || (bool)$track['active'];
}

function nets_ini_bytes(string $value): int {
    $value = trim($value);
    if ($value === '') {
        return 0;
    }

    $unit = strtolower(substr($value, -1));
    $number = (float)$value;
    if ($unit === 'g') {
        $number *= 1024;
    }
    if ($unit === 'g' || $unit === 'm') {
        $number *= 1024;
    }
    if ($unit === 'g' || $unit === 'm' || $unit === 'k') {
        $number *= 1024;
    }
    return (int)$number;
}

function nets_upload_limit_bytes(): int {
    $limits = array_filter([
        nets_ini_bytes((string)ini_get('upload_max_filesize')),
        nets_ini_bytes((string)ini_get('post_max_size')),
        256 * 1024 * 1024,
    ], static fn(int $value): bool => $value > 0);

    return $limits === [] ? 0 : min($limits);
}

function nets_format_bytes(int $bytes): string {
    if ($bytes >= 1024 * 1024 * 1024) {
        return rtrim(rtrim(number_format($bytes / (1024 * 1024 * 1024), 1, '.', ''), '0'), '.') . ' Go';
    }
    if ($bytes >= 1024 * 1024) {
        return rtrim(rtrim(number_format($bytes / (1024 * 1024), 1, '.', ''), '0'), '.') . ' Mo';
    }
    return max(1, (int)ceil($bytes / 1024)) . ' Ko';
}

function nets_text_limit(string $value, int $length): string {
    return function_exists('mb_substr')
        ? mb_substr($value, 0, $length, 'UTF-8')
        : substr($value, 0, $length);
}

function nets_approximate_duration(float $seconds, string $kind): string {
    if ($seconds <= 0) {
        return $kind === 'session' ? 'environ 1 h' : 'environ 5 min';
    }

    $minutes = max(1, (int)round($seconds / 60));
    if ($minutes < 60) {
        return 'environ ' . $minutes . ' min';
    }

    $hours = intdiv($minutes, 60);
    $remaining = $minutes % 60;
    return 'environ ' . $hours . ' h' . ($remaining > 0 ? ' ' . $remaining . ' min' : '');
}

function nets_mp3_signature_matches(string $path): bool {
    $handle = @fopen($path, 'rb');
    if ($handle === false) {
        return false;
    }
    $header = (string)fread($handle, 16);
    fclose($handle);

    return str_starts_with($header, 'ID3')
        || (strlen($header) >= 2 && ord($header[0]) === 0xff && (ord($header[1]) & 0xe0) === 0xe0);
}

/**
 * @return array{ok:bool,error:string,track?:array,path?:string}
 */
function nets_library_import(array $upload, array $input, array $existingTracks): array {
    $errorCode = (int)($upload['error'] ?? UPLOAD_ERR_NO_FILE);
    $uploadErrors = [
        UPLOAD_ERR_INI_SIZE => 'Le fichier depasse la limite autorisee par le serveur.',
        UPLOAD_ERR_FORM_SIZE => 'Le fichier depasse la limite autorisee.',
        UPLOAD_ERR_PARTIAL => 'Le transfert du fichier audio est incomplet.',
        UPLOAD_ERR_NO_FILE => 'Choisis un fichier audio a importer.',
        UPLOAD_ERR_NO_TMP_DIR => 'Le dossier temporaire du serveur est indisponible.',
        UPLOAD_ERR_CANT_WRITE => 'Le serveur ne peut pas ecrire le fichier audio.',
        UPLOAD_ERR_EXTENSION => 'Le serveur a interrompu le transfert.',
    ];
    if ($errorCode !== UPLOAD_ERR_OK) {
        return ['ok' => false, 'error' => $uploadErrors[$errorCode] ?? 'Echec du transfert audio.'];
    }

    $tmpPath = (string)($upload['tmp_name'] ?? '');
    $size = (int)($upload['size'] ?? 0);
    $originalName = basename(str_replace('\\', '/', (string)($upload['name'] ?? '')));
    $extension = strtolower(pathinfo($originalName, PATHINFO_EXTENSION));
    $limit = nets_upload_limit_bytes();

    if ($tmpPath === '' || !is_uploaded_file($tmpPath)) {
        return ['ok' => false, 'error' => 'Le fichier recu n est pas un envoi HTTP valide.'];
    }
    if ($size <= 0) {
        return ['ok' => false, 'error' => 'Le fichier audio est vide.'];
    }
    if ($limit > 0 && $size > $limit) {
        return ['ok' => false, 'error' => 'Le fichier depasse la limite de ' . nets_format_bytes($limit) . '.'];
    }
    if ($extension !== 'mp3' || !nets_mp3_signature_matches($tmpPath)) {
        return ['ok' => false, 'error' => 'Format refuse. La bibliotheque accepte uniquement un vrai fichier MP3.'];
    }

    if (!class_exists('finfo')) {
        return ['ok' => false, 'error' => 'Le controle de securite Fileinfo n est pas disponible sur le serveur.'];
    }
    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mime = (string)$finfo->file($tmpPath);
    if ($mime === '' || preg_match('~(?:php|html|script|javascript|executable)~i', $mime)) {
        return ['ok' => false, 'error' => 'Le contenu du fichier audio est refuse.'];
    }

    $kind = (($input['kind'] ?? 'fragment') === 'session') ? 'session' : 'fragment';
    $title = trim((string)($input['title'] ?? ''));
    if ($title === '') {
        $title = $kind === 'session' ? 'Session' : 'Morceau';
    }
    $title = preg_replace('/\s+/', ' ', $title) ?? '';
    $title = nets_text_limit($title !== '' ? $title : 'son importe', 160);

    $libraryId = bin2hex(random_bytes(16));
    $slugBase = nets_slugify($title);
    if ($slugBase === '') {
        $slugBase = $kind . '-audio';
    }
    $usedIds = [];
    foreach ($existingTracks as $track) {
        foreach (['id', 'slug'] as $field) {
            $value = strtolower((string)($track[$field] ?? ''));
            if ($value !== '') {
                $usedIds[$value] = true;
            }
        }
    }
    $slug = $slugBase;
    if (isset($usedIds[strtolower($slug)])) {
        $slug .= '-' . substr($libraryId, 0, 8);
    }

    $relativePath = 'data/audio-library-' . $libraryId . '.' . $extension;
    $destination = nets_project_file($relativePath);
    if ($destination === '' || file_exists($destination)) {
        return ['ok' => false, 'error' => 'Impossible de reserver un emplacement securise pour ce son.'];
    }
    if (!is_writable(dirname($destination))) {
        return ['ok' => false, 'error' => 'Le dossier prive /data doit etre accessible en ecriture par PHP.'];
    }
    if (!move_uploaded_file($tmpPath, $destination)) {
        return ['ok' => false, 'error' => 'Le serveur n a pas pu placer le son dans la bibliotheque privee.'];
    }
    @chmod($destination, 0444);

    $duration = (float)($input['duration_seconds'] ?? 0);
    $track = [
        'library_id' => $libraryId,
        'id' => $slug,
        'slug' => $slug,
        'kind' => $kind,
        'session_mode' => 'hybrid',
        'year' => date('Y'),
        'title' => $title,
        'subtitle' => nets_approximate_duration($duration, $kind),
        'origin_type' => 'construction',
        'origin_label' => '',
        'cover' => '',
        'support_url' => '',
        'active' => false,
        'locked' => true,
        'audio_rel' => $relativePath,
        'audio_extension' => $extension,
        'original_name' => nets_text_limit($originalName, 240),
        'file_size' => $size,
        'mime' => $mime,
        'source_sha256' => hash_file('sha256', $destination),
        'imported_at' => gmdate('c'),
    ];

    return ['ok' => true, 'error' => '', 'track' => $track, 'path' => $destination];
}

function nets_library_remove_failed_import(string $path): void {
    if ($path === '' || !is_file($path)) {
        return;
    }
    @chmod($path, 0644);
    @unlink($path);
}

/**
 * Keep old uploads working when only the filename casing changed.
 */
function nets_existing_file_case_insensitive(string $expectedPath): string {
    if (is_file($expectedPath)) {
        return $expectedPath;
    }

    $directory = dirname($expectedPath);
    if (!is_dir($directory)) {
        return $expectedPath;
    }

    $expectedName = basename($expectedPath);
    $entries = scandir($directory);
    if ($entries === false) {
        return $expectedPath;
    }

    foreach ($entries as $entry) {
        if (strcasecmp($entry, $expectedName) !== 0) {
            continue;
        }

        $candidate = $directory . DIRECTORY_SEPARATOR . $entry;
        if (is_file($candidate)) {
            return $candidate;
        }
    }

    return $expectedPath;
}

function nets_web_path_for_file(string $expectedWebPath, string $resolvedFile): string {
    if (!is_file($resolvedFile)) {
        return $expectedWebPath;
    }

    return rtrim(str_replace('\\', '/', dirname($expectedWebPath)), '/')
        . '/'
        . rawurlencode(basename($resolvedFile));
}

/**
 * Derive the media paths for a track slug.
 *
 * Current convention:
 * - stream mp3   : /media_private/{fragments|sessions}/{slug}.mp3 (not public)
 * - source wav   : /media_private/wav/{slug}.wav (optional, not public)
 * - Ableton session with this piece as a track:
 *   /downloads/ableton/sessions/{slug}.zip (optional, public when present)
 * - OTS proof   : /proofs/ots/{slug}.ots
 *
 * @return array{
 *   audio_file:string,
 *   audio_wav:string,
 *   ableton_session_file:string,
 *   proof_ots:string,
 *   web_stream:string,
 *   web_wav:string,
 *   web_ableton_session:string,
 *   web_ots:string
 * }
 */
function nets_track_paths(string $slug, string $kind = 'fragment'): array {
    $slug = nets_slugify($slug);
    $folder = ($kind === 'session') ? 'sessions' : 'fragments';
    $webStream = '/media_private/' . $folder . '/' . $slug . '.mp3';
    $webWav = '/media_private/wav/' . $slug . '.wav';
    $webAbletonSession = '/downloads/ableton/sessions/' . $slug . '.zip';
    $webOts = '/proofs/ots/' . $slug . '.ots';
    $root = __DIR__ . '/..';
    $audioFile = nets_existing_file_case_insensitive($root . $webStream);
    $audioWav = nets_existing_file_case_insensitive($root . $webWav);
    $abletonSessionFile = nets_existing_file_case_insensitive($root . $webAbletonSession);
    $proofOts = nets_existing_file_case_insensitive($root . $webOts);

    return [
        'audio_file' => $audioFile,
        'audio_wav' => $audioWav,
        'ableton_session_file' => $abletonSessionFile,
        'proof_ots' => $proofOts,
        'web_stream' => nets_web_path_for_file($webStream, $audioFile),
        'web_wav' => nets_web_path_for_file($webWav, $audioWav),
        'web_ableton_session' => nets_web_path_for_file($webAbletonSession, $abletonSessionFile),
        'web_ots' => nets_web_path_for_file($webOts, $proofOts),
    ];
}

/**
 * Fill a track with derived media paths from its slug.
 * Explicit track paths still win for soft migration.
 */
function nets_track_resolve(array $track): array {
    $slug = (string)($track['slug'] ?? $track['id'] ?? '');
    if ($slug === '') {
        return $track;
    }

    $kind = (string)($track['kind'] ?? 'fragment');
    $paths = nets_track_paths($slug, $kind);
    $relativeAudio = trim((string)($track['audio_rel'] ?? ''));
    $relativeAudioFile = $relativeAudio !== '' ? nets_project_file($relativeAudio) : '';

    if ($relativeAudioFile !== '' && is_file($relativeAudioFile)) {
        $track['audio_file'] = $relativeAudioFile;
    } elseif (empty($track['audio_file'])) {
        $track['audio_file'] = $paths['audio_file'];
    } else {
        $track['audio_file'] = nets_existing_file_case_insensitive((string)$track['audio_file']);
        if (!is_file((string)$track['audio_file']) && is_file($paths['audio_file'])) {
            $track['audio_file'] = $paths['audio_file'];
        }
    }
    if (!isset($track['audio_wav'])) {
        $track['audio_wav'] = $paths['audio_wav'];
    } else {
        $track['audio_wav'] = nets_existing_file_case_insensitive((string)$track['audio_wav']);
    }
    if (!isset($track['ableton_session_file'])) {
        $track['ableton_session_file'] = $paths['ableton_session_file'];
    } else {
        $track['ableton_session_file'] = nets_existing_file_case_insensitive((string)$track['ableton_session_file']);
    }
    if (empty($track['ableton_session_url']) && is_file($paths['ableton_session_file'])) {
        $track['ableton_session_url'] = $paths['web_ableton_session'];
    }
    if (!isset($track['ableton_session_label'])) {
        $track['ableton_session_label'] = 'Session Ableton avec ce morceau';
    }
    if (!isset($track['ots_file'])) {
        $track['ots_file'] = $paths['proof_ots'];
    } else {
        $track['ots_file'] = nets_existing_file_case_insensitive((string)$track['ots_file']);
    }
    if (empty($track['ots_url']) && is_file($paths['proof_ots'])) {
        $track['ots_url'] = $paths['web_ots'];
    }
    if (!isset($track['ots_note'])) {
        $track['ots_note'] = '';
    }

    $track['slug'] = nets_slugify($slug);
    return $track;
}

function track_opentimestamps_url(array $track): string {
    $track = nets_track_resolve($track);
    $url = trim((string)($track['ots_url'] ?? ''));
    if ($url === '') {
        return '';
    }
    if (preg_match('~^(https?://|/)~i', $url)) {
        return $url;
    }
    return '';
}

function track_has_opentimestamps(array $track): bool {
    return track_opentimestamps_url($track) !== '';
}

function track_ableton_session_url(array $track): string {
    $track = nets_track_resolve($track);
    $url = trim((string)($track['ableton_session_url'] ?? ''));
    if ($url === '') {
        return '';
    }
    if (preg_match('~^(https?://|/)~i', $url)) {
        return $url;
    }
    return '';
}

function track_has_ableton_session(array $track): bool {
    return track_ableton_session_url($track) !== '';
}

function track_cover_url(array $track): string {
    return site_track_cover_url($track);
}

/**
 * @return array<string,mixed>|null
 */
function site_find_track(string $trackId): ?array {
    global $content;
    foreach (($content['discovery_tracks'] ?? []) as $track) {
        if ((string)($track['id'] ?? '') === $trackId
            || (string)($track['slug'] ?? '') === $trackId) {
            return nets_track_resolve($track);
        }
    }
    return null;
}
