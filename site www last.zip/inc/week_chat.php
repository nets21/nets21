<?php
declare(strict_types=1);

require_once __DIR__ . '/rate_limit.php';

const NETS_WEEK_CHAT_RETENTION_SECONDS = 7 * 24 * 60 * 60;
const NETS_WEEK_CHAT_MAX_MESSAGES = 250;
// Autorise une courte conversation, puis freine les envois excessifs.
const NETS_WEEK_CHAT_CLIENT_LIMIT = 6;
const NETS_WEEK_CHAT_CLIENT_WINDOW = 30;

function week_chat_storage_path(): string {
  $directory = __DIR__ . '/../data';
  if (!is_dir($directory)) {
    @mkdir($directory, 0755, true);
  }
  return $directory . '/week-chat.json';
}

function week_chat_empty_store(): array {
  return ['next_id' => 1, 'messages' => []];
}

function week_chat_text_limit(string $text, int $limit): string {
  if (function_exists('mb_strlen') && function_exists('mb_substr')) {
    return mb_strlen($text) > $limit ? (string)mb_substr($text, 0, $limit) : $text;
  }
  return strlen($text) > $limit ? substr($text, 0, $limit) : $text;
}

/**
 * Lit, purge et reecrit le salon sous un verrou unique.
 * Les messages expires disparaissent physiquement du JSON au premier acces
 * suivant leur echeance.
 */
function week_chat_transaction(?callable $mutator = null): array {
  $path = week_chat_storage_path();
  $handle = @fopen($path, 'c+');
  if ($handle === false) {
    return week_chat_empty_store();
  }

  if (!flock($handle, LOCK_EX)) {
    fclose($handle);
    return week_chat_empty_store();
  }

  rewind($handle);
  $raw = stream_get_contents($handle);
  $store = json_decode((string)$raw, true);
  if (!is_array($store) || !is_array($store['messages'] ?? null)) {
    $store = week_chat_empty_store();
  }

  $now = time();
  $cutoff = $now - NETS_WEEK_CHAT_RETENTION_SECONDS;
  $store['messages'] = array_values(array_filter(
    $store['messages'],
    static fn($message): bool => is_array($message) && (int)($message['created_at'] ?? 0) > $cutoff
  ));

  $maxId = 0;
  foreach ($store['messages'] as $message) {
    $maxId = max($maxId, (int)($message['id'] ?? 0));
  }
  $store['next_id'] = max((int)($store['next_id'] ?? 1), $maxId + 1, 1);

  if ($mutator !== null) {
    $mutator($store);
  }

  $json = json_encode($store, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
  if ($json !== false) {
    rewind($handle);
    ftruncate($handle, 0);
    fwrite($handle, $json . PHP_EOL);
    fflush($handle);
  }

  flock($handle, LOCK_UN);
  fclose($handle);
  return $store;
}

function week_chat_messages(): array {
  $store = week_chat_transaction();
  return array_values($store['messages'] ?? []);
}

function week_chat_moderation_patterns(): array {
  return [
    '~\b(?:putains?|merdes?|con(?:ne)?s?|connards?|connasses?|salopes?|putes?|encul(?:e|\x{00E9})s?|niqu(?:e|\x{00E9})s?|fdp|ntm|b(?:a|\x{00E2})tards?)\b~iu',
    '~\b(?:ta\s+gueule|ferme\s+ta\s+gueule|va\s+te\s+faire\s+foutre)\b~iu',
  ];
}

function week_chat_moderate_body(string $body): array {
  $moderated = false;
  foreach (week_chat_moderation_patterns() as $pattern) {
    $body = (string)preg_replace_callback(
      $pattern,
      static function () use (&$moderated): string {
        $moderated = true;
        return '[mot masque]';
      },
      $body
    );
  }
  return ['body' => $body, 'moderated' => $moderated];
}

function week_chat_author_key(string $name): string {
  $normalized = trim(preg_replace('/\s+/u', ' ', $name) ?? '');
  $normalized = function_exists('mb_strtolower') ? mb_strtolower($normalized, 'UTF-8') : strtolower($normalized);
  return hash('sha256', $normalized);
}

function week_chat_post(string $name, string $body): bool {
  $name = trim(preg_replace('/\s+/u', ' ', $name) ?? '');
  $body = trim($body);
  if ($name === '' || $body === '') {
    return false;
  }

  $name = week_chat_text_limit(strip_tags($name), 36);
  $body = week_chat_text_limit(strip_tags($body), 600);
  if ($name === '' || $body === '') {
    return false;
  }

  $moderation = week_chat_moderate_body($body);
  $body = (string)$moderation['body'];
  $moderated = !empty($moderation['moderated']);

  if (!site_rate_limit_allow('week-chat', NETS_WEEK_CHAT_CLIENT_LIMIT, NETS_WEEK_CHAT_CLIENT_WINDOW, 30, 60)) {
    return false;
  }

  $posted = false;
  week_chat_transaction(static function (array &$store) use ($name, $body, $moderated, &$posted): void {
    $now = time();
    // Un salon plein refuse les ajouts sans effacer les messages encore valides.
    if (count($store['messages']) >= NETS_WEEK_CHAT_MAX_MESSAGES) {
      return;
    }
    $recent = array_slice($store['messages'], -12);
    foreach ($recent as $message) {
      if ((string)($message['name'] ?? '') === $name
          && (string)($message['body'] ?? '') === $body
          && $now - (int)($message['created_at'] ?? 0) < 300) {
        return;
      }
    }

    $store['messages'][] = [
      'id' => (int)$store['next_id'],
      'name' => $name,
      'body' => $body,
      'moderated' => $moderated,
      'created_at' => $now,
      'expires_at' => $now + NETS_WEEK_CHAT_RETENTION_SECONDS,
    ];
    $store['next_id']++;
    $posted = true;
  });
  return $posted;
}

function week_chat_remaining_label(int $expiresAt): string {
  $remaining = max(0, $expiresAt - time());
  $days = intdiv($remaining, 86400);
  if ($days >= 1) {
    return 's efface dans ' . $days . ($days === 1 ? ' jour' : ' jours');
  }
  $hours = max(1, intdiv($remaining, 3600));
  return 's efface dans ' . $hours . ($hours === 1 ? ' heure' : ' heures');
}
