<?php
declare(strict_types=1);

if (!function_exists('atelier_notes_dir')) {
  function atelier_notes_dir(): string {
    $candidates = [__DIR__ . '/../data'];

    if (DIRECTORY_SEPARATOR === '\\') {
      $userProfile = getenv('USERPROFILE') ?: (string)($_SERVER['USERPROFILE'] ?? '');
      if ($userProfile !== '') {
        $candidates[] = rtrim($userProfile, "\\/") . '\\Documents\\nets-musique-notes';
      }
    }

    $tmp = rtrim(sys_get_temp_dir(), "\\/");
    if ($tmp !== '') {
      $candidates[] = $tmp . DIRECTORY_SEPARATOR . 'nets-musique-notes';
    }

    foreach ($candidates as $dir) {
      if (!is_dir($dir)) {
        @mkdir($dir, 0775, true);
      }
      if (is_dir($dir) && is_writable($dir)) {
        return $dir;
      }
    }

    return __DIR__ . '/../data';
  }
}

if (!function_exists('atelier_notes_path')) {
  function atelier_notes_path(): string {
    return atelier_notes_dir() . '/atelier-notes.json';
  }
}

if (!function_exists('atelier_notes_clean')) {
  function atelier_notes_clean(string $value, int $limit = 20000): string {
    $value = trim(str_replace("\0", '', $value));
    if (function_exists('mb_substr')) {
      return mb_substr($value, 0, $limit);
    }
    return substr($value, 0, $limit);
  }
}

if (!function_exists('atelier_notes_default_title')) {
  function atelier_notes_default_title(string $title, string $body): string {
    $title = atelier_notes_clean($title, 120);
    if ($title !== '') {
      return $title;
    }
    $line = trim((string)preg_split('/\r\n|\r|\n/', $body, 2)[0]);
    if ($line !== '') {
      return atelier_notes_clean($line, 80);
    }
    return 'note sans titre';
  }
}

if (!function_exists('atelier_notes_read_store')) {
  function atelier_notes_read_store(): array {
    $path = atelier_notes_path();
    if (!is_file($path)) {
      return ['notes' => []];
    }
    $raw = @file_get_contents($path);
    if (!$raw) {
      return ['notes' => []];
    }
    $data = json_decode($raw, true);
    if (!is_array($data) || !isset($data['notes']) || !is_array($data['notes'])) {
      return ['notes' => []];
    }

    $notes = [];
    foreach ($data['notes'] as $note) {
      if (!is_array($note)) {
        continue;
      }
      $notes[] = [
        'id' => (int)($note['id'] ?? 0),
        'title' => (string)($note['title'] ?? 'note sans titre'),
        'body' => (string)($note['body'] ?? ''),
        'tag' => (string)($note['tag'] ?? 'direction'),
        'pinned' => !empty($note['pinned']),
        'created_at' => (int)($note['created_at'] ?? time()),
        'updated_at' => (int)($note['updated_at'] ?? ($note['created_at'] ?? time())),
      ];
    }

    return ['notes' => array_values(array_filter($notes, static fn(array $note): bool => $note['id'] > 0))];
  }
}

if (!function_exists('atelier_notes_write_store')) {
  function atelier_notes_write_store(array $store): bool {
    $path = atelier_notes_path();
    $tmp = $path . '.tmp.' . bin2hex(random_bytes(4));
    $json = json_encode($store, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
    if ($json === false) {
      return false;
    }
    if (file_put_contents($tmp, $json, LOCK_EX) === false) {
      return false;
    }
    return rename($tmp, $path);
  }
}

if (!function_exists('atelier_notes_next_id')) {
  function atelier_notes_next_id(array $notes): int {
    $max = 0;
    foreach ($notes as $note) {
      $max = max($max, (int)($note['id'] ?? 0));
    }
    return $max + 1;
  }
}

if (!function_exists('atelier_notes_all')) {
  function atelier_notes_all(): array {
    $notes = atelier_notes_read_store()['notes'];
    usort($notes, static function (array $a, array $b): int {
      if ((bool)$a['pinned'] !== (bool)$b['pinned']) {
        return $a['pinned'] ? -1 : 1;
      }
      return ((int)$b['updated_at']) <=> ((int)$a['updated_at']);
    });
    return $notes;
  }
}

if (!function_exists('atelier_notes_create')) {
  function atelier_notes_create(string $title, string $body, string $tag, bool $pinned): bool {
    $body = atelier_notes_clean($body);
    $title = atelier_notes_default_title($title, $body);
    $tag = atelier_notes_clean($tag, 40);
    if ($tag === '') {
      $tag = 'direction';
    }
    if ($body === '' && $title === 'note sans titre') {
      return false;
    }

    $store = atelier_notes_read_store();
    $now = time();
    $store['notes'][] = [
      'id' => atelier_notes_next_id($store['notes']),
      'title' => $title,
      'body' => $body,
      'tag' => $tag,
      'pinned' => $pinned,
      'created_at' => $now,
      'updated_at' => $now,
    ];
    return atelier_notes_write_store($store);
  }
}

if (!function_exists('atelier_notes_update')) {
  function atelier_notes_update(int $id, string $title, string $body, string $tag, bool $pinned): bool {
    $store = atelier_notes_read_store();
    $found = false;
    $body = atelier_notes_clean($body);
    $title = atelier_notes_default_title($title, $body);
    $tag = atelier_notes_clean($tag, 40);
    if ($tag === '') {
      $tag = 'direction';
    }

    foreach ($store['notes'] as &$note) {
      if ((int)$note['id'] !== $id) {
        continue;
      }
      $note['title'] = $title;
      $note['body'] = $body;
      $note['tag'] = $tag;
      $note['pinned'] = $pinned;
      $note['updated_at'] = time();
      $found = true;
      break;
    }
    unset($note);

    return $found && atelier_notes_write_store($store);
  }
}

if (!function_exists('atelier_notes_delete')) {
  function atelier_notes_delete(int $id): bool {
    $store = atelier_notes_read_store();
    $before = count($store['notes']);
    $store['notes'] = array_values(array_filter($store['notes'], static fn(array $note): bool => (int)$note['id'] !== $id));
    return count($store['notes']) !== $before && atelier_notes_write_store($store);
  }
}
