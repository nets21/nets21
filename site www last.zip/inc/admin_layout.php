<?php
declare(strict_types=1);
require_once __DIR__ . '/site.php';
require_once __DIR__ . '/db.php';

// Petites stats pour la topbar / sidebar
if (!function_exists('admin_guestbook_stats')) {
  function admin_guestbook_stats(): array {
    $store = guestbook_read_store();
    $entries = $store['entries'] ?? [];
    $pending = 0; $approved = 0; $replied = 0; $lastMod = 0;
    foreach ($entries as $e) {
      $status = (string)($e['status'] ?? '');
      if ($status === 'pending')  { $pending++; }
      if ($status === 'approved') {
        $approved++;
        if (!empty($e['reply_body'])) { $replied++; }
      }
      $lastMod = max($lastMod, (int)($e['created_at'] ?? 0), (int)($e['approved_at'] ?? 0), (int)($e['replied_at'] ?? 0));
    }
    return [
      'pending'  => $pending,
      'approved' => $approved,
      'replied'  => $replied,
      'total'    => count($entries),
      'last_mod' => $lastMod,
    ];
  }
}

$admin_stats = admin_guestbook_stats();
$currentPath = strtok($_SERVER['REQUEST_URI'] ?? '/', '?') ?: '/';

$is_login     = ($admin_current ?? '') === 'login';
$is_dashboard = ($admin_current ?? '') === 'dashboard';
$is_guestbook = ($admin_current ?? '') === 'guestbook';
$is_textes    = ($admin_current ?? '') === 'textes';
$is_morceaux  = ($admin_current ?? '') === 'morceaux';
$is_cubes     = ($admin_current ?? '') === 'cubes';
$is_notes     = ($admin_current ?? '') === 'notes';

$path_home     = site_path('admin_home_path', '/coulisses-espace.php');
$path_gb       = site_path('admin_guestbook_path', '/coulisses-presences.php');
$path_textes   = site_path('admin_texts_path', '/coulisses-textes.php');
$path_morceaux = site_path('admin_tracks_path', '/coulisses-sons.php');
$path_cubes     = site_path('admin_cubes_path', '/coulisses-cubes.php');
$path_notes    = site_path('admin_notes_path', '/coulisses-notes.php');
$path_logout   = site_path('admin_logout_path', '/coulisses-sortie.php');
$admin_js_v    = (string)(@filemtime(__DIR__ . '/../assets/admin.js') ?: time());
?>
<!doctype html>
<html lang="fr">
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1"/>
<meta name="robots" content="noindex,nofollow"/>
<title><?= site_h($title ?? 'coulisses — nets-musique.digital') ?></title>
<meta name="theme-color" content="#071522"/>
<link rel="stylesheet" href="/assets/style.css"/>
<script src="/assets/admin.js?v=<?= site_h($admin_js_v) ?>" defer></script>
<link rel="icon" href="/assets/favicon.svg" type="image/svg+xml"/>
</head>
<body class="admin-body<?= $is_login ? ' admin-body-login' : '' ?>">

<?php if (!$is_login): ?>
<header class="admin-top">
  <div class="admin-top-inner">
    <div class="admin-brand">
      <span class="admin-brand-dot" aria-hidden="true"></span>
      <span class="admin-brand-name"><b>nets-musique</b>.digital</span>
      <span class="admin-badge">coulisses</span>
    </div>
    <nav class="admin-top-nav" aria-label="Sections coulisses">
      <a href="<?= site_h($path_home) ?>"<?= $is_dashboard ? ' class="is-current" aria-current="page"' : '' ?>>Tableau de bord</a>
      <a href="<?= site_h($path_textes) ?>"<?= $is_textes ? ' class="is-current" aria-current="page"' : '' ?>>Textes</a>
      <a href="<?= site_h($path_morceaux) ?>"<?= $is_morceaux ? ' class="is-current" aria-current="page"' : '' ?>>Morceaux</a>
      <a href="<?= site_h($path_cubes) ?>"<?= $is_cubes ? ' class="is-current" aria-current="page"' : '' ?>>Cubes</a>
      <a href="<?= site_h($path_notes) ?>"<?= $is_notes ? ' class="is-current" aria-current="page"' : '' ?>>Pense-bête</a>
      <a href="<?= site_h($path_gb) ?>"<?= $is_guestbook ? ' class="is-current" aria-current="page"' : '' ?>>Présences<?php if ($admin_stats['pending'] > 0): ?> <span class="count"><?= (int)$admin_stats['pending'] ?></span><?php endif; ?></a>
      <a href="/" target="_blank" rel="noopener">Voir le site ↗</a>
    </nav>
    <div class="admin-top-spacer"></div>
    <div class="admin-top-user">
      <span class="admin-user-chip"><?= site_h($site['admin_user'] ?? 'atelier') ?></span>
      <a class="admin-top-logout" href="<?= site_h($path_logout) ?>">sortie</a>
    </div>
  </div>
</header>

<div class="admin-shell">
  <aside class="admin-side" aria-label="Navigation coulisses">
    <div class="admin-side-label">Coulisses</div>
    <a href="<?= site_h($path_home) ?>"<?= $is_dashboard ? ' class="is-current" aria-current="page"' : '' ?>>
      <span class="dot" aria-hidden="true"></span>Tableau de bord
    </a>
    <a href="<?= site_h($path_gb) ?>"<?= $is_guestbook ? ' class="is-current" aria-current="page"' : '' ?>>
      <span class="dot" aria-hidden="true"></span>Présences
      <?php if ($admin_stats['pending'] > 0): ?><span class="count alert"><?= (int)$admin_stats['pending'] ?></span><?php endif; ?>
    </a>
    <div class="admin-side-label">Contenu éditable</div>
    <a href="<?= site_h($path_textes) ?>"<?= $is_textes ? ' class="is-current" aria-current="page"' : '' ?>>
      <span class="dot" aria-hidden="true"></span>Textes du site
    </a>
    <a href="<?= site_h($path_morceaux) ?>"<?= $is_morceaux ? ' class="is-current" aria-current="page"' : '' ?>>
      <span class="dot" aria-hidden="true"></span>Morceaux
    </a>
    <a href="<?= site_h($path_cubes) ?>"<?= $is_cubes ? ' class="is-current" aria-current="page"' : '' ?>>
      <span class="dot" aria-hidden="true"></span>Cubes
    </a>
    <a href="<?= site_h($path_notes) ?>"<?= $is_notes ? ' class="is-current" aria-current="page"' : '' ?>>
      <span class="dot" aria-hidden="true"></span>Pense-bête
    </a>
    <div class="admin-side-label">Repères</div>
    <a href="/" target="_blank" rel="noopener"><span class="dot" aria-hidden="true"></span>Voir le site public</a>
    <a href="/chat.php" target="_blank" rel="noopener"><span class="dot" aria-hidden="true"></span>Présences publiques</a>
    <div class="admin-side-label">Sortie</div>
    <a href="<?= site_h($path_logout) ?>"><span class="dot" aria-hidden="true"></span>Se déconnecter</a>
  </aside>

  <main class="admin-main" id="admin-main">
    <?= $page_content ?? '' ?>
  </main>
</div>
<?php else: ?>
  <?= $page_content ?? '' ?>
<?php endif; ?>

</body>
</html>
