<?php
declare(strict_types=1);

function chat_translation_languages(): array {
  return [
    'fr'=>'Français', 'en'=>'English', 'es'=>'Español', 'pt'=>'Português',
    'de'=>'Deutsch', 'it'=>'Italiano', 'nl'=>'Nederlands', 'da'=>'Dansk',
    'sv'=>'Svenska', 'nb'=>'Norsk', 'fi'=>'Suomi', 'is'=>'Íslenska',
    'pl'=>'Polski', 'uk'=>'Українська', 'ru'=>'Русский', 'el'=>'Ελληνικά',
    'tr'=>'Türkçe', 'ar'=>'العربية', 'he'=>'עברית', 'hi'=>'हिन्दी',
    'zh-Hans'=>'简体中文', 'ja'=>'日本語', 'ko'=>'한국어', 'vi'=>'Tiếng Việt',
    'id'=>'Bahasa Indonesia', 'sw'=>'Kiswahili', 'iu'=>'ᐃᓄᒃᑎᑐᑦ · Inuktitut',
  ];
}

function chat_translation_ready(): bool {
  // Confirmation explicite du tarif F0 : aucune activation automatique.
  return getenv('NETS_TRANSLATOR_F0_CONFIRMED') === 'yes'
    && trim((string)getenv('NETS_TRANSLATOR_KEY')) !== ''
    && function_exists('curl_init');
}

function chat_translation_write($handle, array $state): bool {
  $json = json_encode($state, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
  if ($json === false) { return false; }
  rewind($handle);
  return ftruncate($handle, 0) && fwrite($handle, $json) === strlen($json) && fflush($handle);
}

function chat_translation_request(array $texts, string $target): ?array {
  $key = trim((string)getenv('NETS_TRANSLATOR_KEY'));
  $region = trim((string)getenv('NETS_TRANSLATOR_REGION'));
  if (preg_match('/[\r\n]/', $key . $region)) { return null; }
  $headers = ['Content-Type: application/json; charset=UTF-8', 'Ocp-Apim-Subscription-Key: ' . $key];
  if ($region !== '') { $headers[] = 'Ocp-Apim-Subscription-Region: ' . $region; }
  $url = 'https://api.cognitive.microsofttranslator.com/translate?api-version=3.0&textType=plain&profanityAction=Marked&to=' . rawurlencode($target);
  $handle = curl_init($url);
  if ($handle === false) { return null; }
  $response = '';
  curl_setopt_array($handle, [
    CURLOPT_POST=>true, CURLOPT_HTTPHEADER=>$headers,
    CURLOPT_POSTFIELDS=>json_encode(array_map(static fn($text)=>['Text'=>$text], $texts), JSON_UNESCAPED_UNICODE),
    CURLOPT_CONNECTTIMEOUT=>3, CURLOPT_TIMEOUT=>8,
    CURLOPT_FOLLOWLOCATION=>false, CURLOPT_PROTOCOLS=>CURLPROTO_HTTPS,
    CURLOPT_SSL_VERIFYPEER=>true, CURLOPT_SSL_VERIFYHOST=>2,
    CURLOPT_WRITEFUNCTION=>static function ($curl, string $chunk) use (&$response): int {
      if (strlen($response) + strlen($chunk) > 262144) { return 0; }
      $response .= $chunk;
      return strlen($chunk);
    },
  ]);
  $ok = curl_exec($handle);
  $status = (int)curl_getinfo($handle, CURLINFO_RESPONSE_CODE);
  curl_close($handle);
  if ($ok === false || $status !== 200) { return null; }
  $decoded = json_decode($response, true);
  return is_array($decoded) ? $decoded : null;
}

/** Ne traduit que les messages publics non marques par la moderation.
 * Le transport optionnel permet de tester le quota sans service externe.
 */
function chat_translate_messages(array $messages, string $target, ?callable $transport = null): array {
  $result = ['status'=>'unavailable', 'translations'=>[]];
  if (!isset(chat_translation_languages()[$target]) || !chat_translation_ready() || count($messages) > 20) { return $result; }
  $path = __DIR__ . '/../data/chat-translations.json';
  $handle = @fopen($path, 'c+');
  if ($handle === false) { return $result; }
  try {
    // Une autre traduction en cours ne doit pas bloquer le salon.
    if (!flock($handle, LOCK_EX | LOCK_NB)) { $result['status'] = 'busy'; return $result; }
    rewind($handle);
    $raw = stream_get_contents($handle);
    if ($raw === false) { return $result; }
    $month = gmdate('Y-m');
    $state = $raw === '' ? ['month'=>$month,'used'=>0,'cooldown'=>0,'cache'=>[]] : json_decode($raw, true);
    if (!is_array($state) || !is_string($state['month'] ?? null) || !is_int($state['used'] ?? null)
        || $state['used'] < 0 || !is_int($state['cooldown'] ?? null) || !is_array($state['cache'] ?? null)) { return $result; }
    if ($state['month'] !== $month) { $state['month'] = $month; $state['used'] = 0; }
    $now = time();
    $state['cache'] = array_filter($state['cache'], static fn($item)=>is_array($item) && (int)($item['expires'] ?? 0) > $now);
    $pending = []; $cost = 0;
    foreach ($messages as $message) {
      if (!is_array($message) || !empty($message['moderated']) || (int)($message['created_at'] ?? 0) <= $now - 604800) { continue; }
      $body = (string)($message['body'] ?? '');
      $id = (int)($message['id'] ?? 0);
      if ($id < 1 || $body === '' || strlen($body) > 2400) { continue; }
      $cacheKey = hash('sha256', $id . '|' . $body . '|' . $target);
      $cached = $state['cache'][$cacheKey] ?? null;
      if (is_array($cached) && is_string($cached['text'] ?? null) && is_string($cached['source'] ?? null)) {
        $result['translations'][(string)$id] = ['text'=>$cached['text'],'source'=>$cached['source']];
      } else {
        $pending[] = ['id'=>$id,'key'=>$cacheKey,'body'=>$body,'expires'=>(int)$message['created_at'] + 604800];
        // Compter les octets UTF-8 est conservateur par rapport aux caracteres factures.
        $cost += strlen($body);
      }
    }
    $result['status'] = 'ok';
    if ($pending === []) { chat_translation_write($handle, $state); return $result; }
    if ($state['cooldown'] > $now) { $result['status'] = 'unavailable'; return $result; }
    // Garde-fou local supplementaire ; F0 reste indispensable cote fournisseur.
    if ($state['used'] + $cost > 1000000) { $result['status'] = 'quota'; return $result; }
    $state['used'] += $cost;
    if (!chat_translation_write($handle, $state)) { $result['status'] = 'unavailable'; return $result; }
    $reply = ($transport ?? 'chat_translation_request')(array_column($pending, 'body'), $target);
    if (!is_array($reply) || count($reply) !== count($pending)) {
      $state['cooldown'] = $now + 60;
      chat_translation_write($handle, $state);
      $result['status'] = 'unavailable'; return $result;
    }
    foreach ($pending as $i=>$item) {
      $text = $reply[$i]['translations'][0]['text'] ?? null;
      $to = $reply[$i]['translations'][0]['to'] ?? null;
      $source = $reply[$i]['detectedLanguage']['language'] ?? '';
      if (!is_string($text) || $text === '' || strlen($text) > 12000 || $to !== $target || !is_string($source) || !preg_match('/^[a-zA-Z-]{0,16}$/D', $source)) { continue; }
      $state['cache'][$item['key']] = ['text'=>$text,'source'=>$source,'expires'=>$item['expires']];
      $result['translations'][(string)$item['id']] = ['text'=>$text,'source'=>$source];
    }
    // Taille bornee, sans jamais modifier les messages originaux.
    if (count($state['cache']) > 1000) { $state['cache'] = array_slice($state['cache'], -1000, null, true); }
    chat_translation_write($handle, $state);
    return $result;
  } finally { @flock($handle, LOCK_UN); fclose($handle); }
}
