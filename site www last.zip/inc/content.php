<?php
declare(strict_types=1);

$content = [
  'brand_poetic' => 'born-a-gain.blog // nets-musiques',
  'brand_poetic_tagline' => 'Musiques originales, fragments, sessions born-a-gain.blog et retours d’écoute dans un même espace.',

  'manifesto_title' => 'Sans paroles.',
  'manifesto_lines' => [
    'Je fais une musique sans paroles, mais pas sans adresse.',
    'Elle vient directement, puis reçoit son nom après.',
    'Ici, le site sert d’abord à laisser l’écoute agir.',
  ],

  'school_lines' => [
    'Ce lieu ne raconte pas toute l’école qui l’a formé.',
    'Il en porte pourtant quelque chose : une musique apprise dans l’écoute, les heures, les reprises, et le travail patient du son.',
  ],

  'atelier_intro_title' => 'Premières affinités',
  'atelier_intro_lines' => [
    'Entendre un instrument et savoir que quelque chose commence.',
    'Instinct : avoir une réponse à jouer dès la première touche.',
  ],
  'two_violins_title' => '2 violons',
  'two_violins_lines' => [
    'Deux voix, un rythme en ricochet.',
    'Un morceau pour apprendre à un violoniste, s’il le souhaite, par quelqu’un qui a fait du solfège tout petit.',
    'Ce morceau est fait « pour toi » : ricochets de rythmes, et deux violons qui se parlent, se contredisent.',
    'Pour lâcher le violon — ou se faire lâcher par lui — et peut-être, un jour, y venir.',
    'Si le musicien entend, il saura ce qui en découle.',
    'Et pour les autres : passez aussi lire ce petit texte. Juste « décrocher du violon » et arriver à la guitare : c’est une méthode express.',
  ],
  'atelier_contact_intro' => 'Chacun peut prendre contact par deux chemins : laisser une présence sans donner d’adresse e-mail, ou écrire directement à l’adresse du site. Dans les présences, l’e-mail reste facultatif et ne sert que si une réponse privée doit être possible.',
  'member_area_title' => 'Sons rafraîchis, fichiers originaux',
  'member_area_lines' => [
    'Pour l’instant, je rafraîchis mes sons avant de les remettre en écoute.',
    'Si quelqu’un veut quelque chose de plus « brut », ce sera le fichier original.',
    'Les fichiers originaux ne sont pas posés directement dans l’écoute publique : ils passent par la zone membre, avec un accès donné après contact.',
  ],
  'member_area_intro' => 'Une zone légère pour aller plus loin après l’écoute : retrouver un fichier original, une version plus brute ou un élément transmis directement. L’accès n’est pas automatique ; il commence par un vrai contact.',

  'ethics_quote' => 'Dans un monde pressé, ce site choisit encore l’écoute, le temps, et une forme de confiance.',

  'returning_music_lines' => [
    'Ici, la musique n’apparaît pas comme un stock figé.',
    'Elle revient, se reprend, se rafraîchit, puis retrouve sa place peu à peu.',
  ],

  'sessions_intro_lines' => [
    'Les sessions sont des performances longues construites avec Ableton Live : pas une démonstration, plutôt une logique qui se cherche jusqu’à devenir musique.',
    'Ableton Live est ici le logiciel utilisé pour me dépasser encore : tenir une forme, accepter le défi, laisser apparaître l’étonnement quand la matière répond.',
    'La musique ne s’arrête que quand elle a fini de revenir. Chassez la musique, elle revient au galop.',
  ],
  'sessions_listening_lines' => [
    'Ces écoutes peuvent toucher des zones sensibles : incompréhensions, non-dits, vérités que l’on n’a pas toujours envie de regarder.',
    'Il n’y a pas d’obligation d’aller jusqu’au bout. Un temps de latence, un temps mort, peut aussi porter quelque chose.',
    'Si vous venez surtout d’une écoute très cadrée, fouillez le site franchement : les sessions ouvrent une autre entrée.',
  ],

  'home_intro_title' => 'Accueil unique : nets-musique.digital, born-a-gain.blog pour les sessions, fragments et contact.',
  'home_intro_lines' => [
    'Sept écoutes publiques structurent l’entrée : six fragments et une session.',
    'Le rythme peut sembler long si les instruments ne se donnent pas tout de suite, ou si l’écoute ne vient pas encore.',
    'Les sons prennent pourtant la place qu’ils occupent, et celle qu’ils doivent occuper. Les premières écoutes ouvrent la porte ; ensuite, c’est la personne qui voit.',
    'C’est l’inverse d’un geste commercial : la musique ne force pas l’adhésion, elle cherche une stabilité qui tient.',
    'Le lecteur reste en place pour suivre les pages sans casser l’écoute.',
    'Le site sert à la fois de présence d’artiste, de trace d’écoute et de point de contact par e-mail.',
    'La page des présences garde une forme calme : messages relus, réponses possibles, pas de bruit inutile.',
    'Les ouvertures futures restent sobres : laisser le site grandir, garder une trace des retours qui comptent, et préciser les chemins de contact plus tard si nécessaire.',
  ],

  'home_exchange_title' => 'Du plus loin au plus près, sans être proche.',
  'home_exchange_lines' => [
    'Ce site est une aventure sur la toile : la musique ouvre un passage, puis quelques mots peuvent circuler sans obliger les personnes à devenir proches.',
    'Il s’adresse aussi à celles et ceux que la distance éloigne des grands centres ou les uns des autres. Il ne parle pas à leur place ; il propose un lieu d’écoute et d’échange qui n’ajoute pas un problème de plus.',
    'Le projet commence en français. L’anglais, l’espagnol, le russe puis d’autres langues pourront ouvrir progressivement le même lieu, en respectant le texte original.',
    'Si la paix intéresse davantage à travers cette musique, le projet aura déjà trouvé sa raison d’exister.',
  ],

  'artist_identity_lines' => [
    'Projet artistique personnel porté par nets / Aurélien : écriture, guitare, percussions, piano, production et mastering.',
    'La musique reste au centre, avec peu de pages et un rapport direct à l’écoute.',
  ],

  'professional_focus_title' => 'Ce que ce site propose',
  'professional_focus_points' => [
    'écoutes publiques complètes, pensées comme de vraies entrées dans le travail',
    'lecteur persistant pour traverser les pages sans couper la musique',
    'contact par e-mail pour soutien, questions, écoute privée ou échange autour d’un morceau',
    'base légère prête à évoluer vers des chemins de contact plus clairs et des sessions Ableton associées à certains morceaux',
  ],

  'guestbook_intro' => 'Cette page permet de laisser une présence après écoute. Les messages sont relus avant publication, et je peux parfois y répondre moi-même.',
  'guestbook_callout' => 'Auditeurs, proches, curateurs, programmateurs ou personnes de passage peuvent laisser une trace d’écoute.',
  'members_intro' => 'L’extérieur reste lisible et modéré. La zone membre prolonge seulement un échange déjà commencé : fichier original, version plus brute ou envoi direct, sans compte imposé à tout le monde.',
  'first_track_note' => '',
  'player_notice' => 'Le lecteur reste en place pendant la navigation interne. Selon le navigateur, la lecture démarre automatiquement ou au premier geste.',

  'presence_title' => 'Présence artistique',
  'presence_name' => 'nets / Aurélien',
  'presence_status' => '● Présent sur le site et dans les échanges essentiels.',
  'presence_text' => 'Je réponds moi-même quand le message appelle une suite : soutien, retour d’écoute, demande sur un morceau ou échange artistique.',
  'presence_signal_label' => 'dans la toile',
  'presence_signal_state' => 'présent aujourd’hui',
  'presence_signal_note' => 'réponse possible plus tard, sans urgence.',

  'guestbook_title' => 'Présences',
  'guestbook_text' => 'Un lieu extérieur, relu, pour laisser une trace d’écoute avant d’aller plus loin.',

  'about_intro_lines' => [
    'Je viens d’une pratique musicale classique, traversée par des années d’apprentissage en solo, d’écoute, de concerts, de terrain et de contacts réels.',
    'Je joue d’abord. Je fabrique. Le nom du morceau vient après.',
    'Ici, “digital” n’est pas réduit à “numérique”. Il désigne aussi le doigt, le geste, le périphérique électronique tenu en main, et la relation tactile aux machines qui déclenchent ou transforment le son.',
    'Aujourd’hui, Ableton Live est devenu mon moyen d’expression le plus direct. La guitare reste présente, mais souvent de manière plus privée, plus intérieure, comme instrument d’accompagnement, de recherche ou de départ.',
    'Ce site n’a pas été fait pour la promotion au sens habituel. Il sert à continuer : déposer des pièces, ouvrir quelques écoutes, laisser une place à la discussion, proposer parfois des éditions ou des envois plus directs.',
    'J’essaie d’y garder quelque chose de simple : un peu de tenue, un peu de respect, et une musique qui n’a pas besoin de jouer avec les gens pour exister.',
  ],
  'about_extra' => 'Une partie des morceaux a déjà vécu ailleurs, parfois plus loin que le site lui-même, au fil des écoutes et des téléchargements. Le site cherche maintenant à devenir à la hauteur de cette trajectoire, sans perdre sa forme minimale.',
  'about_forms' => 'Le bleu et le rouge ne sont pas seulement des couleurs : ce sont deux vitesses d’écoute. Les sessions ouvrent la continuité. Les fragments tiennent des formes plus courtes, reprises, retravaillées ou réexposées. Entre les deux, il y a une même exigence de son, de forme et de présence.',
  'about_simple' => 'Ici, l’idée n’est pas de sur-promettre : écouter, soutenir, recevoir, écrire directement, avec peu de pages mais des gestes réels.',
  'about_work_lines' => [
    'La démarche tient ensemble composition, jeu, électronique, enregistrement et rendu final.',
    'Le mastering compte comme un vrai geste d’écoute : tenir le morceau, lui laisser sa place, et ne pas écraser ce qu’il doit porter.',
    'Le site ne remplace pas un dossier de presse : il montre d’abord le travail lui-même, dans sa continuité.',
    'Cette base volontairement légère laisse de la place à la musique, à la reprise des pièces et à un contact par e-mail quand cela a du sens.',
  ],

  'bio_title' => 'Biographie musicale',
  'bio_intro' => 'Les morceaux déposés ici appartiennent à une continuité : le violon, les lieux, les contacts, puis les sessions, les périphériques et les formes électroniques actuelles.',
  'bio_lines' => [
    'La première marque vient du violon. Enfant à La Réunion, j’entre au solfège vers huit ans, puis je suis sélectionné pour travailler l’instrument. Avant de montrer ma valeur, il a fallu apprendre la précision, l’écoute, la volonté.',
    'À dix ans, je joue sur scène avec l’école de musique, au Parc des expositions de La Réunion. Une pianiste que je ne connaissais pas m’accompagne. Nous nous regardons, et quelque chose se comprend tout de suite. Le morceau n’était pas long, mais il était efficace.',
    'Ce souvenir reste net : l’annonce au micro, les applaudissements dans le parc, puis ma mère et ma professeure venues m’accueillir en bas des marches. Un violoniste n’oublie pas ce genre de moment.',
    'Plus tard, à une période où j’étais encore pur violoniste, il m’est arrivé de jouer en hiver au bord de Saône, près d’une péniche parfois à quai. Le chemin passait là, avec un banc, des passants, et parfois deux jeunes sur la péniche qui écoutaient sans vraiment intervenir.',
    'Je jouais sur un violon chinois. Cela peut faire sourire, mais sur un violon, parfois 0,5 mm change déjà le son : un chevalet, une âme, une pression, un angle, et tout l’équilibre bouge. J’ai construit mon son sur ce fil du rasoir, avec les moyens que j’avais, en cherchant la justesse du geste plus que le prestige de l’instrument.',
    'Je sais parfois chercher la confrontation dans la musique, mais ce n’était pas ce moment-là. Je ne jouais pas jusqu’à plus soif. J’étais à l’écoute de tout : du lieu, du froid, de l’eau, des gens qui passaient, de ceux qui restaient un peu, et de ce que le violon pouvait laisser sans forcer.',
    'Ce n’était pas une scène officielle. Ce n’était pas un concert annoncé. C’était le violon seul, dehors, dans le froid, au bord de l’eau. Les gens n’étaient pas mécontents ; certains semblaient surtout curieux. Ils entendaient quelque chose sans forcément savoir quoi en faire.',
    'J’ai eu beaucoup de contacts à cette époque : des présences, des regards, des passages, des moments courts mais réels. J’en sors encore heureux, parce que la musique m’a permis de traverser des lieux et des gens sans toujours avoir besoin d’expliquer.',
    'Pourtant, je fais dans l’utile et le concret. Je ne cherche pas seulement l’effet ou la posture. Derrière les cordes, il y a une forme de gloire discrète : celle du geste travaillé, du son construit avec peu, de l’instrument réglé au plus juste, et de l’écoute tenue jusqu’à trouver un passage vrai.',
    'Plus tard, en France, j’ai appris la volonté autrement. J’ai appris la guitare par mes propres moyens, sans chercher à devenir un guitariste démonstratif. Certains sons du site montrent plutôt comment un violoniste peut se fabriquer une image de la guitare et sortir de l’emballage qui enferme le geste.',
    'J’ai aussi connu l’électronique par une base concrète, apprise en BEP. Ici, le mot “digital” ne veut pas seulement dire numérique : il parle aussi du doigt, du contact, du périphérique électronique en main, et de la relation tactile aux machines.',
    'Aujourd’hui, cette musique n’est pas une collection d’albums finis au sens commercial. Elle témoigne d’un apprentissage long : reprendre, comprendre, préciser, trouver des notes justes dans un monde souvent imprécis.',
    'Ce site rassemble cette trace. Il peut devenir un tombeau artistique au sens musical du terme : une pierre déposée, une preuve de travail, une manière de laisser la musique tenir debout sans se déguiser.',
  ],
  'bio_markers' => [
    'La Réunion : solfège, violon, première scène.',
    'Saône : violon chinois, hiver, banc, péniche, passants, écoute du lieu.',
    'France : volonté, guitare apprise seul, fabrication du son.',
    'Site : fragments, sessions born-a-gain.blog, preuves, écoute sur place.',
  ],

  'irc_history_title' => 'De La Réunion à un lieu d’échange',
  'irc_history_lines' => [
    'J’ai été co-chanmaster d’un salon IRC de l’île de La Réunion. J’y ai connu une présence particulière : des personnes éloignées pouvaient parler et faire vivre un lieu commun sans partager le même espace.',
    'Ce besoin de parler à des gens qui sont loin ne m’a jamais vraiment quitté. Il touche quelque chose de profond en moi.',
    'Le site ne cherche pas à reconstruire l’ancien IRC à l’identique. Il reprend ce passage : laisser la musique accueillir, puis permettre une conversation légère, presque translucide, où chacun conserve sa distance.',
    'Je serai fier d’y découvrir les ressemblances comme les différences, même lorsque je ne suis pas présent en permanence.',
  ],

  'chat_beta_title' => 'Un salon pendant sept jours',
  'chat_beta_lines' => [
    'Ce salon accompagne la phase bêta du site. Les messages sont publics immédiatement, restent visibles pendant sept jours, puis disparaissent automatiquement.',
    'Il permet déjà de laisser quelques mots autour de la musique sans construire une archive permanente. Personne n’est obligé de raconter sa vie ni de devenir proche pour participer.',
    'Ce salon provisoire reste volontairement simple. Il ne prétend pas encore être le futur tchat multilingue inspiré de l’IRC.',
  ],

  'chat_future_title' => 'Après la phase bêta',
  'chat_future_lines' => [
    'Le futur salon pourra traduire les échanges de manière transparente : chacun écrira dans sa langue et pourra toujours retrouver le message original.',
    'Une protection inspirée de l’IRC est prévue : détection des insultes malgré certaines lettres masquées, droit immédiat pour la personne visée de se protéger, et kick ou ban lorsque cela devient nécessaire.',
    'Le flood répété pourra provoquer un kick automatique du serveur. Un statut Helper très court pourra aussi être attribué à une seule personne à la fois, puis disparaître automatiquement.',
    'Ces fonctions viendront seulement après une phase bêta réussie. Aujourd’hui, le français et le salon de sept jours restent la base stable.',
  ],

  'listening_ethics_title' => 'Démarche d’écoute',
  'listening_ethics_lines' => [
    'Cette démarche part d’une idée simple : une musique sans paroles peut parfois ouvrir une autre réalité, sans obliger quelqu’un à s’expliquer.',
    'Le premier geste peut rester postal : une lettre adressée à une structure, accompagnée d’un CD propre et d’un texte clair sur le but de l’envoi.',
    'Il ne s’agit pas de sauver, de convaincre ou de manipuler. Il s’agit seulement de proposer une petite porte d’écoute plus constructive, si une équipe estime que cela peut avoir du sens.',
    'Cette musique n’impose pas d’identité. Elle peut servir d’outil d’écoute, sans parole obligatoire, sans rôle à tenir, sans enfermer quelqu’un dans une musique ou une impasse.',
    'L’intention doit être dite clairement par la structure : personne n’est pris dans un dispositif caché.',
    'Les morceaux peuvent être proposés gratuitement à des équipes éducatives, thérapeutiques ou sociales comme support d’écoute. Ils ne remplacent ni un soin, ni une parole, ni un accompagnement ; ils offrent seulement un objet sonore construit avec respect.',
    'Aucune vente ne se fait sur le dos des personnes concernées : la circulation peut rester gratuite quand le contexte le demande.',
  ],

  'contact_topics' => [
    'retour d’écoute, message sensible ou question sur un morceau',
    'demande autour d’un morceau, d’un retour suivi ou d’un envoi direct',
    'échange artistique, programmation légère, projet à taille humaine',
    'soutien simple pour aider la musique à rester vivante et accessible',
  ],

  'support_modes' => [
    'écoute libre sur le site, sans passage obligé par le paiement',
    'soutien conseillé de 3 € via Ko-fi pour aider les prochaines mises en ligne',
    'téléchargements complets possibles plus tard via Ko-fi Shop, fichier par fichier',
    'contact par e-mail pour une demande précise, un retour ou un contexte clair',
    'zone membre légère pour transmettre un fichier original ou une version plus brute après contact',
  ],
  'social_intro' => 'Presences choisies, sans integration externe dans le site.',
  'social_links' => [
  ],

  'privacy_title' => 'Confidentialité sobre',
  'privacy_intro' => 'Le site ne cherche pas à savoir qui vous êtes. Il garde seulement ce qui est nécessaire au fonctionnement, ou ce que vous choisissez d’écrire volontairement.',
  'privacy_lines' => [
    'Pas de suivi externe, pas de publicité, pas de mesure d’audience intrusive.',
    'Pas de cookies de pistage. Les cookies de session servent seulement aux fonctions nécessaires, comme l’atelier privé ou la page des présences.',
    'Les écoutes se font sur le site. Les fichiers éventuels restent rattachés à un morceau précis, par exemple une session Ableton distincte où ce morceau existe comme piste.',
    'Les informations arrivent seulement si vous écrivez volontairement : e-mail, présence publiée après relecture, ou formulaire futur choisi clairement.',
    'Les messages envoyés dans les présences sont relus avant publication. Rien n’est publié automatiquement.',
    'Les réseaux choisis restent des liens sortants : le site ne charge pas leurs outils de suivi dans les pages.',
  ],

  'downloads_readme_title' => 'Merci pour votre soutien.',
  'downloads_readme_body' => "Merci pour votre soutien et votre écoute.

Merci de respecter le travail, le temps, et l’écoute.
Le site reste vivant : la musique revient, se reprend, se rafraîchit, puis retrouve sa place peu à peu.

Contact : aurelien@nets-musique.digital",

  // Le catalogue est alimenté par les imports dans Coulisses > Sons.
  // Aucun morceau de démonstration sans fichier audio.
  'discovery_tracks' => [],
  'sessions' => [],
  'fragments' => [],
];

$content = array_replace($content, json_decode((string)file_get_contents(__DIR__ . "/../data/editorial-defaults.json"), true) ?: []);
