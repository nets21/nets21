<?php
declare(strict_types=1);

require_once __DIR__ . '/site.php';
require_once __DIR__ . '/security.php';

function admin_send_private_headers(): void {
  if (headers_sent()) {
    return;
  }
  header('X-Robots-Tag: noindex, nofollow, noarchive');
  header('Cache-Control: no-store, private, max-age=0');
}

function admin_session_start(): void {
  admin_send_private_headers();
  site_session_start('NETSADMINSESSID');
  if (empty($_SESSION['admin_csrf'])) {
    $_SESSION['admin_csrf'] = bin2hex(random_bytes(16));
  }
}

function admin_attempts_path(): string {
  $dir = __DIR__ . '/../data';
  if (!is_dir($dir)) {
    @mkdir($dir, 0755, true);
  }
  $path = $dir . '/admin_attempts.json';
  if (!file_exists($path)) {
    file_put_contents($path, json_encode(['attempts' => []], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
  }
  return $path;
}

function admin_attempts_read(): array {
  $raw = @file_get_contents(admin_attempts_path());
  $data = json_decode((string)$raw, true);
  if (!is_array($data) || !isset($data['attempts']) || !is_array($data['attempts'])) {
    return ['attempts' => []];
  }
  return $data;
}

function admin_attempts_write(array $data): void {
  @file_put_contents(admin_attempts_path(), json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), LOCK_EX);
}

function admin_attempt_key(string $ip): string {
  return $ip !== '' ? $ip : 'unknown';
}

function admin_login_allowed(string $ip): bool {
  $data = admin_attempts_read();
  $key = admin_attempt_key($ip);
  $now = time();
  $window = 15 * 60;
  $attempts = array_values(array_filter($data['attempts'][$key] ?? [], static function ($ts) use ($now, $window): bool {
    return is_int($ts) && ($now - $ts) < $window;
  }));
  $data['attempts'][$key] = $attempts;
  admin_attempts_write($data);
  return count($attempts) < 5;
}

function admin_record_failed_login(string $ip): void {
  $data = admin_attempts_read();
  $key = admin_attempt_key($ip);
  $attempts = $data['attempts'][$key] ?? [];
  $attempts[] = time();
  $data['attempts'][$key] = array_slice(array_values(array_filter($attempts, 'is_int')), -20);
  admin_attempts_write($data);
}

function admin_clear_login_attempts(string $ip): void {
  $data = admin_attempts_read();
  unset($data['attempts'][admin_attempt_key($ip)]);
  admin_attempts_write($data);
}

function admin_is_logged_in(): bool {
  admin_session_start();
  return !empty($_SESSION['admin_logged_in']);
}

function admin_login(string $username, string $password): bool {
  global $site;
  admin_session_start();
  $ip = (string)($_SERVER['REMOTE_ADDR'] ?? '');
  if (!admin_login_allowed($ip)) {
    return false;
  }

  $valid = false;
  if ($username === (string)$site['admin_user']) {
    $hash = (string)($site['admin_password_hash'] ?? '');
    if ($hash !== '' && password_verify($password, $hash)) {
      $valid = true;
    }
  }

  if ($valid) {
    session_regenerate_id(true);
    $_SESSION['admin_logged_in'] = true;
    admin_clear_login_attempts($ip);
    return true;
  }

  admin_record_failed_login($ip);
  return false;
}

function admin_require_login(): void {
  if (!admin_is_logged_in()) {
    header('Location: ' . site_path('admin_login_path', '/coulisses.php'));
    exit;
  }
}

function admin_logout(): void {
  admin_session_start();
  $_SESSION = [];
  if (ini_get('session.use_cookies')) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 3600, $params['path'], $params['domain'], (bool)$params['secure'], (bool)$params['httponly']);
  }
  session_destroy();
}
