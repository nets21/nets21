<?php
declare(strict_types=1);

require_once __DIR__ . '/security.php';
require_once __DIR__ . '/media.php';

function member_access_default_ttl_seconds(): int {
  return 15 * 60;
}

function member_access_ttl_options(): array {
  return [
    'quarter_hour' => ['label' => '15 min', 'seconds' => member_access_default_ttl_seconds()],
    'hour' => ['label' => '1 h', 'seconds' => 60 * 60],
    'three_hours' => ['label' => '3 h', 'seconds' => 3 * 60 * 60],
  ];
}

function member_access_ttl_seconds(string $key): int {
  $options = member_access_ttl_options();
  $seconds = (int)($options[$key]['seconds'] ?? member_access_default_ttl_seconds());
  return member_access_clamp_ttl_seconds($seconds);
}

function member_access_clamp_ttl_seconds(int $seconds): int {
  return max(15 * 60, min($seconds, 3 * 60 * 60));
}

function member_access_format_expiry(int $expiresAt): string {
  return $expiresAt > 0 ? date('d/m/Y H:i', $expiresAt) : '';
}

function member_access_default_store(): array {
  return [
    'password_hash' => '',
    'version' => '',
    'updated_at' => 0,
    'expires_at' => 0,
  ];
}

function member_access_storage_path(): string {
  $dir = __DIR__ . '/../data';
  if (!is_dir($dir)) {
    @mkdir($dir, 0755, true);
  }

  $path = $dir . '/member-access.json';
  if (!is_file($path)) {
    $json = json_encode(member_access_default_store(), JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
    if ($json !== false) {
      @file_put_contents($path, $json . PHP_EOL, LOCK_EX);
    }
  }
  return $path;
}

function member_access_read(): array {
  $raw = @file_get_contents(member_access_storage_path());
  $data = json_decode((string)$raw, true);
  if (!is_array($data)) {
    return member_access_default_store();
  }

  $store = [
    'password_hash' => (string)($data['password_hash'] ?? ''),
    'version' => (string)($data['version'] ?? ''),
    'updated_at' => max(0, (int)($data['updated_at'] ?? 0)),
    'expires_at' => max(0, (int)($data['expires_at'] ?? 0)),
  ];

  if ($store['version'] !== '' && $store['expires_at'] <= 0) {
    $store['expires_at'] = $store['updated_at'] > 0
      ? $store['updated_at'] + member_access_default_ttl_seconds()
      : time() - 1;
  }

  if ($store['version'] !== '' && $store['expires_at'] > 0 && time() >= $store['expires_at']) {
    member_access_disable();
    return member_access_default_store();
  }

  return $store;
}

function member_access_write(array $store): bool {
  $path = member_access_storage_path();
  $tmp = $path . '.tmp.' . bin2hex(random_bytes(4));
  $json = json_encode($store, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
  if ($json === false || @file_put_contents($tmp, $json . PHP_EOL, LOCK_EX) === false) {
    return false;
  }
  if (!@rename($tmp, $path)) {
    @unlink($tmp);
    return false;
  }
  return true;
}

function member_access_is_configured(): bool {
  $store = member_access_read();
  return $store['password_hash'] !== '' && $store['version'] !== '';
}

function member_access_set_code(string $code, int $ttlSeconds = 0): bool {
  $code = trim($code);
  if (strlen($code) < 8 || strlen($code) > 120) {
    return false;
  }
  $ttlSeconds = $ttlSeconds > 0 ? member_access_clamp_ttl_seconds($ttlSeconds) : member_access_default_ttl_seconds();

  $hash = password_hash($code, PASSWORD_DEFAULT);
  if (!is_string($hash) || $hash === '') {
    return false;
  }

  $now = time();
  return member_access_write([
    'password_hash' => $hash,
    'version' => bin2hex(random_bytes(16)),
    'updated_at' => $now,
    'expires_at' => $now + $ttlSeconds,
  ]);
}

function member_access_disable(): bool {
  return member_access_write(member_access_default_store());
}

function member_access_consume_code(string $version): void {
  $store = member_access_read();
  if ($store['version'] !== '' && hash_equals($store['version'], $version)) {
    $store['password_hash'] = '';
    member_access_write($store);
  }
}

function member_session_start(): void {
  site_session_start('NETSMEMBERSESSID');
  if (empty($_SESSION['member_csrf'])) {
    $_SESSION['member_csrf'] = bin2hex(random_bytes(16));
  }
}

function member_login(string $code): bool {
  member_session_start();
  $now = time();
  $attempts = array_values(array_filter(
    (array)($_SESSION['member_failed_at'] ?? []),
    static fn($timestamp): bool => is_int($timestamp) && ($now - $timestamp) < 15 * 60
  ));
  if (count($attempts) >= 8) {
    $_SESSION['member_failed_at'] = $attempts;
    return false;
  }

  $store = member_access_read();
  if ($store['password_hash'] !== '' && password_verify($code, $store['password_hash'])) {
    $version = (string)$store['version'];
    session_regenerate_id(true);
    $_SESSION['member_logged_in'] = true;
    $_SESSION['member_access_version'] = $version;
    unset($_SESSION['member_failed_at']);
    member_access_consume_code($version);
    return true;
  }

  $attempts[] = $now;
  $_SESSION['member_failed_at'] = $attempts;
  return false;
}

function member_is_logged_in(): bool {
  member_session_start();
  if (empty($_SESSION['member_logged_in'])) {
    return false;
  }

  $store = member_access_read();
  if ($store['version'] === '' || !hash_equals($store['version'], (string)($_SESSION['member_access_version'] ?? ''))) {
    unset($_SESSION['member_logged_in'], $_SESSION['member_access_version']);
    return false;
  }
  return true;
}

function member_logout(): void {
  member_session_start();
  $_SESSION = [];
  if (ini_get('session.use_cookies')) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 3600, $params['path'], $params['domain'], (bool)$params['secure'], (bool)$params['httponly']);
  }
  session_destroy();
}

function member_track_key(array $track): string {
  $identity = (string)($track['library_id'] ?? $track['id'] ?? $track['slug'] ?? '');
  return substr(hash('sha256', $identity), 0, 24);
}

function member_status_options(): array {
  return [
    'work' => 'en travail',
    'review' => 'à écouter / relire',
    'shared' => 'version partagée',
    'approved' => 'version validée',
  ];
}

function member_status_label(string $status): string {
  $options = member_status_options();
  return $options[$status] ?? $options['work'];
}

function member_visible_tracks(): array {
  global $content;

  $library = is_array($content['track_library'] ?? null)
    ? $content['track_library']
    : (array)($content['discovery_tracks'] ?? []);

  $tracks = [];
  foreach ($library as $track) {
    if (!is_array($track) || empty($track['member_visible'])) {
      continue;
    }

    $resolved = nets_track_resolve($track);
    $audioFile = (string)($resolved['audio_file'] ?? '');
    if ($audioFile === '' || !is_file($audioFile) || !is_readable($audioFile)) {
      continue;
    }

    $tracks[] = $resolved;
  }
  return $tracks;
}

function member_find_track(string $trackId): ?array {
  foreach (member_visible_tracks() as $track) {
    if ((string)($track['id'] ?? '') === $trackId || (string)($track['slug'] ?? '') === $trackId) {
      return $track;
    }
  }
  return null;
}