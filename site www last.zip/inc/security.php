<?php
declare(strict_types=1);

function site_is_https(): bool {
    if (!empty($_SERVER['HTTPS']) && strtolower((string)$_SERVER['HTTPS']) !== 'off') {
        return true;
    }
    if (isset($_SERVER['SERVER_PORT']) && (string)$_SERVER['SERVER_PORT'] === '443') {
        return true;
    }
    if (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && strtolower((string)$_SERVER['HTTP_X_FORWARDED_PROTO']) === 'https') {
        return true;
    }
    return false;
}

function site_send_security_headers(): void {
    if (headers_sent()) {
        return;
    }
    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: DENY');
    header('X-Robots-Tag: noindex, nofollow, noarchive, noimageindex');
    header('X-Permitted-Cross-Domain-Policies: none');
    header('Referrer-Policy: no-referrer');
    header('Permissions-Policy: camera=(), microphone=(), geolocation=()');
    header("Content-Security-Policy: default-src 'self'; base-uri 'self'; form-action 'self'; frame-ancestors 'none'; object-src 'none'; img-src 'self' data:; media-src 'self'; script-src 'self'; style-src 'self';");
    if (site_is_https()) {
        header('Strict-Transport-Security: max-age=31536000; includeSubDomains');
    }
}

function site_session_save_dir(): string {
    $candidates = [__DIR__ . '/../data/sessions'];

    if (DIRECTORY_SEPARATOR === '\\') {
        $userProfile = getenv('USERPROFILE') ?: (string)($_SERVER['USERPROFILE'] ?? '');
        if ($userProfile !== '') {
            $candidates[] = rtrim($userProfile, "\\/") . '\\Documents\\nets-musique-sessions';
        }
        $candidates[] = 'C:\\tmp\\nets-musique-sessions';
    }

    $tmp = rtrim(sys_get_temp_dir(), "\\/");
    if ($tmp !== '') {
        $candidates[] = $tmp . DIRECTORY_SEPARATOR . 'nets-musique-sessions';
    }

    foreach ($candidates as $dir) {
        if (!is_dir($dir)) {
            @mkdir($dir, 0775, true);
        }
        if (is_dir($dir) && is_writable($dir)) {
            return $dir;
        }
    }

    return (string)session_save_path();
}

function site_session_start(string $name = 'NETSSESSID'): void {
    if (session_status() === PHP_SESSION_ACTIVE) {
        return;
    }

    session_name($name);
    $saveDir = site_session_save_dir();
    if (is_dir($saveDir) && is_writable($saveDir)) {
        session_save_path($saveDir);
    }

    $params = [
        'lifetime' => 0,
        'path' => '/',
        'domain' => '',
        'secure' => site_is_https(),
        'httponly' => true,
        'samesite' => 'Lax',
    ];

    if (PHP_VERSION_ID >= 70300) {
        session_set_cookie_params($params);
    } else {
        session_set_cookie_params(
            $params['lifetime'],
            $params['path'] . '; samesite=' . $params['samesite'],
            $params['domain'],
            $params['secure'],
            $params['httponly']
        );
    }

    session_start();
}
