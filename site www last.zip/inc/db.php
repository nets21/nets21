<?php
declare(strict_types=1);

require_once __DIR__ . '/mail.php';

function guestbook_storage_path(): string {
  $dir = __DIR__ . '/../data';
  if (!is_dir($dir)) {
    @mkdir($dir, 0755, true);
  }
  $path = $dir . '/guestbook.json';
  if (!file_exists($path)) {
    file_put_contents($path, json_encode(['next_id' => 1, 'entries' => []], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
  }
  return $path;
}

function guestbook_read_store(): array {
  $path = guestbook_storage_path();
  $raw = file_get_contents($path);
  $data = json_decode((string)$raw, true);
  if (!is_array($data) || !isset($data['entries']) || !is_array($data['entries'])) {
    $data = ['next_id' => 1, 'entries' => []];
  }
  if (!isset($data['next_id']) || !is_int($data['next_id'])) {
    $maxId = 0;
    foreach ($data['entries'] as $entry) {
      $maxId = max($maxId, (int)($entry['id'] ?? 0));
    }
    $data['next_id'] = $maxId + 1;
  }
  return $data;
}

function guestbook_write_store(array $data): void {
  $path = guestbook_storage_path();
  $json = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
  if ($json === false) {
    throw new RuntimeException('Unable to encode guestbook data.');
  }
  file_put_contents($path, $json, LOCK_EX);
}

function guestbook_label_options(): array {
  return [
    'presence' => '@presence',
    'ecoute' => '@ecoute',
    'question' => '@question',
    'idee' => '@idee',
    'constructif' => '@constructif',
    'contact' => '@contact',
  ];
}

function guestbook_label_descriptions(): array {
  return [
    'presence' => 'Laisser une trace simple après passage ou écoute.',
    'ecoute' => 'Retour centré sur un morceau, une session ou une impression sonore.',
    'question' => 'Demande claire, précision ou échange à ouvrir.',
    'idee' => 'Piste, proposition, intuition ou association possible.',
    'constructif' => 'Retour critique mais utile, à lire tranquillement.',
    'contact' => 'Signal plus direct, sans publier d’adresse personnelle.',
  ];
}

function guestbook_normalize_label(?string $label): string {
  $key = strtolower(trim((string)$label));
  $key = ltrim($key, '@');
  return array_key_exists($key, guestbook_label_options()) ? $key : 'presence';
}

function guestbook_entry_label(array $entry): string {
  return guestbook_normalize_label((string)($entry['label'] ?? 'presence'));
}

function guestbook_label_text(?string $label): string {
  $key = guestbook_normalize_label($label);
  $options = guestbook_label_options();
  return $options[$key] ?? $options['presence'];
}

function db_text_limit(string $text, int $limit): string {
  if (function_exists('mb_strlen') && function_exists('mb_substr')) {
    return mb_strlen($text) > $limit ? (string)mb_substr($text, 0, $limit) : $text;
  }
  return strlen($text) > $limit ? substr($text, 0, $limit) : $text;
}

function guestbook_normalize_email(?string $email): ?string {
  $email = trim((string)$email);
  if ($email === '') {
    return null;
  }
  $email = db_text_limit($email, 160);
  return filter_var($email, FILTER_VALIDATE_EMAIL) ? $email : null;
}

function guestbook_entry_email(array $entry): ?string {
  return guestbook_normalize_email((string)($entry['email'] ?? ''));
}

function guestbook_post(string $name, string $body, string $ip, string $label = 'presence', string $email = ''): bool {
  $name = trim($name);
  $body = trim($body);
  if ($name === '' || $body === '') {
    return false;
  }

  $name = db_text_limit($name, 40);
  $body = db_text_limit($body, 1200);
  $label = guestbook_normalize_label($label);
  $emailRaw = trim($email);
  $email = guestbook_normalize_email($emailRaw);
  if ($emailRaw !== '' && $email === null) {
    return false;
  }

  $store = guestbook_read_store();
  $now = time();
  foreach (array_reverse($store['entries']) as $entry) {
    if (($entry['ip'] ?? '') === $ip && ($now - (int)($entry['created_at'] ?? 0)) < 30) {
      return false;
    }
  }

  $entry = [
    'id' => (int)$store['next_id'],
    'name' => $name,
    'body' => $body,
    'label' => $label,
    'email' => $email,
    'reply_body' => null,
    'status' => 'pending',
    'ip' => $ip,
    'created_at' => $now,
    'approved_at' => null,
    'replied_at' => null,
  ];
  $store['entries'][] = $entry;
  $store['next_id']++;
  guestbook_write_store($store);

  // La notification ne doit jamais faire perdre le message conserve dans les coulisses.
  site_send_guestbook_notification($entry);
  return true;
}

function guestbook_public_entries(int $limit = 30): array {
  $entries = array_values(array_filter(guestbook_read_store()['entries'], static function (array $entry): bool {
    return (string)($entry['status'] ?? '') === 'approved';
  }));
  usort($entries, static function (array $a, array $b): int {
    return ((int)($b['approved_at'] ?? 0) <=> (int)($a['approved_at'] ?? 0)) ?: ((int)($b['id'] ?? 0) <=> (int)($a['id'] ?? 0));
  });
  return array_slice($entries, 0, $limit);
}

function guestbook_pending_entries(): array {
  $entries = array_values(array_filter(guestbook_read_store()['entries'], static function (array $entry): bool {
    return (string)($entry['status'] ?? '') === 'pending';
  }));
  usort($entries, static fn(array $a, array $b): int => (int)($b['id'] ?? 0) <=> (int)($a['id'] ?? 0));
  return $entries;
}

function guestbook_approved_entries_admin(): array {
  return guestbook_public_entries(100);
}

function guestbook_approve(int $id): void {
  $store = guestbook_read_store();
  foreach ($store['entries'] as &$entry) {
    if ((int)($entry['id'] ?? 0) === $id) {
      $entry['status'] = 'approved';
      $entry['approved_at'] = time();
      break;
    }
  }
  unset($entry);
  guestbook_write_store($store);
}

function guestbook_delete(int $id): void {
  $store = guestbook_read_store();
  $store['entries'] = array_values(array_filter($store['entries'], static function (array $entry) use ($id): bool {
    return (int)($entry['id'] ?? 0) !== $id;
  }));
  guestbook_write_store($store);
}

function admin_guestbook_stats(): array {
  $store = guestbook_read_store();
  $stats = [
    'total'    => 0,
    'pending'  => 0,
    'approved' => 0,
    'replied'  => 0,
    'last_mod' => 0,
    'labels'   => array_fill_keys(array_keys(guestbook_label_options()), 0),
  ];
  foreach ($store['entries'] as $entry) {
    $stats['total']++;
    $label = guestbook_entry_label($entry);
    if (isset($stats['labels'][$label])) {
      $stats['labels'][$label]++;
    }
    $status = (string)($entry['status'] ?? '');
    if ($status === 'pending')  { $stats['pending']++; }
    if ($status === 'approved') { $stats['approved']++; }
    if (!empty($entry['reply_body'])) { $stats['replied']++; }
    foreach (['created_at', 'approved_at', 'replied_at'] as $k) {
      $t = (int)($entry[$k] ?? 0);
      if ($t > $stats['last_mod']) { $stats['last_mod'] = $t; }
    }
  }
  return $stats;
}

function guestbook_reply(int $id, string $replyBody): void {
  $store = guestbook_read_store();
  $replyBody = trim($replyBody);
  foreach ($store['entries'] as &$entry) {
    if ((int)($entry['id'] ?? 0) === $id) {
      $entry['reply_body'] = $replyBody !== '' ? db_text_limit($replyBody, 1200) : null;
      $entry['replied_at'] = $replyBody !== '' ? time() : null;
      break;
    }
  }
  unset($entry);
  guestbook_write_store($store);
}
