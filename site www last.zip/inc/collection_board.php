<?php
declare(strict_types=1);

/**
 * Configuration editable du tableau de cubes de la bibliotheque.
 *
 * Les identifiants techniques restent stables afin de conserver la trace
 * locale des cubes deja ouverts dans le navigateur des visiteurs.
 */

if (!function_exists('collection_board_storage_path')) {
  function collection_board_storage_path(): string {
    return __DIR__ . '/../data/collection-board-draft.json';
  }
}

if (!function_exists('collection_board_text')) {
  function collection_board_text(mixed $value, int $maxLength): string {
    $text = trim((string)$value);
    if (function_exists('mb_substr')) {
      return mb_substr($text, 0, $maxLength);
    }
    return substr($text, 0, $maxLength);
  }
}

if (!function_exists('collection_board_defaults')) {
  function collection_board_defaults(): array {
    return [
      'schema' => 'nets.collection-board.draft/2',
      'title' => 'tableau de cubes',
      'enabled' => true,
      'draft' => true,
      'minted' => false,
      'kicker' => 'Tableau en preparation',
      'heading' => 'Des cubes, une meme piece.',
      'intro' => 'Deux albums et une session pour commencer. Le tableau pourra grandir avec la collection.',
      'mark' => 'netS',
      'placeholder_title' => 'Ouvrir un cube',
      'placeholder_text' => 'Chaque place restera stable pendant la preparation.',
      'slots' => [
        ['id' => 'album-01', 'kind' => 'album', 'label' => 'Album I', 'number' => '01', 'status' => 'reserve', 'description' => "Ce cube attend un album. Aucun son nouveau n'est fige ici aujourd'hui.", 'link_label' => 'revenir aux sons presents', 'link_url' => '#library-catalogue', 'visible' => true],
        ['id' => 'album-02', 'kind' => 'album', 'label' => 'Album II', 'number' => '02', 'status' => 'reserve', 'description' => "Ce cube attend un album. Aucun son nouveau n'est fige ici aujourd'hui.", 'link_label' => 'revenir aux sons presents', 'link_url' => '#library-catalogue', 'visible' => true],
        ['id' => 'album-03', 'kind' => 'album', 'label' => 'Album III', 'number' => '03', 'status' => 'reserve', 'description' => "Ce cube attend un album. Aucun son nouveau n'est fige ici aujourd'hui.", 'link_label' => 'revenir aux sons presents', 'link_url' => '#library-catalogue', 'visible' => false],
        ['id' => 'session-01', 'kind' => 'session', 'label' => 'Session I', 'number' => 'S1', 'status' => 'reserve', 'description' => "Ce cube attend une session. Aucun son nouveau n'est fige ici aujourd'hui.", 'link_label' => 'revenir aux sons presents', 'link_url' => '#library-catalogue', 'visible' => true],
        ['id' => 'session-02', 'kind' => 'session', 'label' => 'Session II', 'number' => 'S2', 'status' => 'reserve', 'description' => "Ce cube attend une session. Aucun son nouveau n'est fige ici aujourd'hui.", 'link_label' => 'revenir aux sons presents', 'link_url' => '#library-catalogue', 'visible' => false],
      ],
    ];
  }
}

if (!function_exists('collection_board_status_options')) {
  function collection_board_status_options(): array {
    return [
      'reserve' => 'Place reservee',
      'preparation' => 'En preparation',
      'ready' => 'Disponible',
    ];
  }
}

if (!function_exists('collection_board_safe_link')) {
  function collection_board_safe_link(mixed $value): string {
    $url = collection_board_text($value, 240);
    if ($url === '') {
      return '';
    }
    if (preg_match('~^(?:/(?!/)[^\\s]*|#[a-zA-Z0-9_-]+)$~', $url)) {
      return $url;
    }
    return filter_var($url, FILTER_VALIDATE_URL) && preg_match('~^https?://~i', $url) ? $url : '';
  }
}

if (!function_exists('collection_board_normalize')) {
  function collection_board_normalize(array $board): array {
    $defaults = collection_board_defaults();
    $normalized = $defaults;
    $normalized['enabled'] = array_key_exists('enabled', $board) ? (bool)$board['enabled'] : true;

    foreach (['title', 'kicker', 'heading', 'intro', 'mark', 'placeholder_title', 'placeholder_text'] as $field) {
      $limits = [
        'title' => 80,
        'kicker' => 80,
        'heading' => 120,
        'intro' => 400,
        'mark' => 30,
        'placeholder_title' => 80,
        'placeholder_text' => 240,
      ];
      $value = collection_board_text($board[$field] ?? $defaults[$field], $limits[$field]);
      $normalized[$field] = $value !== '' ? $value : $defaults[$field];
    }

    $normalized['draft'] = array_key_exists('draft', $board) ? (bool)$board['draft'] : true;
    $normalized['minted'] = array_key_exists('minted', $board) ? (bool)$board['minted'] : false;
    $inputSlots = is_array($board['slots'] ?? null) ? array_values($board['slots']) : $defaults['slots'];
    $slots = [];
    $seenIds = [];
    $statusOptions = collection_board_status_options();

    foreach (array_slice($inputSlots, 0, 30) as $index => $slot) {
      if (!is_array($slot)) {
        continue;
      }
      $kind = (($slot['kind'] ?? 'album') === 'session') ? 'session' : 'album';
      $id = strtolower(collection_board_text($slot['id'] ?? '', 64));
      $id = preg_replace('~[^a-z0-9-]+~', '-', $id) ?? '';
      $id = trim($id, '-');
      if ($id === '') {
        $id = $kind . '-' . str_pad((string)($index + 1), 2, '0', STR_PAD_LEFT);
      }
      if (isset($seenIds[$id])) {
        continue;
      }
      $seenIds[$id] = true;

      $label = collection_board_text($slot['label'] ?? '', 100);
      if ($label === '') {
        $label = ($kind === 'session' ? 'Session ' : 'Album ') . ($index + 1);
      }
      $number = collection_board_text($slot['number'] ?? '', 12);
      $status = (string)($slot['status'] ?? 'reserve');
      if (!array_key_exists($status, $statusOptions)) {
        $status = 'reserve';
      }

      $defaultDescription = 'Ce cube attend ' . ($kind === 'session' ? 'une session' : 'un album') . ". Aucun son nouveau n'est fige ici aujourd'hui.";
      $description = collection_board_text($slot['description'] ?? $defaultDescription, 500);
      $linkLabel = collection_board_text($slot['link_label'] ?? 'revenir aux sons presents', 100);
      $linkUrl = collection_board_safe_link($slot['link_url'] ?? '#library-catalogue');

      $slots[] = [
        'id' => $id,
        'kind' => $kind,
        'label' => $label,
        'number' => $number,
        'status' => $status,
        'description' => $description,
        'link_label' => $linkLabel,
        'link_url' => $linkUrl,
        'visible' => array_key_exists('visible', $slot) ? (bool)$slot['visible'] : true,
      ];
    }

    $normalized['slots'] = $slots;
    return $normalized;
  }
}

if (!function_exists('collection_board_add_slot')) {
  function collection_board_add_slot(array $board, string $kind = 'album'): array {
    $board = collection_board_normalize($board);
    if (count($board['slots']) >= 30) {
      return $board;
    }

    $kind = $kind === 'session' ? 'session' : 'album';
    $used = array_fill_keys(array_map(static fn(array $slot): string => (string)$slot['id'], $board['slots']), true);
    $counter = 1;
    do {
      $id = $kind . '-' . str_pad((string)$counter, 2, '0', STR_PAD_LEFT);
      $counter++;
    } while (isset($used[$id]));

    $visibleNumber = count(array_filter($board['slots'], static fn(array $slot): bool => $slot['kind'] === $kind)) + 1;
    $board['slots'][] = [
      'id' => $id,
      'kind' => $kind,
      'label' => ($kind === 'session' ? 'Session ' : 'Album ') . $visibleNumber,
      'number' => ($kind === 'session' ? 'S' : '') . $visibleNumber,
      'status' => 'reserve',
      'description' => 'Ce cube attend ' . ($kind === 'session' ? 'une session' : 'un album') . ". Aucun son nouveau n'est fige ici aujourd'hui.",
      'link_label' => 'revenir aux sons presents',
      'link_url' => '#library-catalogue',
      'visible' => false,
    ];
    return collection_board_normalize($board);
  }
}

if (!function_exists('collection_board_remove_slot')) {
  function collection_board_remove_slot(array $board, string $id): array {
    $board = collection_board_normalize($board);
    $board['slots'] = array_values(array_filter(
      $board['slots'],
      static fn(array $slot): bool => (string)$slot['id'] !== $id
    ));
    return collection_board_normalize($board);
  }
}

if (!function_exists('collection_board_read')) {
  function collection_board_read(?string $path = null): array {
    $path = $path ?? collection_board_storage_path();
    if (!is_file($path)) {
      return collection_board_defaults();
    }
    $decoded = json_decode((string)@file_get_contents($path), true);
    return is_array($decoded) ? collection_board_normalize($decoded) : collection_board_defaults();
  }
}

if (!function_exists('collection_board_from_admin_post')) {
  function collection_board_from_admin_post(array $post, array $current): array {
    $current = collection_board_normalize($current);
    $boardPost = is_array($post['board'] ?? null) ? $post['board'] : [];
    $rows = is_array($post['cube'] ?? null) ? $post['cube'] : [];

    $updated = $current;
    $updated['enabled'] = !empty($boardPost['enabled']);
    foreach (['kicker', 'heading', 'intro', 'mark', 'placeholder_title', 'placeholder_text'] as $field) {
      if (array_key_exists($field, $boardPost)) {
        $updated[$field] = $boardPost[$field];
      }
    }

    $ordered = [];
    foreach ($current['slots'] as $index => $slot) {
      $id = (string)$slot['id'];
      $row = is_array($rows[$id] ?? null) ? $rows[$id] : [];
      $slot['label'] = $row['label'] ?? $slot['label'];
      $slot['number'] = $row['number'] ?? $slot['number'];
      $slot['kind'] = $row['kind'] ?? $slot['kind'];
      $slot['status'] = $row['status'] ?? $slot['status'];
      $slot['description'] = $row['description'] ?? $slot['description'];
      $slot['link_label'] = $row['link_label'] ?? $slot['link_label'];
      $slot['link_url'] = $row['link_url'] ?? $slot['link_url'];
      $slot['visible'] = !empty($row['visible']);
      $position = filter_var($row['position'] ?? ($index + 1), FILTER_VALIDATE_INT);
      $ordered[] = [
        'position' => $position !== false ? max(1, min(99, (int)$position)) : ($index + 1),
        'original' => $index,
        'slot' => $slot,
      ];
    }
    usort($ordered, static fn(array $a, array $b): int => [$a['position'], $a['original']] <=> [$b['position'], $b['original']]);
    $updated['slots'] = array_column($ordered, 'slot');
    return collection_board_normalize($updated);
  }
}

if (!function_exists('collection_board_write')) {
  function collection_board_write(array $board, ?string $path = null): bool {
    $path = $path ?? collection_board_storage_path();
    $directory = dirname($path);
    if (!is_dir($directory) || !is_writable($directory)) {
      return false;
    }
    $normalized = collection_board_normalize($board);
    $json = json_encode($normalized, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
    if ($json === false) {
      return false;
    }
    $temporary = $path . '.tmp.' . bin2hex(random_bytes(4));
    if (file_put_contents($temporary, $json . PHP_EOL, LOCK_EX) === false) {
      return false;
    }
    @chmod($temporary, 0660);
    if (!@rename($temporary, $path)) {
      @unlink($temporary);
      return false;
    }
    return true;
  }
}
