<?php
declare(strict_types=1);

/** Reserve une tentative sous verrou, independamment du cookie de session.
 * Les adresses brutes ne sont jamais ecrites; les cles expirees sont purgees.
 */
function site_rate_limit_allow(string $scope, int $clientLimit, int $clientWindow, int $globalLimit, int $globalWindow): bool {
  if (!preg_match('/^[a-z-]+$/D', $scope) || min($clientLimit, $clientWindow, $globalLimit, $globalWindow) < 1) {
    return false;
  }
  $path = __DIR__ . '/../data/security-rate-' . $scope . '.json';
  $handle = @fopen($path, 'c+');
  if ($handle === false) {
    return false;
  }
  try {
    if (!flock($handle, LOCK_EX)) {
      return false;
    }
    rewind($handle);
    $raw = stream_get_contents($handle);
    if ($raw === false) {
      return false;
    }
    if ($raw === '') {
      $store = ['salt' => bin2hex(random_bytes(32)), 'events' => []];
    } else {
      $store = json_decode($raw, true);
      if (!is_array($store) || !is_string($store['salt'] ?? null)
          || !preg_match('/^[a-f0-9]{64}$/D', $store['salt']) || !is_array($store['events'] ?? null)) {
        return false;
      }
    }
    $now = time();
    $retention = max($clientWindow, $globalWindow);
    $events = [];
    foreach ($store['events'] as $event) {
      if (!is_array($event) || !is_int($event['at'] ?? null) || !is_string($event['key'] ?? null)
          || !preg_match('/^[a-f0-9]{64}$/D', $event['key'])) {
        return false;
      }
      if ($event['at'] > $now - $retention) {
        $events[] = $event;
      }
    }
    if ($events === []) {
      $store['salt'] = bin2hex(random_bytes(32));
    }
    // Ne pas faire confiance aux en-tetes Forwarded/X-Forwarded-For du client.
    $address = (string)($_SERVER['REMOTE_ADDR'] ?? '');
    $packed = @inet_pton($address);
    $key = hash_hmac('sha256', $packed !== false ? $packed : 'unknown', $store['salt']);
    $clientCount = 0;
    $globalCount = 0;
    foreach ($events as $event) {
      if ($event['at'] > $now - $globalWindow) {
        $globalCount++;
      }
      if ($event['at'] > $now - $clientWindow && hash_equals($event['key'], $key)) {
        $clientCount++;
      }
    }
    $allowed = $clientCount < $clientLimit && $globalCount < $globalLimit;
    if ($allowed) {
      $events[] = ['at' => $now, 'key' => $key];
    }
    $store['events'] = $events;
    $json = json_encode($store, JSON_UNESCAPED_SLASHES);
    if ($json === false) {
      return false;
    }
    rewind($handle);
    if (!ftruncate($handle, 0) || fwrite($handle, $json) !== strlen($json) || !fflush($handle)) {
      return false;
    }
    return $allowed;
  } finally {
    @flock($handle, LOCK_UN);
    fclose($handle);
  }
}
