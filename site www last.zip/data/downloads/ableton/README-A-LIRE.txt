Fichiers Ableton associes aux morceaux.

Convention :
- le fragment reste une ecoute autonome ;
- la session Ableton est un objet distinct avec ce morceau comme piste ;
- un fichier zip par session associee au morceau ;
- nom du zip = slug du morceau ;
- exemple : fragment_001 -> /downloads/ableton/sessions/fragment_001.zip.

Le site affiche un lien de session seulement quand le zip existe.
Ne pas mettre ici de brouillons inutiles, de mots de passe ou de fichiers personnels.
