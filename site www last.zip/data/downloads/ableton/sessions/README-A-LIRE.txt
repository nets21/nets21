Sessions Ableton associees aux morceaux.

Nom attendu :
{slug-du-morceau}.zip

Exemple :
fragment_001.zip

Le fragment audio reste autonome. Ce zip correspond a une session Ableton distincte dans laquelle le morceau existe comme piste de travail.
