README POUR LES ENVOIS MANUELS
==============================

Merci pour votre soutien et votre ecoute.

Ce dossier ne correspond pas a une livraison automatique.
Un envoi propre peut etre fait au cas par cas, manuellement, pour une personne identifiee, un retour suivi ou un soutien reel.

Merci de respecter le travail, le temps et l'ecoute.

Contact : via nets-musique.digital/chat.php
