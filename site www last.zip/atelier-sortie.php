<?php
declare(strict_types=1);

define('NETS_ATELIER_ENTRY', true);
header('Location: /coulisses-sortie.php', true, 302);
exit;
