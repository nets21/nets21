<?php
declare(strict_types=1);
require_once __DIR__ . '/inc/site.php';
$title = 'Écoute & soutien';
ob_start(); ?>
<section class="panel"><h1>Écoute & soutien</h1><div class="prose"><?php site_paragraphs($content['support_lines']); ?></div>
<div class="cta"><a class="btn support-btn" href="<?= site_h($site['buymeacoffee_url']) ?>" target="_blank" rel="noopener">M’offrir un café</a>
<?php $cardUrl = trim((string)($content['card_payment_url'] ?? '')); if (preg_match('~^https://buy\.stripe\.com/[A-Za-z0-9_/-]+$~D', $cardUrl)): ?><a class="btn ghost" href="<?= site_h($cardUrl) ?>" target="_blank" rel="noopener">M’offrir un café — par carte</a><?php endif; ?>
<a class="btn ghost" href="/salon.php">Échanger · 7J</a></div></section>
<div class="cta"><a href="/preuves.php">Preuves de date</a></div>
<?php $page_content = ob_get_clean(); include __DIR__ . '/inc/layout.php';
