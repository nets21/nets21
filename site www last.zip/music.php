<?php
declare(strict_types=1);
require_once __DIR__ . '/inc/site.php';
$title = 'Parcours d’écoute'; ob_start(); ?>
<section class="panel"><h1>Parcours d’écoute</h1><div class="prose"><?php site_paragraphs($content['fragments_intro_lines']); site_paragraphs($content['sessions_intro_lines']); ?></div><div class="cta"><a class="btn" href="/fragments.php">Fragments rouges</a><a class="btn ghost" href="/sessions.php">Sessions bleues</a><a class="btn ghost" href="/biographie.php">Mon parcours musical</a></div></section>
<?php $page_content = ob_get_clean(); include __DIR__ . '/inc/layout.php';
