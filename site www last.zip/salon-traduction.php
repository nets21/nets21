<?php
declare(strict_types=1);
require_once __DIR__ . '/inc/security.php';
require_once __DIR__ . '/inc/week_chat.php';
require_once __DIR__ . '/inc/chat_translation.php';
site_send_security_headers();
header('Content-Type: application/json; charset=UTF-8');
header('Cache-Control: no-store');
if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') { header('Allow: POST'); http_response_code(405); exit('{}'); }
site_session_start('NETSWEEKCHAT');
$csrf = $_POST['csrf'] ?? null;
if (!is_string($csrf) || $csrf === '' || !hash_equals((string)($_SESSION['week_chat_csrf'] ?? ''), $csrf)) { http_response_code(403); exit('{}'); }
session_write_close();
$target = $_POST['target'] ?? null;
$ids = $_POST['ids'] ?? null;
if (!is_string($target) || !isset(chat_translation_languages()[$target]) || !is_array($ids) || count($ids) < 1 || count($ids) > 20) { http_response_code(400); exit('{}'); }
foreach ($ids as $id) { if (!is_string($id) || !ctype_digit($id) || strlen($id) > 10) { http_response_code(400); exit('{}'); } }
if (!chat_translation_ready()) { http_response_code(503); exit('{"status":"unavailable","translations":{}}'); }
if (!site_rate_limit_allow('chat-translation', 20, 60, 60, 60)) { http_response_code(429); exit('{"status":"limited","translations":{}}'); }
$wanted = array_fill_keys(array_map('intval', $ids), true);
$messages = array_values(array_filter(week_chat_messages(), static fn($message)=>isset($wanted[(int)($message['id'] ?? 0)])));
echo json_encode(chat_translate_messages($messages, $target), JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
