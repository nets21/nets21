<?php
declare(strict_types=1);

define('NETS_ATELIER_ENTRY', true);
header('Location: /coulisses-presences.php', true, 302);
exit;
