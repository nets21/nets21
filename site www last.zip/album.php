<?php
declare(strict_types=1);
require_once __DIR__ . '/inc/site.php';
$title = 'La paix de netsA';
ob_start(); ?>
<section class="panel"><h1><?= site_h($content['album_title']) ?></h1><img class="album-cover" src="/assets/covers/la-paix-de-netsa.webp" alt="Jaquette de La paix de netsA : un arbre massif et touffu"><div class="prose"><?php site_paragraphs($content['album_lines']); ?></div><a class="btn ghost" href="/bibliotheque.php">Revenir aux écoutes</a></section>
<?php $page_content = ob_get_clean(); include __DIR__ . '/inc/layout.php';
