(function () {
  document.addEventListener('submit', function (event) {
    var form = event.target;
    if (!form || !form.matches) return;

    if (form.matches('form[data-confirm]')) {
      var message = form.getAttribute('data-confirm') || 'Confirmer cette action ?';
      if (!window.confirm(message)) {
        event.preventDefault();
        return;
      }
    }

    if (form.id === 'library-import-form') {
      var button = form.querySelector('button[type="submit"]');
      if (button) {
        button.disabled = true;
        button.textContent = 'Import en cours...';
      }
    }
  });

  var form = document.getElementById('library-import-form');
  var fileInput = document.getElementById('library-audio');
  var titleInput = document.getElementById('library-title');
  var kindInput = document.getElementById('library-kind');
  var durationInput = document.getElementById('library-duration-seconds');
  var summary = document.getElementById('library-import-summary');

  if (!form || !fileInput || !durationInput || !summary) return;

  function formatBytes(bytes) {
    if (bytes >= 1024 * 1024 * 1024) return (bytes / (1024 * 1024 * 1024)).toFixed(1) + ' Go';
    if (bytes >= 1024 * 1024) return (bytes / (1024 * 1024)).toFixed(1) + ' Mo';
    return Math.max(1, Math.ceil(bytes / 1024)) + ' Ko';
  }

  function approximateDuration(seconds, kind) {
    if (!isFinite(seconds) || seconds <= 0) {
      return kind === 'session' ? 'environ 1 h' : 'environ 5 min';
    }
    var minutes = Math.max(1, Math.round(seconds / 60));
    if (minutes < 60) return 'environ ' + minutes + ' min';
    var hours = Math.floor(minutes / 60);
    var rest = minutes % 60;
    return 'environ ' + hours + ' h' + (rest ? ' ' + rest + ' min' : '');
  }

  function updateSummary(file, seconds) {
    if (!file) {
      summary.textContent = 'Le son sera importe inactif, puis verrouille.';
      return;
    }
    var kind = kindInput ? kindInput.value : 'fragment';
    summary.textContent = file.name + ' - ' + formatBytes(file.size) + ' - '
      + approximateDuration(seconds, kind)
      + '. Import inactif et verrouille.';
  }

  function inspectFile() {
    var file = fileInput.files && fileInput.files[0] ? fileInput.files[0] : null;
    durationInput.value = '';
    if (!file) {
      updateSummary(null, 0);
      return;
    }


    updateSummary(file, 0);
    var audio = document.createElement('audio');
    var objectUrl = URL.createObjectURL(file);
    audio.preload = 'metadata';
    audio.addEventListener('loadedmetadata', function () {
      var seconds = isFinite(audio.duration) ? audio.duration : 0;
      durationInput.value = seconds > 0 ? String(seconds) : '';
      updateSummary(file, seconds);
      URL.revokeObjectURL(objectUrl);
    }, { once: true });
    audio.addEventListener('error', function () {
      URL.revokeObjectURL(objectUrl);
    }, { once: true });
    audio.src = objectUrl;
  }

  fileInput.addEventListener('change', inspectFile);
  if (kindInput) {
    kindInput.addEventListener('change', function () {
      if (titleInput) titleInput.placeholder = kindInput.value === 'session' ? 'Session' : 'Morceau';
      var file = fileInput.files && fileInput.files[0] ? fileInput.files[0] : null;
      updateSummary(file, parseFloat(durationInput.value || '0'));
    });
  }
})();
