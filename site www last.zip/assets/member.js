(function () {
  var audio = document.getElementById('member-audio');
  if (!audio) return;

  var buttons = Array.from(document.querySelectorAll('[data-member-track]'));
  var toggle = document.getElementById('member-toggle');
  var progress = document.getElementById('member-progress');
  var volume = document.getElementById('member-volume');
  var current = document.getElementById('member-current');
  var duration = document.getElementById('member-duration');
  var title = document.getElementById('member-player-title');
  var version = document.getElementById('member-player-version');
  var note = document.getElementById('member-player-note');
  var selected = null;

  function formatTime(seconds) {
    if (!Number.isFinite(seconds) || seconds < 0) return '00:00';
    var minutes = Math.floor(seconds / 60);
    var rest = Math.floor(seconds % 60);
    return String(minutes).padStart(2, '0') + ':' + String(rest).padStart(2, '0');
  }

  function updateButtons() {
    buttons.forEach(function (button) {
      var active = selected && button === selected;
      button.classList.toggle('is-playing', Boolean(active && !audio.paused));
      button.textContent = active && !audio.paused ? 'en lecture' : 'écouter cette version';
    });
  }

  function updateProgress() {
    var total = Number.isFinite(audio.duration) ? audio.duration : 0;
    var position = Number.isFinite(audio.currentTime) ? audio.currentTime : 0;
    current.textContent = formatTime(position);
    duration.textContent = formatTime(total);
    progress.value = total > 0 ? String(Math.round(position / total * 1000)) : '0';
  }

  function selectTrack(button, autoplay) {
    selected = button;
    title.textContent = button.getAttribute('data-member-title') || 'Version de travail';
    version.textContent = button.getAttribute('data-member-version') || '';
    note.textContent = button.getAttribute('data-member-note') || '';
    audio.src = button.getAttribute('data-member-src') || '';
    audio.load();
    toggle.disabled = false;
    progress.disabled = false;
    updateButtons();

    if (autoplay) {
      audio.play().catch(function () {
        updateButtons();
      });
    }
  }

  buttons.forEach(function (button) {
    button.addEventListener('click', function () {
      if (selected === button) {
        if (audio.paused) {
          audio.play().catch(function () {});
        } else {
          audio.pause();
        }
        return;
      }
      selectTrack(button, true);
    });
  });

  toggle.addEventListener('click', function () {
    if (!selected) return;
    if (audio.paused) {
      audio.play().catch(function () {});
    } else {
      audio.pause();
    }
  });

  progress.addEventListener('input', function () {
    if (!Number.isFinite(audio.duration) || audio.duration <= 0) return;
    audio.currentTime = Number(progress.value) / 1000 * audio.duration;
  });

  volume.addEventListener('input', function () {
    audio.volume = Math.max(0, Math.min(1, Number(volume.value) / 100));
  });

  audio.addEventListener('loadedmetadata', updateProgress);
  audio.addEventListener('timeupdate', updateProgress);
  audio.addEventListener('play', function () {
    toggle.textContent = 'pause';
    updateButtons();
  });
  audio.addEventListener('pause', function () {
    toggle.textContent = 'lecture';
    updateButtons();
  });
  audio.addEventListener('ended', function () {
    toggle.textContent = 'lecture';
    progress.value = '0';
    updateButtons();
  });
  audio.addEventListener('error', function () {
    note.textContent = 'Cette version ne peut pas être chargée pour le moment.';
    toggle.textContent = 'lecture';
    updateButtons();
  });
})();