/* === Menu : trace jaune de la dernière page visitée ===================== */
(function () {
  try {
    var MEM_KEY = 'nets-menu-last-path';
    var currentPath = (location.pathname || '/').replace(/\/+$/, '') || '/';
    var lastPath = null;
    try { lastPath = sessionStorage.getItem(MEM_KEY); } catch (_) {}
    var links = document.querySelectorAll('.menu a[href]');
    links.forEach(function (a) {
      var href = a.getAttribute('href') || '';
      // on ne traite que les liens internes débutant par /
      if (href.charAt(0) !== '/') return;
      var linkPath = href.replace(/\/+$/, '') || '/';
      // page courante : déjà gérée par aria-current côté PHP, rien à faire
      if (linkPath === currentPath) return;
      // dernière page visitée : on pose .is-last (trace qui s'estompe)
      if (lastPath && linkPath === lastPath) a.classList.add('is-last');
    });
    // mémorise la page courante pour la prochaine navigation
    try { sessionStorage.setItem(MEM_KEY, currentPath); } catch (_) {}
  } catch (_) {}
})();

(function () {
  const playlistDataNode = document.getElementById('site-playlist-data');
  let playlist = [];
  try {
    playlist = playlistDataNode ? JSON.parse(playlistDataNode.textContent || '[]') : [];
  } catch (_) {
    playlist = [];
  }
  if (!Array.isArray(playlist)) playlist = [];
  const playlistById = new Map(playlist.map((track, index) => [track.id, { ...track, index }]));
  const bodyShell = document.querySelector('.site-shell');
  const main = document.getElementById('site-main');
  const audio = document.getElementById('global-player');
  const titleEl = document.getElementById('player-title');
  const subtitleEl = document.getElementById('player-subtitle');
  const kindEl = document.getElementById('player-kind');
  const coverEl = document.getElementById('player-cover');
  const supportEl = document.getElementById('player-support');
  const toggleBtn = document.getElementById('player-toggle');
  const prevBtn = document.getElementById('player-prev');
  const nextBtn = document.getElementById('player-next');
  const progressBar = document.getElementById('player-progress-bar');
  const timeCurrent = document.getElementById('player-time-current');
  const timeTotal = document.getElementById('player-time-total');
  const wordsEl = document.getElementById('player-words');
  const wordMarksEl = document.getElementById('player-word-marks');
  const playerDock = document.getElementById('player-dock');
  const defaultCover = coverEl
    ? (coverEl.getAttribute('data-default-cover') || coverEl.getAttribute('src') || '/assets/covers/default.svg')
    : '/assets/covers/default.svg';
  let currentWordIndex = -1;  // index de la parole actuellement affichée (-1 = aucune)
  const storageKey = 'nets-player-state-v1';
  const privatePaths = new Set([
    '/atelier.php',
    '/atelier-espace.php',
    '/atelier-livre-dor.php',
    '/atelier-notes.php',
    '/atelier-sortie.php',
    '/membre.php',
    '/membre-sortie.php'
  ]);
  let currentTrackId = null;

  if (coverEl) {
    coverEl.addEventListener('error', function () {
      if (coverEl.getAttribute('src') !== defaultCover) {
        coverEl.src = defaultCover;
      }
    });
  }

  function isPrivatePath(pathname) {
    return pathname.startsWith('/admin/') || pathname.startsWith('/coulisses') || privatePaths.has(pathname);
  }

  function formatTime(seconds) {
    if (!Number.isFinite(seconds)) return '00:00';
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return String(mins).padStart(2, '0') + ':' + String(secs).padStart(2, '0');
  }

  function applyTrackGain(track) {
    const gainDb = Number(track && track.playback_gain_db);
    const safeGainDb = Number.isFinite(gainDb) ? Math.max(-24, Math.min(0, gainDb)) : 0;
    audio.volume = Math.pow(10, safeGainDb / 20);
  }

  function saveState() {
    if (!currentTrackId) return;
    try {
      sessionStorage.setItem(storageKey, JSON.stringify({
        trackId: currentTrackId,
        currentTime: audio.currentTime || 0,
        paused: audio.paused,
      }));
    } catch (_) {}
  }

  function updateButtons() {
    document.querySelectorAll('[data-track-id]').forEach((button) => {
      const active = button.getAttribute('data-track-id') === currentTrackId;
      button.classList.toggle('active-track', active);
    });
  }

  function updatePlayerText(track) {
    const info = document.getElementById('player-info');
    const infoText = document.getElementById('player-info-text');
    if (info && infoText) {
      infoText.textContent = track ? (track.track_note || '') : '';
      info.hidden = !infoText.textContent.trim();
      info.open = false;
    }
    if (!track) {
      titleEl.textContent = 'Sélectionne un morceau';
      subtitleEl.textContent = 'Ecouter, c\'est parfois jouer avec nous.';
      kindEl.textContent = 'écoute';
      if (coverEl) {
        coverEl.src = defaultCover;
        coverEl.alt = 'Jaquette neutre du site';
      }
      hideWord();
      renderWordMarks(null);
      if (playerDock) playerDock.classList.remove('is-session', 'is-fragment');
      return;
    }
    titleEl.textContent = track.title || 'Morceau';
    subtitleEl.textContent = track.player_subtitle || track.subtitle || '';
    const kindLabel = track.kind === 'session' ? '● Session' : '● Morceau';
    kindEl.textContent = kindLabel;
    if (coverEl) {
      coverEl.src = track.cover || defaultCover;
      coverEl.alt = 'Jaquette de ' + (track.title || 'ce morceau');
    }
    if (supportEl) {
      supportEl.href = track.support_url || supportEl.href;
      supportEl.setAttribute('aria-label', 'Soutenir ' + (track.title || 'ce morceau'));
    }
    if (playerDock) {
      playerDock.classList.toggle('is-session', track.kind === 'session');
      playerDock.classList.toggle('is-fragment', track.kind === 'fragment');
    }
    renderWordMarks(track);
    hideWord();
  }

  /* === Paroles écrites au lieu du chant ================================= */
  function hideWord() {
    if (!wordsEl) return;
    wordsEl.classList.remove('is-active');
    wordsEl.textContent = '';
    currentWordIndex = -1;
  }
  function showWord(index, text) {
    if (!wordsEl) return;
    if (index === currentWordIndex && wordsEl.textContent === text) return;
    wordsEl.textContent = text;
    wordsEl.classList.add('is-active');
    currentWordIndex = index;
  }
  function renderWordMarks(track) {
    if (!wordMarksEl) return;
    wordMarksEl.innerHTML = '';
    if (!track || !Array.isArray(track.words) || !track.words.length) return;
    const dur = audio.duration;
    if (!Number.isFinite(dur) || dur <= 0) return;
    track.words.forEach((w) => {
      const t = Number(w.t) || 0;
      if (t < 0 || t > dur) return;
      const mark = document.createElement('span');
      mark.className = 'word-mark';
      mark.style.left = (t / dur * 100) + '%';
      wordMarksEl.appendChild(mark);
    });
  }
  function updateWords() {
    const track = currentTrack();
    if (!track || !Array.isArray(track.words) || !track.words.length) {
      hideWord();
      return;
    }
    const t = audio.currentTime || 0;
    // Trouve la parole active : t >= w.t et t < w.t + w.d
    let active = -1;
    for (let i = 0; i < track.words.length; i++) {
      const w = track.words[i];
      const start = Number(w.t) || 0;
      const dur = Number(w.d) || 6;
      if (t >= start && t < start + dur) { active = i; break; }
    }
    if (active === -1) {
      if (currentWordIndex !== -1) hideWord();
    } else {
      showWord(active, track.words[active].text);
    }
    // Marqueurs : surligne ceux qu'on approche (± 0.8s)
    if (wordMarksEl) {
      const marks = wordMarksEl.querySelectorAll('.word-mark');
      marks.forEach((m, i) => {
        const w = track.words[i];
        if (!w) return;
        const start = Number(w.t) || 0;
        const near = Math.abs(t - start) < 0.8;
        m.classList.toggle('is-near', near);
      });
    }
  }

  function loadTrack(trackId, options = {}) {
    const track = playlistById.get(trackId);
    if (!track) return;
    const sameTrack = currentTrackId === track.id;
    currentTrackId = track.id;
    updatePlayerText(track);
    updateButtons();
    applyTrackGain(track);

    if (!sameTrack || audio.getAttribute('data-track-id') !== track.id) {
      audio.src = track.audio;
      audio.setAttribute('data-track-id', track.id);
      audio.load();
    }

    if (typeof options.currentTime === 'number') {
      audio.currentTime = options.currentTime;
    }

    if (options.autoplay) {
      const playPromise = audio.play();
      if (playPromise && typeof playPromise.catch === 'function') {
        playPromise.catch(() => {
          toggleBtn.textContent = 'lecture';
        });
      }
    }
    saveState();
  }

  function currentTrack() {
    return currentTrackId ? playlistById.get(currentTrackId) : null;
  }

  function loadRelativeTrack(direction) {
    if (!playlist.length) return;
    const current = currentTrack();
    let nextIndex = 0;
    if (current) {
      nextIndex = current.index + direction;
      if (nextIndex < 0) nextIndex = playlist.length - 1;
      if (nextIndex >= playlist.length) nextIndex = 0;
    }
    loadTrack(playlist[nextIndex].id, { autoplay: true });
  }

  function restoreState() {
    try {
      const raw = sessionStorage.getItem(storageKey);
      if (!raw) return false;
      const state = JSON.parse(raw);
      if (!state || !state.trackId || !playlistById.has(state.trackId)) return false;
      loadTrack(state.trackId, { currentTime: Number(state.currentTime) || 0, autoplay: !state.paused });
      return true;
    } catch (_) {
      return false;
    }
  }

  function syncUi() {
    toggleBtn.textContent = audio.paused ? 'lecture' : 'pause';
    progressBar.style.width = audio.duration ? ((audio.currentTime / audio.duration) * 100) + '%' : '0%';
    timeCurrent.textContent = formatTime(audio.currentTime);
    timeTotal.textContent = formatTime(audio.duration);
    updateWords();
    saveState();
  }

  function normalizeLibraryText(value) {
    return String(value || '')
      .toLocaleLowerCase('fr')
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/\s+/g, ' ')
      .trim();
  }

  function initLibraryUi() {
    const catalogue = document.querySelector('[data-library-catalogue]');
    if (!catalogue || catalogue.dataset.libraryBound === '1') return;
    catalogue.dataset.libraryBound = '1';

    const search = catalogue.querySelector('[data-library-search]');
    const filters = Array.from(catalogue.querySelectorAll('[data-library-filter]'));
    const items = Array.from(catalogue.querySelectorAll('[data-library-item]'));
    const count = catalogue.querySelector('[data-library-count]');
    const empty = catalogue.querySelector('[data-library-empty]');
    const random = document.querySelector('[data-library-random]');
    let activeFilter = 'all';

    function visibleItems() {
      return items.filter((item) => !item.hidden);
    }

    function refreshLibrary() {
      const query = normalizeLibraryText(search ? search.value : '');
      let visibleCount = 0;
      items.forEach((item) => {
        const kind = item.getAttribute('data-library-kind') || 'fragment';
        const haystack = normalizeLibraryText(item.getAttribute('data-library-search-text'));
        const matchesKind = activeFilter === 'all' || kind === activeFilter;
        const matchesQuery = query === '' || haystack.includes(query);
        item.hidden = !(matchesKind && matchesQuery);
        if (!item.hidden) visibleCount += 1;
      });
      if (count) {
        count.textContent = visibleCount + (visibleCount === 1 ? ' son visible' : ' sons visibles');
      }
      if (empty) empty.hidden = visibleCount !== 0;
      if (random) random.disabled = visibleCount === 0;
    }

    filters.forEach((filter) => {
      filter.addEventListener('click', () => {
        activeFilter = filter.getAttribute('data-library-filter') || 'all';
        filters.forEach((candidate) => {
          const active = candidate === filter;
          candidate.classList.toggle('is-active', active);
          candidate.setAttribute('aria-pressed', active ? 'true' : 'false');
        });
        refreshLibrary();
      });
    });

    if (search) search.addEventListener('input', refreshLibrary);
    if (random) {
      random.addEventListener('click', () => {
        const candidates = visibleItems();
        if (!candidates.length) return;
        const chosen = candidates[Math.floor(Math.random() * candidates.length)];
        const trigger = chosen.querySelector('[data-track-id]');
        if (trigger) trigger.click();
      });
    }

    refreshLibrary();
  }

  function initCubeBoardUi() {
    const root = document.querySelector('[data-cube-board]');
    if (!root || root.dataset.cubeBoardBound === '1') return;
    root.dataset.cubeBoardBound = '1';

    const storageKey = 'nets-cube-board-seen-v1';
    const cubes = Array.from(root.querySelectorAll('[data-cube-id]'));
    const panels = Array.from(root.querySelectorAll('[data-cube-panel]'));
    const placeholder = root.querySelector('[data-cube-placeholder]');
    const progress = root.querySelector('[data-cube-progress]');
    const reset = root.querySelector('[data-cube-reset]');
    let seen = new Set();

    try {
      const stored = JSON.parse(localStorage.getItem(storageKey) || '[]');
      if (Array.isArray(stored)) {
        const validIds = new Set(cubes.map((cube) => cube.getAttribute('data-cube-id')));
        seen = new Set(stored.filter((id) => typeof id === 'string' && validIds.has(id)));
      }
    } catch (_) {}

    function saveSeen() {
      try { localStorage.setItem(storageKey, JSON.stringify(Array.from(seen))); } catch (_) {}
    }

    function updateSeenUi() {
      cubes.forEach((cube) => {
        cube.classList.toggle('is-seen', seen.has(cube.getAttribute('data-cube-id')));
      });
      if (progress) {
        progress.textContent = seen.size + ' / ' + cubes.length + (seen.size === 1 ? ' cube ouvert sur cet appareil' : ' cubes ouverts sur cet appareil');
      }
      if (reset) reset.disabled = seen.size === 0;
    }

    function openCube(cube) {
      const cubeId = cube.getAttribute('data-cube-id') || '';
      if (cubeId === '') return;
      seen.add(cubeId);
      saveSeen();
      cubes.forEach((candidate) => {
        const active = candidate === cube;
        candidate.classList.toggle('is-active', active);
        candidate.setAttribute('aria-expanded', active ? 'true' : 'false');
      });
      panels.forEach((panel) => {
        panel.hidden = panel.getAttribute('data-cube-panel') !== cubeId;
      });
      if (placeholder) placeholder.hidden = true;
      updateSeenUi();
    }

    root.addEventListener('click', (event) => {
      const cube = event.target.closest('[data-cube-id]');
      if (cube) {
        openCube(cube);
        return;
      }
      if (event.target.closest('[data-cube-reset]')) {
        seen.clear();
        saveSeen();
        updateSeenUi();
      }
    });

    root.addEventListener('keydown', (event) => {
      const cube = event.target.closest('[data-cube-id]');
      if (!cube || !['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown'].includes(event.key)) return;
      event.preventDefault();
      const currentIndex = cubes.indexOf(cube);
      const direction = (event.key === 'ArrowLeft' || event.key === 'ArrowUp') ? -1 : 1;
      const nextIndex = (currentIndex + direction + cubes.length) % cubes.length;
      cubes[nextIndex].focus();
    });

    updateSeenUi();
  }

  function initWeekChatUi() {
    const root = document.querySelector('[data-week-chat]');
    if (!root || root.dataset.weekChatBound === '1') return;
    root.dataset.weekChatBound = '1';

    const storageKey = 'nets-week-chat-muted-v1';
    const messages = Array.from(root.querySelectorAll('[data-week-chat-message]'));
    const summary = root.querySelector('[data-week-chat-muted-summary]');
    const count = root.querySelector('[data-week-chat-muted-count]');
    const unmuteAll = root.querySelector('[data-week-chat-unmute-all]');
    let muted = new Set();

    try {
      const stored = JSON.parse(localStorage.getItem(storageKey) || '[]');
      if (Array.isArray(stored)) muted = new Set(stored.filter((value) => typeof value === 'string'));
    } catch (_) {}

    function saveMuted() {
      try { localStorage.setItem(storageKey, JSON.stringify(Array.from(muted))); } catch (_) {}
    }

    function applyMuted() {
      messages.forEach((message) => {
        const authorKey = message.getAttribute('data-author-key') || '';
        message.hidden = authorKey !== '' && muted.has(authorKey);
      });
      if (summary) summary.hidden = muted.size === 0;
      if (count) count.textContent = muted.size + (muted.size === 1 ? ' pseudo masque sur cet appareil' : ' pseudos masques sur cet appareil');
    }

    root.addEventListener('click', (event) => {
      const muteButton = event.target.closest('[data-week-chat-mute]');
      if (muteButton) {
        const authorKey = muteButton.getAttribute('data-week-chat-mute') || '';
        if (authorKey !== '') {
          muted.add(authorKey);
          saveMuted();
          applyMuted();
        }
        return;
      }
      if (event.target.closest('[data-week-chat-unmute-all]')) {
        muted.clear();
        saveMuted();
        applyMuted();
      }
    });

    applyMuted();
  }

  function initPageSpecificUi() {
    updateButtons();
    initLibraryUi();
    initCubeBoardUi();
    initWeekChatUi();
    const hero = document.querySelector('[data-autoplay-track]');
    if (!currentTrackId && hero) {
      const trackId = hero.getAttribute('data-autoplay-track');
      if (trackId && playlistById.has(trackId)) {
        loadTrack(trackId, { autoplay: true });
      }
    }
  }

  function handleTrackClick(event) {
    const trigger = event.target.closest('[data-track-id]');
    if (!trigger) return;
    event.preventDefault();
    loadTrack(trigger.getAttribute('data-track-id'), { autoplay: true });
  }

  async function navigate(url, push = true) {
    if (!main) return;
    bodyShell && bodyShell.classList.add('is-loading');
    try {
      const response = await fetch(url, { headers: { 'X-Requested-With': 'fetch' }, credentials: 'same-origin' });
      if (!response.ok) {
        window.location.href = url;
        return;
      }
      const html = await response.text();
      const doc = new DOMParser().parseFromString(html, 'text/html');
      const nextMain = doc.getElementById('site-main');
      if (!nextMain) {
        window.location.href = url;
        return;
      }
      main.innerHTML = nextMain.innerHTML;
      document.title = doc.title || document.title;
      if (push) {
        history.pushState({}, '', url);
      }
      document.querySelectorAll('.menu a').forEach((link) => {
        const href = new URL(link.href, window.location.origin);
        if (href.pathname === window.location.pathname) {
          link.setAttribute('aria-current', 'page');
        } else {
          link.removeAttribute('aria-current');
        }
      });
      initPageSpecificUi();
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } catch (_) {
      window.location.href = url;
    } finally {
      bodyShell && bodyShell.classList.remove('is-loading');
    }
  }


  document.addEventListener('submit', async function (event) {
    const form = event.target;
    if (!(form instanceof HTMLFormElement)) return;
    if (!form.matches('[data-ajax-main="1"]')) return;
    event.preventDefault();
    bodyShell && bodyShell.classList.add('is-loading');
    try {
      const response = await fetch(form.action || window.location.href, {
        method: form.method || 'POST',
        body: new FormData(form),
        credentials: 'same-origin'
      });
      if (!response.ok) {
        window.location.href = form.action || window.location.href;
        return;
      }
      const html = await response.text();
      const doc = new DOMParser().parseFromString(html, 'text/html');
      const nextMain = doc.getElementById('site-main');
      if (!nextMain) {
        window.location.href = form.action || window.location.href;
        return;
      }
      main.innerHTML = nextMain.innerHTML;
      document.title = doc.title || document.title;
      initPageSpecificUi();
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } catch (_) {
      window.location.href = form.action || window.location.href;
    } finally {
      bodyShell && bodyShell.classList.remove('is-loading');
    }
  });

  document.addEventListener('click', function (event) {
    handleTrackClick(event);

    const link = event.target.closest('a');
    if (!link) return;
    if (link.target && link.target !== '_self') return;
    if (link.hasAttribute('download')) return;
    const href = link.getAttribute('href') || '';
    if (!href || href.startsWith('mailto:') || href.startsWith('tel:') || href.startsWith('#')) return;
    const url = new URL(link.href, window.location.origin);
    if (url.origin !== window.location.origin) return;
    if (isPrivatePath(url.pathname)) return;
    event.preventDefault();
    navigate(url.pathname + url.search + url.hash);
  });

  window.addEventListener('popstate', () => {
    navigate(window.location.pathname + window.location.search + window.location.hash, false);
  });

  toggleBtn.addEventListener('click', function () {
    if (!currentTrackId && playlist.length) {
      loadTrack(playlist[0].id, { autoplay: true });
      return;
    }
    if (!audio.src) return;
    if (audio.paused) {
      audio.play().catch(() => {});
    } else {
      audio.pause();
    }
  });

  prevBtn.addEventListener('click', () => loadRelativeTrack(-1));
  nextBtn.addEventListener('click', () => loadRelativeTrack(1));
  audio.addEventListener('timeupdate', syncUi);
  audio.addEventListener('loadedmetadata', () => {
    // Quand on connaît la durée réelle, on (re)place les marqueurs
    const tr = currentTrack();
    if (tr) renderWordMarks(tr);
    syncUi();
  });
  audio.addEventListener('play', syncUi);
  audio.addEventListener('pause', syncUi);
  audio.addEventListener('ended', () => loadRelativeTrack(1));

  /* ============================================================
   * VU-MÈTRE "escaliers" — pilote 12 barres en temps réel
   * via Web Audio API (AnalyserNode). Mesure RMS du signal,
   * applique une courbe (compression douce) et un release lent
   * pour que les barres redescendent en escalier sans flicker.
   * ============================================================ */
  (function setupVuMeter() {
    const vuRoot = document.getElementById('player-vu');
    if (!vuRoot) return;
    const bars = Array.from(vuRoot.querySelectorAll('.vu-bar'));
    const N = bars.length; // 12
    let ctx = null, srcNode = null, analyser = null, dataArr = null;
    let rafId = null;
    let smoothed = 0; // niveau lissé entre 0 et 1

    function ensureCtx() {
      if (ctx) return true;
      try {
        const AC = window.AudioContext || window.webkitAudioContext;
        if (!AC) return false;
        ctx = new AC();
        srcNode = ctx.createMediaElementSource(audio);
        analyser = ctx.createAnalyser();
        analyser.fftSize = 1024;
        analyser.smoothingTimeConstant = 0.6;
        // Le son DOIT continuer à sortir des HP : src -> analyser -> destination
        srcNode.connect(analyser);
        analyser.connect(ctx.destination);
        dataArr = new Uint8Array(analyser.fftSize);
        return true;
      } catch (e) {
        // CORS / déjà connecté / API absente : on désactive en silence
        ctx = null;
        return false;
      }
    }

    function setLitCount(n) {
      // n = combien de barres allumées (0..N), du bas vers le haut
      for (let i = 0; i < N; i++) {
        // data-level commence à 1 en bas
        const level = i + 1;
        const bar = bars[i];
        const on = level <= n;
        if (on !== bar.classList.contains('is-on')) {
          bar.classList.toggle('is-on', on);
        }
      }
      vuRoot.classList.toggle('is-clip', n >= N);
    }

    function tick() {
      rafId = null;
      if (!analyser || audio.paused) {
        // chute douce vers 0 même quand en pause
        smoothed *= 0.82;
        const litIdle = Math.round(smoothed * N);
        setLitCount(litIdle);
        if (smoothed > 0.01) rafId = requestAnimationFrame(tick);
        else setLitCount(0);
        return;
      }
      analyser.getByteTimeDomainData(dataArr);
      // RMS sur le buffer (centré sur 128)
      let sum = 0;
      for (let i = 0; i < dataArr.length; i++) {
        const v = (dataArr[i] - 128) / 128;
        sum += v * v;
      }
      const rms = Math.sqrt(sum / dataArr.length); // 0..~1
      // Courbe : un peu de gain + compression douce -> jolie échelle visuelle
      let level = Math.min(1, Math.pow(rms * 2.4, 0.7));
      // Lissage attaque rapide, release lent (effet escaliers qui descendent)
      if (level > smoothed) smoothed = smoothed + (level - smoothed) * 0.5;
      else smoothed = smoothed + (level - smoothed) * 0.18;
      const lit = Math.round(smoothed * N);
      setLitCount(lit);
      rafId = requestAnimationFrame(tick);
    }

    function start() {
      if (!ensureCtx()) return;
      if (ctx.state === 'suspended') ctx.resume().catch(() => {});
      if (rafId == null) rafId = requestAnimationFrame(tick);
    }

    audio.addEventListener('play', start);
    audio.addEventListener('playing', start);
    audio.addEventListener('pause', () => {
      if (rafId == null) rafId = requestAnimationFrame(tick);
    });
    audio.addEventListener('ended', () => {
      if (rafId == null) rafId = requestAnimationFrame(tick);
    });
  })();

  updatePlayerText(null);
  if (!restoreState()) {
    initPageSpecificUi();
  } else {
    initPageSpecificUi();
  }
})();
