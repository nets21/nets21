(() => {
  'use strict';
  const initialized = new WeakSet();
  function init() {
    const host = document.querySelector('[data-chat-translation]');
    if (!host || initialized.has(host)) return;
    initialized.add(host);
    if (host.dataset.enabled !== '1') return;
    const select = host.querySelector('[data-chat-language]');
    const status = host.querySelector('[data-chat-translation-status]');
    const thread = host.closest('[data-week-chat]');
    const rows = [...thread.querySelectorAll('[data-chat-id]')].map(row => ({
      row, body: row.querySelector('[data-chat-body]'), original: row.querySelector('[data-chat-body]').innerText
    }));
    let controller;
    let generation = 0;
    async function translate() {
      controller?.abort();
      controller = new AbortController();
      const signal = controller.signal;
      const run = ++generation;
      const target = select.value;
      try { localStorage.setItem('nets-chat-language', target); } catch (_) {}
      for (const {row, body, original} of rows) {
        body.textContent = original;
        body.removeAttribute('lang');
        row.querySelector('[data-chat-original]')?.remove();
      }
      if (!target) { status.textContent = 'Textes originaux affichés.'; return; }
      status.textContent = 'Traduction en cours… Les originaux restent accessibles.';
      const eligible = rows.filter(item => item.row.dataset.chatModerated !== '1').reverse();
      try {
        for (let i = 0; i < eligible.length; i += 20) {
          if (!host.isConnected || signal.aborted) return;
          const batch = eligible.slice(i, i + 20);
          const form = new URLSearchParams({csrf: host.dataset.csrf, target});
          batch.forEach(({row}) => form.append('ids[]', row.dataset.chatId));
          const response = await fetch('/salon-traduction.php', {method:'POST', body:form, credentials:'same-origin', signal});
          if (!response.ok) throw new Error('unavailable');
          const result = await response.json();
          if (run !== generation || !host.isConnected) return;
          for (const {row, body, original} of batch) {
            const item = result.translations?.[row.dataset.chatId];
            if (!item || typeof item.text !== 'string' || item.source === target) continue;
            body.textContent = item.text;
            body.lang = target;
            const details = document.createElement('details');
            details.dataset.chatOriginal = '1';
            const summary = document.createElement('summary');
            summary.textContent = 'Traduction automatique — voir l’original';
            const source = document.createElement('p');
            source.dir = 'auto';
            source.textContent = original;
            details.append(summary, source);
            body.after(details);
          }
          if (result.status !== 'ok') throw new Error('unavailable');
        }
        status.textContent = 'Traduction automatique. Les messages signalés par la modération restent dans leur version originale.';
      } catch (error) {
        if (run === generation && error.name !== 'AbortError') {
          status.textContent = 'Certaines traductions sont indisponibles ou le quota est atteint. Les textes originaux restent affichés.';
        }
      }
    }
    let saved = null;
    try { saved = localStorage.getItem('nets-chat-language'); } catch (_) {}
    const browser = (navigator.language || 'fr').split('-')[0];
    const preferred = saved === null ? browser : saved;
    if ([...select.options].some(option => option.value === preferred)) select.value = preferred;
    select.addEventListener('change', translate);
    translate();
  }
  init();
  // Le site remplace le contenu central sans interrompre son lecteur audio.
  new MutationObserver(init).observe(document.body, {childList:true, subtree:true});
})();
