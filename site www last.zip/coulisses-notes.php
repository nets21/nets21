<?php
declare(strict_types=1);

define('NETS_ATELIER_ENTRY', true);
require __DIR__ . '/admin/notes.php';
