<?php
declare(strict_types=1);
header('Location: /bibliotheque.php', true, 302);
exit;
