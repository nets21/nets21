<?php
declare(strict_types=1);

require_once __DIR__ . '/inc/site.php';
require_once __DIR__ . '/inc/media.php';
require_once __DIR__ . '/inc/collection_board.php';

$title = $site['brand_main'] . ' :: bibliotheque temporaire';
$libraryTracks = array_values(array_filter(
  (array)($content['discovery_tracks'] ?? []),
  static fn($track): bool => is_array($track) && !empty($track['id'])
));

if (!function_exists('nets_library_duration_seconds')) {
  function nets_library_duration_seconds(string $duration): int {
    $seconds = 0;
    if (preg_match('/(\d+)\s*h/iu', $duration, $match)) {
      $seconds += (int)$match[1] * 3600;
    }
    if (preg_match('/(\d+)\s*min/iu', $duration, $match)) {
      $seconds += (int)$match[1] * 60;
    }
    if (preg_match('/(\d+)\s*s/iu', $duration, $match)) {
      $seconds += (int)$match[1];
    }
    return $seconds;
  }
}

if (!function_exists('nets_library_duration_label')) {
  function nets_library_duration_label(int $seconds): string {
    $hours = intdiv($seconds, 3600);
    $minutes = intdiv($seconds % 3600, 60);
    if ($hours > 0) {
      return $hours . ' h ' . str_pad((string)$minutes, 2, '0', STR_PAD_LEFT);
    }
    return $minutes . ' min';
  }
}

$libraryDuration = 0;
$libraryFragments = 0;
$librarySessions = 0;
foreach ($libraryTracks as $track) {
  $libraryDuration += nets_library_duration_seconds((string)($track['subtitle'] ?? ''));
  if (($track['kind'] ?? 'fragment') === 'session') {
    $librarySessions++;
  } else {
    $libraryFragments++;
  }
}

$boardDraft = collection_board_read();
$boardSlots = array_values(array_filter(
  (array)($boardDraft['slots'] ?? []),
  static fn($slot): bool => is_array($slot) && !empty($slot['id']) && !empty($slot['label']) && !empty($slot['visible'])
));

ob_start(); ?>

<section class="panel library-hero" data-library-root>
  <div class="library-eyebrow">
    <span class="library-live-dot" aria-hidden="true"></span>
    musique sans paroles
  </div>
  <div class="library-hero-grid">
    <div>
      <h1><?= site_h($content['home_title']) ?></h1>
      <p class="lede"><?= site_h($content['home_description']) ?></p>
    </div>
    <div class="library-stats" aria-label="Etat de la collection">
      <div><strong><?= count($libraryTracks) ?></strong><span>sons en ecoute</span></div>
      <div><strong><?= site_h(nets_library_duration_label($libraryDuration)) ?></strong><span>de matiere sonore</span></div>
      <div><strong>0</strong><span>pisteur publicitaire</span></div>
    </div>
  </div>
  <div class="library-hero-actions">
    <?php if ($libraryTracks !== []): ?>
      <button type="button" class="btn" data-track-id="<?= site_h((string)$libraryTracks[0]['id']) ?>">Commencer l'ecoute continue</button>
      <button type="button" class="btn ghost" data-library-random>Entrer au hasard</button>
    <?php endif; ?>
    <a class="library-text-link" href="/about.php">comprendre le projet</a>
  </div>
</section>

<?php $motd = trim((string)($content['motd_message'] ?? '')); ?>
<?php if ($motd !== ''): ?>
<aside class="motd" aria-label="Message du jour">
  <span class="motd-label">MOTD - message du jour</span>
  <p><?= site_h($motd) ?></p>
</aside>
<?php endif; ?>
<?php if (!empty($boardDraft['enabled']) && $boardSlots !== []): ?>
<section class="panel cube-board-section" id="collection-board" data-cube-board>
  <header class="cube-board-head">
    <div>
      <div class="kicker"><?= site_h((string)$boardDraft['kicker']) ?></div>
      <h2><?= site_h((string)$boardDraft['heading']) ?></h2>
    </div>
    <p><?= site_h((string)$boardDraft['intro']) ?></p>
  </header>

  <div class="cube-board-layout">
    <div class="cube-board-stage" aria-label="Emplacements du tableau">
      <div class="cube-board-mark" aria-hidden="true"><?= site_h((string)$boardDraft['mark']) ?></div>
      <?php foreach ($boardSlots as $slot): ?>
        <?php $slotKind = (($slot['kind'] ?? 'album') === 'session') ? 'session' : 'album'; ?>
        <button
          type="button"
          class="wood-cube wood-cube-<?= site_h($slotKind) ?>"
          data-cube-id="<?= site_h((string)$slot['id']) ?>"
          aria-expanded="false"
          aria-controls="cube-panel-<?= site_h((string)$slot['id']) ?>"
        >
          <span class="wood-cube-number"><?= site_h((string)($slot['number'] ?? '')) ?></span>
          <strong><?= site_h((string)$slot['label']) ?></strong>
          <small><?= $slotKind === 'album' ? 'album' : 'session' ?></small>
          <span class="wood-cube-trace" aria-hidden="true"></span>
        </button>
      <?php endforeach; ?>
    </div>

    <aside class="cube-board-drawer" aria-live="polite">
      <div class="cube-board-placeholder" data-cube-placeholder>
        <span class="cube-board-placeholder-mark">+</span>
        <strong><?= site_h((string)$boardDraft['placeholder_title']) ?></strong>
        <p><?= site_h((string)$boardDraft['placeholder_text']) ?></p>
      </div>
      <?php foreach ($boardSlots as $slot): ?>
        <?php
          $slotKind = (($slot['kind'] ?? 'album') === 'session') ? 'session' : 'album';
          $slotStatus = (string)($slot['status'] ?? 'reserve');
          $statusLabel = collection_board_status_options()[$slotStatus] ?? collection_board_status_options()['reserve'];
          $linkUrl = collection_board_safe_link($slot['link_url'] ?? '');
          $externalLink = preg_match('~^https?://~i', $linkUrl) === 1;
        ?>
        <div class="cube-board-panel" id="cube-panel-<?= site_h((string)$slot['id']) ?>" data-cube-panel="<?= site_h((string)$slot['id']) ?>" hidden>
          <div class="cube-board-panel-topline">
            <span><?= site_h((string)$slot['id']) ?></span>
            <span><?= site_h($statusLabel) ?></span>
          </div>
          <strong><?= site_h((string)$slot['label']) ?></strong>
          <p><?= site_h((string)$slot['description']) ?></p>
          <?php if ($linkUrl !== '' && (string)$slot['link_label'] !== ''): ?>
            <a href="<?= site_h($linkUrl) ?>" class="cube-board-link"<?= $externalLink ? ' target="_blank" rel="noopener"' : '' ?>><?= site_h((string)$slot['link_label']) ?></a>
          <?php endif; ?>
        </div>
      <?php endforeach; ?>
    </aside>
  </div>

  <footer class="cube-board-progress">
    <span data-cube-progress>0 / <?= count($boardSlots) ?> cubes ouverts sur cet appareil</span>
    <button type="button" data-cube-reset>effacer la trace locale</button>
  </footer>
</section>
<?php endif; ?>

<section class="panel library-catalogue" id="library-catalogue" data-library-catalogue>
  <div class="library-catalogue-head">
    <div>
      <div class="kicker">Le fonds present</div>
      <h2>Les sons rassembles</h2>
    </div>
    <p class="library-catalogue-note">Le lecteur garde le fil pendant la visite et enchaine les morceaux. Rien ici ne cherche a fabriquer de l'urgence.</p>
  </div>

  <div class="library-tools" aria-label="Outils de la bibliotheque">
    <label class="library-search">
      <span>chercher dans les titres</span>
      <input type="search" data-library-search placeholder="un titre, une annee, une forme..." autocomplete="off">
    </label>
    <div class="library-filters" aria-label="Filtrer par forme">
      <button type="button" class="library-filter is-active" data-library-filter="all" aria-pressed="true">tout</button>
      <button type="button" class="library-filter" data-library-filter="fragment" aria-pressed="false">Morceaux <span><?= $libraryFragments ?></span></button>
      <button type="button" class="library-filter" data-library-filter="session" aria-pressed="false">sessions <span><?= $librarySessions ?></span></button>
    </div>
  </div>

  <div class="library-result-line" aria-live="polite">
    <span data-library-count><?= count($libraryTracks) ?> sons visibles</span>
    <span>ordre du rassemblement</span>
  </div>

  <div class="library-grid">
    <?php foreach ($libraryTracks as $index => $track): ?>
      <?php
        $kind = (($track['kind'] ?? 'fragment') === 'session') ? 'session' : 'fragment';
        $originLabel = trim((string)($track['origin_label'] ?? ''));
        $trackNote = trim((string)($track['track_note'] ?? $track['player_subtitle'] ?? ''));
        $searchText = implode(' ', [
          (string)($track['title'] ?? ''),
          (string)($track['year'] ?? ''),
          (string)($track['subtitle'] ?? ''),
          $kind,
          $originLabel,
          $trackNote,
        ]);
        $otsUrl = track_opentimestamps_url($track);
      ?>
      <article
        class="library-item library-item-<?= site_h($kind) ?>"
        data-library-item
        data-library-kind="<?= site_h($kind) ?>"
        data-library-search-text="<?= site_h($searchText) ?>"
      >
        <div class="library-item-index"><?= str_pad((string)($index + 1), 2, '0', STR_PAD_LEFT) ?></div>
        <img class="library-item-cover" src="<?= site_h(track_cover_url($track)) ?>" alt="" loading="lazy">
        <div class="library-item-body">
          <div class="library-item-meta">
            <span><?= $kind === 'session' ? 'Session' : 'Morceau' ?></span>
            <?php if ($originLabel !== ''): ?><span><?= site_h($originLabel) ?></span><?php endif; ?>
            <?php if (!empty($track['year'])): ?><span><?= site_h((string)$track['year']) ?></span><?php endif; ?>
          </div>
          <h3><?= site_h((string)($track['title'] ?? 'Sans titre')) ?></h3>
          <?php if ($trackNote !== ''): ?><details><summary>À propos de ce morceau</summary><div class="track-note-text"><?= site_h($trackNote) ?></div></details><?php endif; ?>
        </div>
        <div class="library-item-end">
          <span class="library-duration"><?= site_h((string)($track['subtitle'] ?? '')) ?></span>
          <button type="button" class="btn small" data-track-id="<?= site_h((string)$track['id']) ?>">ecouter</button>
          <?php if ($otsUrl !== ''): ?>
            <a class="proof-link" href="/preuves.php#<?= site_h((string)($track['slug'] ?? $track['id'])) ?>">preuve de date</a>
          <?php endif; ?>
        </div>
      </article>
    <?php endforeach; ?>
  </div>

  <p class="library-empty" data-library-empty<?= $libraryTracks === [] ? '' : ' hidden' ?>>Aucun son disponible pour cette sélection.</p>
</section>

<section class="panel subtle"><p><?= site_h($content['beta_text']) ?></p><div class="cta"><a class="btn" href="/fragments.php">Fragments rouges</a><a class="btn ghost" href="/sessions.php">Sessions bleues</a><a class="btn ghost" href="/salon.php">Échanger · 7J</a><a class="btn ghost" href="/chat.php">Présences</a></div></section>
<?php $page_content = ob_get_clean(); include __DIR__ . '/inc/layout.php';
