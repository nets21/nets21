<?php
declare(strict_types=1);
require_once __DIR__ . '/inc/site.php';
$title = 'À propos';
ob_start(); ?>
<section class="panel"><h1>À propos</h1><div class="prose"><?php site_paragraphs($content['about_intro_lines']); ?></div><div class="cta"><a class="btn" href="/biographie.php">Mon parcours musical</a><a class="btn ghost" href="/salon.php">Échanger · 7J</a></div></section>
<section class="panel subtle"><h2>La suite du projet</h2><div class="prose"><?php site_paragraphs($content['future_lines']); ?></div></section>
<?php $page_content = ob_get_clean(); include __DIR__ . '/inc/layout.php';
