<?php
declare(strict_types=1);
require_once __DIR__ . '/../inc/admin_auth.php';
require_once __DIR__ . '/../inc/notes.php';

if (!defined('NETS_ATELIER_ENTRY')) {
  header('Location: ' . site_path('admin_home_path', '/coulisses-espace.php'), true, 302);
  exit;
}

admin_require_login();

$path_notes = site_path('admin_notes_path', '/coulisses-notes.php');
$error = null;

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
  if (!hash_equals($_SESSION['admin_csrf'] ?? '', (string)($_POST['csrf'] ?? ''))) {
    http_response_code(400);
    $error = 'Jeton de sécurité invalide. Recharge la page.';
  } else {
    $action = (string)($_POST['action'] ?? '');
    $id = (int)($_POST['id'] ?? 0);
    $title_value = (string)($_POST['title'] ?? '');
    $body_value = (string)($_POST['body'] ?? '');
    $tag_value = (string)($_POST['tag'] ?? '');
    $pinned_value = !empty($_POST['pinned']);

    if ($action === 'create') {
      if (atelier_notes_create($title_value, $body_value, $tag_value, $pinned_value)) {
        header('Location: ' . $path_notes . '?saved=created');
        exit;
      }
      $error = 'Impossible d’enregistrer cette note.';
    } elseif ($action === 'update' && $id > 0) {
      if (atelier_notes_update($id, $title_value, $body_value, $tag_value, $pinned_value)) {
        header('Location: ' . $path_notes . '?saved=updated#note-' . $id);
        exit;
      }
      $error = 'Impossible de modifier cette note.';
    } elseif ($action === 'delete' && $id > 0) {
      if (atelier_notes_delete($id)) {
        header('Location: ' . $path_notes . '?saved=deleted');
        exit;
      }
      $error = 'Impossible de supprimer cette note.';
    }
  }
}

$q = trim((string)($_GET['q'] ?? ''));
$notes = atelier_notes_all();
$visible = $notes;

if ($q !== '') {
  $needle = function_exists('mb_strtolower') ? mb_strtolower($q) : strtolower($q);
  $visible = array_values(array_filter($notes, static function (array $note) use ($needle): bool {
    $haystack = (string)$note['title'] . ' ' . (string)$note['tag'] . ' ' . (string)$note['body'];
    $haystack = function_exists('mb_strtolower') ? mb_strtolower($haystack) : strtolower($haystack);
    return strpos($haystack, $needle) !== false;
  }));
}

function atelier_notes_fmt_date(int $t): string {
  return $t > 0 ? date('Y-m-d · H:i', $t) : '—';
}

$saved = (string)($_GET['saved'] ?? '');
$title = 'coulisses — pense-bête — nets-musique.digital';
$admin_current = 'notes';

ob_start(); ?>
<div class="page-head">
  <div>
    <div class="crumbs">coulisses <b>/</b> pense-bête</div>
    <h1>Pense-bête</h1>
    <p>Notes privées de travail : directions, choses vues, idées de lettres, décisions à reprendre. Rien n’est publié sur le site public.</p>
  </div>
  <div class="ascii-mark" aria-hidden="true">:: carnet ::
background</div>
</div>

<?php if ($saved === 'created'): ?>
  <div class="notice notice-good">Note enregistrée.</div>
<?php elseif ($saved === 'updated'): ?>
  <div class="notice notice-good">Note modifiée.</div>
<?php elseif ($saved === 'deleted'): ?>
  <div class="notice notice-good">Note supprimée.</div>
<?php elseif ($error): ?>
  <div class="notice notice-alert"><?= site_h($error) ?></div>
<?php endif; ?>

<section class="card">
  <div class="card-head">
    <h2>Nouvelle note</h2>
    <span class="card-sub">direction, observation, lettre, site, son...</span>
  </div>
  <div class="card-body">
    <form method="post" class="notes-form">
      <input type="hidden" name="csrf" value="<?= site_h($_SESSION['admin_csrf'] ?? '') ?>">
      <input type="hidden" name="action" value="create">
      <div class="notes-fields">
        <label class="field">
          <span class="label">Titre</span>
          <input type="text" name="title" placeholder="Direction que je prends">
        </label>
        <label class="field">
          <span class="label">Étiquette</span>
          <input type="text" name="tag" value="direction" placeholder="direction">
        </label>
        <label class="field full-row">
          <span class="label">Note</span>
          <textarea name="body" rows="7" placeholder="J’ai vu ça... / à reprendre... / idée de courrier..."></textarea>
        </label>
      </div>
      <div class="form-actions">
        <label class="checkline"><input type="checkbox" name="pinned" value="1"> garder en haut</label>
        <button type="submit" class="btn primary">Enregistrer la note</button>
      </div>
    </form>
  </div>
</section>

<section class="card">
  <div class="card-head">
    <h2>Notes enregistrées</h2>
    <span class="card-sub"><?= count($visible) ?> visible<?= count($visible) > 1 ? 's' : '' ?> / <?= count($notes) ?> au total</span>
    <div class="card-head-actions">
      <form method="get" class="admin-filter-form">
        <input type="search" class="search-input" name="q" value="<?= site_h($q) ?>" placeholder="chercher dans le pense-bête">
        <?php if ($q !== ''): ?><a href="<?= site_h($path_notes) ?>" class="btn small ghost">effacer</a><?php endif; ?>
      </form>
    </div>
  </div>
  <div class="card-body notes-list">
    <?php if (!$visible): ?>
      <div class="empty">
        <div class="big">∅</div>
        <?= $q !== '' ? 'aucune note ne correspond à cette recherche' : 'aucune note pour l’instant' ?>
      </div>
    <?php else: ?>
      <?php foreach ($visible as $note): ?>
        <article class="note-card<?= !empty($note['pinned']) ? ' is-pinned' : '' ?>" id="note-<?= (int)$note['id'] ?>">
          <div class="note-head">
            <div>
              <div class="note-meta">
                <span class="status-chip <?= !empty($note['pinned']) ? 'pending' : 'published' ?>"><?= !empty($note['pinned']) ? 'épinglée' : site_h((string)$note['tag']) ?></span>
                <span><?= site_h(atelier_notes_fmt_date((int)$note['updated_at'])) ?></span>
              </div>
              <h3><?= site_h((string)$note['title']) ?></h3>
            </div>
          </div>
          <?php if ((string)$note['body'] !== ''): ?>
            <p class="note-body"><?= nl2br(site_h((string)$note['body'])) ?></p>
          <?php endif; ?>

          <details class="note-edit">
            <summary>modifier</summary>
            <form method="post" class="notes-form">
              <input type="hidden" name="csrf" value="<?= site_h($_SESSION['admin_csrf'] ?? '') ?>">
              <input type="hidden" name="action" value="update">
              <input type="hidden" name="id" value="<?= (int)$note['id'] ?>">
              <div class="notes-fields">
                <label class="field">
                  <span class="label">Titre</span>
                  <input type="text" name="title" value="<?= site_h((string)$note['title']) ?>">
                </label>
                <label class="field">
                  <span class="label">Étiquette</span>
                  <input type="text" name="tag" value="<?= site_h((string)$note['tag']) ?>">
                </label>
                <label class="field full-row">
                  <span class="label">Note</span>
                  <textarea name="body" rows="7"><?= site_h((string)$note['body']) ?></textarea>
                </label>
              </div>
              <div class="form-actions">
                <label class="checkline"><input type="checkbox" name="pinned" value="1"<?= !empty($note['pinned']) ? ' checked' : '' ?>> garder en haut</label>
                <button type="submit" class="btn primary small">enregistrer</button>
              </div>
            </form>
            <form method="post" class="note-delete-form" onsubmit="return confirm('Supprimer cette note du pense-bête ?');">
              <input type="hidden" name="csrf" value="<?= site_h($_SESSION['admin_csrf'] ?? '') ?>">
              <input type="hidden" name="action" value="delete">
              <input type="hidden" name="id" value="<?= (int)$note['id'] ?>">
              <button type="submit" class="btn danger small">supprimer</button>
            </form>
          </details>
        </article>
      <?php endforeach; ?>
    <?php endif; ?>
  </div>
  <div class="card-foot">
    Fichier privé : <code><?= site_h(atelier_notes_path()) ?></code>. La racine du site reste en noindex.
  </div>
</section>

<?php $page_content = ob_get_clean(); include __DIR__ . '/../inc/admin_layout.php';
