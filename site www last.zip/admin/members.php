<?php
declare(strict_types=1);

// Fonction retiree : ne pas ouvrir de session ni exposer les fichiers prives.
http_response_code(410);
header('Content-Type: text/html; charset=UTF-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');
exit('<!doctype html><html lang="fr"><meta charset="utf-8"><title>Page retiree</title><p>Cet espace a été retiré.</p><a href="/">Retour au site</a></html>');