<?php
declare(strict_types=1);
require_once __DIR__ . '/../inc/admin_auth.php';
require_once __DIR__ . '/../inc/db.php';

if (!defined('NETS_ATELIER_ENTRY')) {
  header('Location: ' . site_path('admin_guestbook_path', '/coulisses-presences.php'), true, 302);
  exit;
}

admin_require_login();
admin_session_start();

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
  if (!hash_equals($_SESSION['admin_csrf'] ?? '', (string)($_POST['csrf'] ?? ''))) {
    http_response_code(400);
    exit('Bad request');
  }
  $id = (int)($_POST['id'] ?? 0);
  $action = (string)($_POST['action'] ?? '');
  if ($id > 0) {
    if ($action === 'approve') {
      guestbook_approve($id);
    } elseif ($action === 'delete') {
      guestbook_delete($id);
    } elseif ($action === 'reply') {
      guestbook_reply($id, (string)($_POST['reply_body'] ?? ''));
    }
  }
  $redirect = site_path('admin_guestbook_path', '/coulisses-presences.php');
  $filter = (string)($_POST['return_filter'] ?? '');
  $returnLabelRaw = (string)($_POST['return_label'] ?? 'all');
  $returnLabel = $returnLabelRaw === 'all' ? 'all' : guestbook_normalize_label($returnLabelRaw);
  if ($filter !== '') { $redirect .= '?filter=' . urlencode($filter); }
  if ($returnLabel !== 'all') {
    $redirect .= (str_contains($redirect, '?') ? '&' : '?') . 'label=' . urlencode($returnLabel);
  }
  header('Location: ' . $redirect);
  exit;
}

$filter  = (string)($_GET['filter'] ?? 'pending');
$q       = trim((string)($_GET['q'] ?? ''));
$labelFilter = (string)($_GET['label'] ?? 'all');
$labelOptions = guestbook_label_options();
$labelDescriptions = guestbook_label_descriptions();
$labelMailboxes = [];
foreach (array_keys($labelOptions) as $labelKey) {
  $labelMailboxes[$labelKey] = site_guestbook_mailbox_address($labelKey);
}
$valid   = ['pending', 'approved', 'replied', 'all'];
if (!in_array($filter, $valid, true)) { $filter = 'pending'; }
if ($labelFilter !== 'all') {
  $labelFilter = guestbook_normalize_label($labelFilter);
}

$stats    = admin_guestbook_stats();
$pending  = guestbook_pending_entries();
$approved = guestbook_approved_entries_admin();
$all      = array_merge($pending, $approved);

// Tri commun : pending en premier (par date desc) puis approuvés (par date desc)
usort($all, function ($a, $b) {
  $sa = (string)($a['status'] ?? '');
  $sb = (string)($b['status'] ?? '');
  if ($sa !== $sb) return $sa === 'pending' ? -1 : 1;
  $ta = (int)($a['approved_at'] ?? $a['created_at'] ?? 0);
  $tb = (int)($b['approved_at'] ?? $b['created_at'] ?? 0);
  return $tb <=> $ta;
});

$visible = array_values(array_filter($all, function ($e) use ($filter, $q, $labelFilter) {
  $status = (string)($e['status'] ?? '');
  switch ($filter) {
    case 'pending':  if ($status !== 'pending')  return false; break;
    case 'approved': if ($status !== 'approved') return false; break;
    case 'replied':  if ($status !== 'approved' || empty($e['reply_body'])) return false; break;
    case 'all': default: /* pas de filtre */ break;
  }
  if ($labelFilter !== 'all' && guestbook_entry_label($e) !== $labelFilter) {
    return false;
  }
  if ($q !== '') {
    $entryLabel = guestbook_entry_label($e);
    $haystack = mb_strtolower((string)($e['name'] ?? '') . ' ' . (string)($e['body'] ?? '') . ' ' . (string)($e['reply_body'] ?? '') . ' ' . (string)($e['email'] ?? '') . ' ' . $entryLabel . ' ' . guestbook_label_text($entryLabel));
    if (strpos($haystack, mb_strtolower($q)) === false) return false;
  }
  return true;
}));

function admin_initial(string $name): string {
  $name = trim($name);
  if ($name === '') return '?';
  if (function_exists('mb_substr')) return mb_strtoupper(mb_substr($name, 0, 1));
  return strtoupper(substr($name, 0, 1));
}
function admin_fmt_date(int $t): string {
  return $t > 0 ? date('Y-m-d · H:i', $t) : '—';
}
function admin_guestbook_url(string $filter, string $q, string $labelFilter, array $extra = [], string $anchor = ''): string {
  $params = ['filter' => $filter];
  if ($q !== '') {
    $params['q'] = $q;
  }
  if ($labelFilter !== 'all') {
    $params['label'] = $labelFilter;
  }
  foreach ($extra as $key => $value) {
    if ($value !== null && $value !== '') {
      $params[$key] = $value;
    }
  }
  return '?' . http_build_query($params) . $anchor;
}
function admin_guestbook_mailto(array $entry): string {
  $email = guestbook_entry_email($entry);
  if ($email === null) {
    return '#';
  }
  $name = trim((string)($entry['name'] ?? ''));
  $hello = $name !== '' ? 'Bonjour ' . $name . ',' : 'Bonjour,';
  $subject = 'Réponse à votre message sur nets-musique.digital';
  $body = $hello . "\n\n\n\n---\nVotre message sur nets-musique.digital :\n" . trim((string)($entry['body'] ?? ''));
  return 'mailto:' . $email . '?subject=' . rawurlencode($subject) . '&body=' . rawurlencode($body);
}

$title = 'coulisses — présences — nets-musique.digital';
$admin_current = 'guestbook';

$path_gb = site_path('admin_guestbook_path', '/coulisses-presences.php');
$open_reply = (int)($_GET['reply'] ?? 0);

ob_start(); ?>
<div class="page-head">
  <div>
    <div class="crumbs">coulisses <b>/</b> présences</div>
    <h1>Présences à relire</h1>
    <p>Approuver, supprimer ou répondre en tant que site. Les messages deviennent publics seulement après publication.</p>
  </div>
</div>

<div class="card">
  <div class="card-head">
    <h2>Filtrer</h2>
    <div class="card-head-actions" style="width:100%;gap:10px;flex-wrap:wrap">
      <nav class="seg" aria-label="Filtre par statut">
        <a href="<?= site_h(admin_guestbook_url('pending', $q, $labelFilter)) ?>"<?= $filter==='pending'  ? ' class="is-current"' : '' ?>>En attente <span class="n"><?= (int)$stats['pending']  ?></span></a>
        <a href="<?= site_h(admin_guestbook_url('approved', $q, $labelFilter)) ?>"<?= $filter==='approved' ? ' class="is-current"' : '' ?>>Publiés <span class="n"><?= (int)$stats['approved'] ?></span></a>
        <a href="<?= site_h(admin_guestbook_url('replied', $q, $labelFilter)) ?>"<?= $filter==='replied'  ? ' class="is-current"' : '' ?>>Avec réponse <span class="n"><?= (int)$stats['replied']  ?></span></a>
        <a href="<?= site_h(admin_guestbook_url('all', $q, $labelFilter)) ?>"<?= $filter==='all'      ? ' class="is-current"' : '' ?>>Tous <span class="n"><?= (int)$stats['total']    ?></span></a>
      </nav>
      <nav class="seg labels-seg" aria-label="Filtre par boîte à lettres">
        <a href="<?= site_h(admin_guestbook_url($filter, $q, 'all')) ?>"<?= $labelFilter==='all' ? ' class="is-current"' : '' ?>>Toutes</a>
        <?php foreach ($labelOptions as $labelKey => $labelText): ?>
          <a href="<?= site_h(admin_guestbook_url($filter, $q, $labelKey)) ?>"<?= $labelFilter===$labelKey ? ' class="is-current"' : '' ?>><?= site_h($labelText) ?> <span class="n"><?= (int)($stats['labels'][$labelKey] ?? 0) ?></span></a>
        <?php endforeach; ?>
      </nav>
      <div class='mailbox-routing' aria-label='Adresses Zimbra par designation'>
        <?php foreach ($labelOptions as $labelKey => $labelText):
          $mailboxAddress = $labelMailboxes[$labelKey] ?? null;
          if (!is_string($mailboxAddress) || $mailboxAddress === '') { continue; }
        ?>
          <span class='mailbox-route'>
            <b><?= site_h($labelText) ?></b>
            <a href='mailto:<?= site_h($mailboxAddress) ?>'><?= site_h($mailboxAddress) ?></a>
          </span>
        <?php endforeach; ?>
      </div>
      <form method="get" style="display:flex;gap:8px;flex:1;min-width:220px;margin:0">
        <input type="hidden" name="filter" value="<?= site_h($filter) ?>" />
        <?php if ($labelFilter !== 'all'): ?><input type="hidden" name="label" value="<?= site_h($labelFilter) ?>" /><?php endif; ?>
        <input type="search" class="search-input" name="q" value="<?= site_h($q) ?>" placeholder="chercher un nom, un mot…" />
        <?php if ($q !== ''): ?><a href="<?= site_h(admin_guestbook_url($filter, '', $labelFilter)) ?>" class="btn small ghost">effacer</a><?php endif; ?>
      </form>
    </div>
  </div>
</div>

<div class="card">
  <div class="card-head">
    <h2>
      <?php
        $head = ['pending' => 'En attente', 'approved' => 'Publiés', 'replied' => 'Avec réponse', 'all' => 'Tous les messages'];
        echo site_h($head[$filter] ?? 'Messages');
      ?>
    </h2>
    <span class="card-sub"><?= count($visible) ?> résultat<?= count($visible) > 1 ? 's' : '' ?><?= $labelFilter !== 'all' ? ' · ' . site_h(guestbook_label_text($labelFilter)) : '' ?><?= $q !== '' ? ' · recherche « ' . site_h($q) . ' »' : '' ?></span>
  </div>
  <div class="card-body flush">

    <?php if (!$visible): ?>
      <div class="empty">
        <div class="big">∅</div>
        <?php if ($q !== ''): ?>aucun message ne correspond à « <?= site_h($q) ?> »<?php else: ?>aucun message dans cette vue<?php endif; ?>
      </div>
    <?php else: ?>
      <?php foreach ($visible as $entry):
        $eid = (int)$entry['id'];
        $status = (string)($entry['status'] ?? '');
        $has_reply = !empty($entry['reply_body']);
        $is_pending = $status === 'pending';
        $display_date = $is_pending ? (int)($entry['created_at'] ?? 0) : (int)($entry['approved_at'] ?? $entry['created_at'] ?? 0);
        $reply_open = ($open_reply === $eid);
        $entryLabel = guestbook_entry_label($entry);
        $entryEmail = guestbook_entry_email($entry);
      ?>
      <article class="entry-admin" id="entry-<?= $eid ?>">
        <div class="entry-avatar"><?= site_h(admin_initial((string)$entry['name'])) ?></div>
        <div class="entry-main">
          <div class="entry-meta-line">
            <b><?= site_h((string)$entry['name']) ?></b>
            <span class="id">#<?= $eid ?></span>
            <span class="label-chip label-<?= site_h($entryLabel) ?>"><?= site_h(guestbook_label_text($entryLabel)) ?></span>
            <?php if ($entryEmail !== null): ?>
              <a class="private-mail" href="<?= site_h(admin_guestbook_mailto($entry)) ?>"><?= site_h($entryEmail) ?></a>
            <?php endif; ?>
            <span><?= site_h(admin_fmt_date($display_date)) ?></span>
            <?php if ($is_pending): ?>
              <span class="status-chip pending">en attente</span>
            <?php else: ?>
              <span class="status-chip published">publié</span>
              <?php if ($has_reply): ?><span class="status-chip replied">réponse envoyée</span><?php endif; ?>
            <?php endif; ?>
          </div>
          <p class="entry-body"><?= nl2br(site_h((string)$entry['body'])) ?></p>

          <?php if ($has_reply && !$reply_open): ?>
            <div class="entry-reply">
              <div class="meta">Réponse du site</div>
              <p><?= nl2br(site_h((string)$entry['reply_body'])) ?></p>
            </div>
            <div style="margin-top:8px">
              <a class="reply-toggle" href="<?= site_h(admin_guestbook_url($filter, $q, $labelFilter, ['reply' => $eid], '#entry-' . $eid)) ?>">modifier la réponse</a>
            </div>
          <?php endif; ?>

          <?php if (!$is_pending && ($reply_open || !$has_reply)): ?>
            <form method="post" class="reply-inline is-open" style="margin-top:12px">
              <input type="hidden" name="csrf" value="<?= site_h($_SESSION['admin_csrf']) ?>">
              <input type="hidden" name="id" value="<?= $eid ?>">
              <input type="hidden" name="action" value="reply">
              <input type="hidden" name="return_filter" value="<?= site_h($filter) ?>">
              <input type="hidden" name="return_label" value="<?= site_h($labelFilter) ?>">
              <label>
                <span class="field-label">Réponse du site</span>
                <textarea name="reply_body" rows="4" placeholder="Réponse publique au message…"><?= site_h((string)($entry['reply_body'] ?? '')) ?></textarea>
              </label>
              <div class="row">
                <?php if ($has_reply && !$reply_open): ?><a class="btn small ghost" href="<?= site_h(admin_guestbook_url($filter, $q, $labelFilter, [], '#entry-' . $eid)) ?>">annuler</a><?php endif; ?>
                <button class="btn blue small" type="submit">enregistrer la réponse</button>
              </div>
            </form>
          <?php endif; ?>
        </div>

        <div class="entry-actions">
          <?php if ($entryEmail !== null): ?>
            <a class="btn small ghost" href="<?= site_h(admin_guestbook_mailto($entry)) ?>">répondre email</a>
          <?php endif; ?>
          <?php if ($is_pending): ?>
            <form method="post" style="margin:0">
              <input type="hidden" name="csrf" value="<?= site_h($_SESSION['admin_csrf']) ?>">
              <input type="hidden" name="id" value="<?= $eid ?>">
              <input type="hidden" name="action" value="approve">
              <input type="hidden" name="return_filter" value="<?= site_h($filter) ?>">
              <input type="hidden" name="return_label" value="<?= site_h($labelFilter) ?>">
              <button class="btn primary small" type="submit">publier</button>
            </form>
            <form method="post" style="margin:0" onsubmit="return confirm('Supprimer définitivement ce message ?');">
              <input type="hidden" name="csrf" value="<?= site_h($_SESSION['admin_csrf']) ?>">
              <input type="hidden" name="id" value="<?= $eid ?>">
              <input type="hidden" name="action" value="delete">
              <input type="hidden" name="return_filter" value="<?= site_h($filter) ?>">
              <input type="hidden" name="return_label" value="<?= site_h($labelFilter) ?>">
              <button class="btn danger small" type="submit">supprimer</button>
            </form>
          <?php else: ?>
            <?php if (!$reply_open && !$has_reply): ?>
              <a class="btn small" href="<?= site_h(admin_guestbook_url($filter, $q, $labelFilter, ['reply' => $eid], '#entry-' . $eid)) ?>">répondre…</a>
            <?php endif; ?>
            <form method="post" style="margin:0" onsubmit="return confirm('Retirer ce message publié ?');">
              <input type="hidden" name="csrf" value="<?= site_h($_SESSION['admin_csrf']) ?>">
              <input type="hidden" name="id" value="<?= $eid ?>">
              <input type="hidden" name="action" value="delete">
              <input type="hidden" name="return_filter" value="<?= site_h($filter) ?>">
              <input type="hidden" name="return_label" value="<?= site_h($labelFilter) ?>">
              <button class="btn danger small" type="submit">retirer</button>
            </form>
          <?php endif; ?>
        </div>
      </article>
      <?php endforeach; ?>
    <?php endif; ?>

  </div>
  <div class="card-foot">
    Les réponses apparaissent publiquement sous le message. Les boîtes à lettres aident seulement à trier la lecture.
  </div>
</div>

<?php $page_content = ob_get_clean(); include __DIR__ . '/../inc/admin_layout.php';
