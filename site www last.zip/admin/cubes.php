<?php
declare(strict_types=1);

require_once __DIR__ . '/../inc/admin_auth.php';
require_once __DIR__ . '/../inc/collection_board.php';

if (!defined('NETS_ATELIER_ENTRY')) {
  header('Location: ' . site_path('admin_home_path', '/coulisses-espace.php'), true, 302);
  exit;
}

admin_require_login();
admin_session_start();

$board = collection_board_read();
$error = '';
$flash = (string)($_SESSION['cube_admin_flash'] ?? '');
unset($_SESSION['cube_admin_flash']);

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
  if (!hash_equals((string)($_SESSION['admin_csrf'] ?? ''), (string)($_POST['csrf'] ?? ''))) {
    http_response_code(400);
    $error = 'Jeton de securite invalide. Recharge la page.';
  } else {
    $board = collection_board_from_admin_post($_POST, $board);
    $action = isset($_POST['delete_id']) ? 'delete_cube' : (string)($_POST['action'] ?? '');
    if ($action === 'add_album') {
      $board = collection_board_add_slot($board, 'album');
    } elseif ($action === 'add_session') {
      $board = collection_board_add_slot($board, 'session');
    } elseif ($action === 'delete_cube') {
      $board = collection_board_remove_slot($board, (string)($_POST['delete_id'] ?? ''));
    } elseif ($action !== 'save_cubes') {
      $error = 'Action inconnue.';
    }

    if ($error !== '') {
      // Le formulaire reste affiche avec les valeurs recues.
    } elseif (!collection_board_write($board)) {
      $error = 'Le tableau de cubes n a pas pu etre enregistre dans le dossier data.';
    } else {
      $_SESSION['cube_admin_flash'] = $action === 'add_album'
        ? 'Un nouveau cube album a ete ajoute. Il est masque tant que tu ne le rends pas visible.'
        : ($action === 'add_session'
          ? 'Un nouveau cube session a ete ajoute. Il est masque tant que tu ne le rends pas visible.'
          : ($action === 'delete_cube' ? 'Le cube a ete supprime.' : 'Les noms et reglages des cubes ont ete enregistres.'));
      header('Location: ' . site_path('admin_cubes_path', '/coulisses-cubes.php'), true, 303);
      exit;
    }
  }
}

$title = 'coulisses - cubes de la bibliotheque - nets-musique.digital';
$admin_current = 'cubes';
$statusOptions = collection_board_status_options();

ob_start(); ?>
<div class="page-head">
  <div>
    <div class="crumbs">coulisses <b>/</b> cubes</div>
    <h1>Tableau de cubes</h1>
    <p>Renomme les cubes et ajuste leur contenu public. L identifiant technique reste volontairement fixe pour ne pas perdre la trace des visiteurs.</p>
  </div>
  <div class="ascii-mark" aria-hidden="true">:: cubes ::
noms / ordre / etat</div>
</div>

<?php if ($flash !== ''): ?>
  <div class="notice notice-good"><?= site_h($flash) ?></div>
<?php elseif ($error !== ''): ?>
  <div class="notice notice-alert"><?= site_h($error) ?></div>
<?php endif; ?>

<form method="post" class="cube-admin-form">
  <input type="hidden" name="csrf" value="<?= site_h((string)($_SESSION['admin_csrf'] ?? '')) ?>">

  <section class="card">
    <div class="card-head">
      <h2>Presentation du tableau</h2>
      <span class="card-sub">visible dans la bibliotheque publique</span>
      <div class="card-head-actions">
        <a href="/bibliotheque.php#collection-board" class="btn small ghost" target="_blank" rel="noopener">voir le tableau public</a>
      </div>
    </div>
    <div class="card-body cube-board-settings">
      <label class="cube-admin-toggle">
        <input type="checkbox" name="board[enabled]" value="1"<?= !empty($board['enabled']) ? ' checked' : '' ?>>
        <span>afficher le tableau de cubes</span>
      </label>
      <label>
        <span class="label">Sur-titre</span>
        <input type="text" name="board[kicker]" maxlength="80" value="<?= site_h((string)$board['kicker']) ?>">
      </label>
      <label>
        <span class="label">Titre principal</span>
        <input type="text" name="board[heading]" maxlength="120" value="<?= site_h((string)$board['heading']) ?>" required>
      </label>
      <label class="cube-admin-wide">
        <span class="label">Introduction</span>
        <textarea name="board[intro]" rows="3" maxlength="400"><?= site_h((string)$board['intro']) ?></textarea>
      </label>
      <label>
        <span class="label">Marque sur le plateau</span>
        <input type="text" name="board[mark]" maxlength="30" value="<?= site_h((string)$board['mark']) ?>">
      </label>
      <label>
        <span class="label">Invitation avant ouverture</span>
        <input type="text" name="board[placeholder_title]" maxlength="80" value="<?= site_h((string)$board['placeholder_title']) ?>">
      </label>
      <label class="cube-admin-wide">
        <span class="label">Texte avant ouverture</span>
        <input type="text" name="board[placeholder_text]" maxlength="240" value="<?= site_h((string)$board['placeholder_text']) ?>">
      </label>
    </div>
  </section>

  <section class="card">
    <div class="card-head">
      <h2>Cubes</h2>
      <span class="card-sub"><?= count($board['slots']) ?> emplacement<?= count($board['slots']) > 1 ? 's' : '' ?></span>
      <div class="card-head-actions cube-add-actions">
        <button type="submit" class="btn small ghost" name="action" value="add_album">+ album</button>
        <button type="submit" class="btn small ghost" name="action" value="add_session">+ session</button>
      </div>
    </div>
    <div class="card-body flush">
      <div class="cube-admin-list">
        <?php foreach ($board['slots'] as $index => $slot): ?>
          <?php $id = (string)$slot['id']; ?>
          <article class="cube-admin-item<?= !empty($slot['visible']) ? ' is-visible' : '' ?>">
            <div class="cube-admin-item-head">
              <div>
                <strong><?= site_h((string)$slot['label']) ?></strong>
                <span class="cube-admin-id">identifiant fixe : <?= site_h($id) ?></span>
              </div>
              <label class="cube-admin-toggle">
                <input type="checkbox" name="cube[<?= site_h($id) ?>][visible]" value="1"<?= !empty($slot['visible']) ? ' checked' : '' ?>>
                <span>cube visible</span>
              </label>
              <button type="submit" class="btn small ghost cube-delete-button" name="delete_id" value="<?= site_h($id) ?>" onclick="return confirm('Supprimer ce cube ?');">supprimer</button>
            </div>

            <div class="cube-admin-grid">
              <label>
                <span class="label">Nom du cube</span>
                <input type="text" name="cube[<?= site_h($id) ?>][label]" maxlength="100" value="<?= site_h((string)$slot['label']) ?>" required>
              </label>
              <label>
                <span class="label">Repere court</span>
                <input type="text" name="cube[<?= site_h($id) ?>][number]" maxlength="12" value="<?= site_h((string)$slot['number']) ?>" placeholder="01 ou S1">
              </label>
              <label>
                <span class="label">Type</span>
                <select name="cube[<?= site_h($id) ?>][kind]">
                  <option value="album"<?= $slot['kind'] === 'album' ? ' selected' : '' ?>>Album</option>
                  <option value="session"<?= $slot['kind'] === 'session' ? ' selected' : '' ?>>Session</option>
                </select>
              </label>
              <label>
                <span class="label">Etat</span>
                <select name="cube[<?= site_h($id) ?>][status]">
                  <?php foreach ($statusOptions as $statusKey => $statusLabel): ?>
                    <option value="<?= site_h((string)$statusKey) ?>"<?= $slot['status'] === $statusKey ? ' selected' : '' ?>><?= site_h((string)$statusLabel) ?></option>
                  <?php endforeach; ?>
                </select>
              </label>
              <label>
                <span class="label">Ordre</span>
                <input type="number" name="cube[<?= site_h($id) ?>][position]" min="1" max="99" value="<?= $index + 1 ?>">
              </label>
              <label class="cube-admin-wide">
                <span class="label">Texte affiche apres ouverture</span>
                <textarea name="cube[<?= site_h($id) ?>][description]" rows="3" maxlength="500"><?= site_h((string)$slot['description']) ?></textarea>
              </label>
              <label>
                <span class="label">Texte du lien</span>
                <input type="text" name="cube[<?= site_h($id) ?>][link_label]" maxlength="100" value="<?= site_h((string)$slot['link_label']) ?>">
              </label>
              <label class="cube-admin-link-field">
                <span class="label">Destination du lien</span>
                <input type="text" name="cube[<?= site_h($id) ?>][link_url]" maxlength="240" value="<?= site_h((string)$slot['link_url']) ?>" placeholder="#library-catalogue ou https://...">
              </label>
            </div>
          </article>
        <?php endforeach; ?>
      </div>
    </div>
  </section>

  <div class="form-actions cube-admin-save-actions">
    <button type="submit" class="btn primary" name="action" value="save_cubes">enregistrer le tableau de cubes</button>
  </div>
</form>

<?php $page_content = ob_get_clean(); include __DIR__ . '/../inc/admin_layout.php';
