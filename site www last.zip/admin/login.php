<?php
declare(strict_types=1);
require_once __DIR__ . '/../inc/admin_auth.php';

if (!defined('NETS_ATELIER_ENTRY')) {
  header('Location: ' . site_path('admin_login_path', '/coulisses.php'), true, 302);
  exit;
}

admin_session_start();
$error = null;
if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
  if (!hash_equals($_SESSION['admin_csrf'] ?? '', (string)($_POST['csrf'] ?? ''))) {
    http_response_code(400);
    exit('Bad request');
  }
  if (!admin_login((string)($_POST['username'] ?? ''), (string)($_POST['password'] ?? ''))) {
    $error = 'Identifiants invalides.';
  } else {
    header('Location: ' . site_path('admin_home_path', '/coulisses-espace.php'));
    exit;
  }
}

$title = 'coulisses — entrée — nets-musique.digital';
$admin_current = 'login';
ob_start(); ?>
<div class="login-wrap">
  <div class="login-card">
    <div class="login-logo"><b>nets-musique</b>.digital &nbsp;::&nbsp; coulisses</div>
    <div class="login-title">Entrée privée</div>

    <?php if ($error): ?>
      <div class="login-notice"><?= site_h($error) ?></div>
    <?php endif; ?>

    <form method="post" autocomplete="on">
      <input type="hidden" name="csrf" value="<?= site_h($_SESSION['admin_csrf']) ?>" />
      <label>
        <span class="field-label">Utilisateur</span>
        <input type="text" name="username" autocomplete="username" required autofocus />
      </label>
      <label>
        <span class="field-label">Mot de passe</span>
        <input type="password" name="password" autocomplete="current-password" required />
      </label>
      <button class="btn primary" type="submit">se connecter</button>
    </form>
  </div>
</div>
<?php $page_content = ob_get_clean(); include __DIR__ . '/../inc/admin_layout.php';
