<?php
declare(strict_types=1);

require_once __DIR__ . '/../inc/admin_auth.php';
require_once __DIR__ . '/../inc/content_overrides.php';
require_once __DIR__ . '/../inc/media.php';

if (!defined('NETS_ATELIER_ENTRY')) {
    header('Location: ' . site_path('admin_home_path', '/coulisses-espace.php'), true, 302);
    exit;
}

admin_require_login();

$rawContentPath = __DIR__ . '/../inc/content.php';
$contentDefault = (static function () use ($rawContentPath) {
    include $rawContentPath;
    return $content ?? [];
})();
$defaultTracks = is_array($contentDefault['discovery_tracks'] ?? null)
    ? $contentDefault['discovery_tracks']
    : [];
$defaultTracksById = [];
foreach ($defaultTracks as $defaultTrack) {
    foreach (['id', 'slug'] as $field) {
        $key = strtolower((string)($defaultTrack[$field] ?? ''));
        if ($key !== '') {
            $defaultTracksById[$key] = $defaultTrack;
        }
    }
}

/**
 * Add immutable library metadata and discover audio files already on disk.
 */
$normalizeLibrary = static function (array $tracks) use ($defaultTracksById): array {
    $normalized = [];
    $knownAudio = [];

    foreach ($tracks as $track) {
        if (!is_array($track)) {
            continue;
        }
        $slug = nets_slugify((string)($track['slug'] ?? $track['id'] ?? ''));
        if ($slug === '') {
            continue;
        }
        $kind = (($track['kind'] ?? 'fragment') === 'session') ? 'session' : 'fragment';
        $track['id'] = $slug;
        $track['slug'] = $slug;
        $track['kind'] = $kind;
        if (trim((string)($track['title'] ?? '')) === '' || preg_match('/^(?:FRAGMENT|SESSION)_\d+$/i', (string)$track['title'])) {
            $track['title'] = $kind === 'session' ? 'Session' : 'Morceau';
        }
        $track['active'] = !array_key_exists('active', $track) || (bool)$track['active'];
        $track['locked'] = true;
        $track['library_id'] = (string)($track['library_id'] ?? (
            'legacy-' . substr(hash('sha256', $kind . '|' . $slug), 0, 24)
        ));

        $resolved = nets_track_resolve(array_merge($defaultTracksById[strtolower($slug)] ?? [], $track));
        $audioFile = (string)($resolved['audio_file'] ?? '');
        if (!is_file($audioFile) || strtolower(pathinfo($audioFile, PATHINFO_EXTENSION)) !== 'mp3') {
            $mp3Path = nets_track_paths($slug, $kind)['audio_file'];
            $audioFile = is_file($mp3Path) && strtolower(pathinfo($mp3Path, PATHINFO_EXTENSION)) === 'mp3'
                ? $mp3Path
                : '';
        }
        if ($audioFile === '') {
            // Preserve imported metadata if the file is temporarily unavailable.
            if (!empty($track['audio_rel']) || !empty($track['source_sha256'])) {
                $track['active'] = false;
                $normalized[] = $track;
            }
            continue;
        }

        $relative = nets_project_relative_file($audioFile);
        if ($relative === '') {
            continue;
        }
        $track['audio_rel'] = $relative;
        $knownAudio[strtolower(str_replace('\\', '/', $relative))] = true;
        $track['original_name'] = (string)($track['original_name'] ?? basename($audioFile));
        $track['file_size'] = (int)($track['file_size'] ?? filesize($audioFile));
        $track['audio_extension'] = 'mp3';
        $track['source_sha256'] = (string)($track['source_sha256'] ?? hash_file('sha256', $audioFile));
        @chmod($audioFile, 0444);

        $normalized[] = $track;
    }

    $folders = [
        'fragment' => nets_project_root() . '/media_private/fragments',
        'session' => nets_project_root() . '/media_private/sessions',
    ];
    foreach ($folders as $kind => $folder) {
        if (!is_dir($folder)) {
            continue;
        }
        $entries = scandir($folder);
        if ($entries === false) {
            continue;
        }
        foreach ($entries as $entry) {
            $extension = strtolower(pathinfo($entry, PATHINFO_EXTENSION));
            if ($extension !== 'mp3') {
                continue;
            }
            $file = $folder . DIRECTORY_SEPARATOR . $entry;
            if (!is_file($file)) {
                continue;
            }
            $relative = nets_project_relative_file($file);
            if ($relative === '' || isset($knownAudio[strtolower($relative)])) {
                continue;
            }

            $slug = nets_slugify(pathinfo($entry, PATHINFO_FILENAME));
            if ($slug === '') {
                continue;
            }
            $duplicate = false;
            foreach ($normalized as $track) {
                if (strcasecmp((string)$track['slug'], $slug) === 0) {
                    $duplicate = true;
                    break;
                }
            }
            if ($duplicate) {
                $slug .= '-' . substr(hash('sha256', $relative), 0, 8);
            }

            @chmod($file, 0444);
            $normalized[] = [
                'library_id' => 'legacy-' . substr(hash('sha256', $kind . '|' . $relative), 0, 24),
                'id' => $slug,
                'slug' => $slug,
                'kind' => $kind,
                'session_mode' => 'hybrid',
                'year' => date('Y', (int)filemtime($file)),
                'title' => $kind === 'session' ? 'Session' : 'Morceau',
                'subtitle' => nets_approximate_duration(0, $kind),
                'origin_type' => 'construction',
                'origin_label' => '',
                'cover' => '',
                'support_url' => '',
                'active' => false,
                'locked' => true,
                'audio_rel' => $relative,
                'audio_extension' => $extension,
                'original_name' => $entry,
                'file_size' => (int)filesize($file),
                'source_sha256' => hash_file('sha256', $file),
                'imported_at' => '',
            ];
            $knownAudio[strtolower($relative)] = true;
        }
    }

    return $normalized;
};

$error = null;
$flash = (string)($_SESSION['library_flash'] ?? '');
unset($_SESSION['library_flash']);

$contentLength = (int)($_SERVER['CONTENT_LENGTH'] ?? 0);
$postLimit = nets_ini_bytes((string)ini_get('post_max_size'));
$requestTooLarge = $_SERVER['REQUEST_METHOD'] === 'POST'
    && $_POST === []
    && $contentLength > 0
    && $postLimit > 0
    && $contentLength > $postLimit;

$currentTracks = tracks_read_overrides();
if ($currentTracks === []) {
    $currentTracks = $defaultTracks;
}
$normalizedTracks = $normalizeLibrary($currentTracks);
if (json_encode($normalizedTracks) !== json_encode($currentTracks)) {
    if (tracks_write_overrides($normalizedTracks)) {
        $currentTracks = $normalizedTracks;
    } else {
        $error = 'La migration de la bibliotheque n a pas pu etre enregistree dans /data.';
    }
} else {
    $currentTracks = $normalizedTracks;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($requestTooLarge) {
        $error = 'Le fichier depasse la limite actuelle du serveur : ' . nets_format_bytes($postLimit) . '.';
    } elseif (!hash_equals($_SESSION['admin_csrf'] ?? '', (string)($_POST['csrf'] ?? ''))) {
        http_response_code(400);
        $error = 'Jeton de securite invalide. Recharge la page.';
    } else {
        $action = (string)($_POST['action'] ?? '');

        if ($action === 'import') {
            $result = nets_library_import($_FILES['audio'] ?? [], $_POST, $currentTracks);
            if (!$result['ok']) {
                $error = $result['error'];
            } else {
                $updated = $currentTracks;
                $updated[] = $result['track'];
                if (!tracks_write_overrides($updated)) {
                    nets_library_remove_failed_import((string)($result['path'] ?? ''));
                    $error = 'Le son n a pas ete ajoute : impossible d enregistrer la bibliotheque.';
                } else {
                    $_SESSION['library_flash'] = 'Son importe et verrouille. Il est inactif tant que tu ne l actives pas.';
                    header('Location: ' . site_path('admin_tracks_path', '/coulisses-sons.php'), true, 303);
                    exit;
                }
            }
        } elseif ($action === 'edit') {
            $libraryId = (string)($_POST['library_id'] ?? '');
            $kind = (string)($_POST['kind'] ?? '');
            $found = false;
            if (!in_array($kind, ['fragment', 'session'], true)) {
                $error = 'Choisis Morceau ou Session.';
            } else {
                $newTitle = preg_replace('/\s+/', ' ', trim((string)($_POST['title'] ?? ''))) ?? '';
                $newTitle = nets_text_limit($newTitle !== '' ? $newTitle : ($kind === 'session' ? 'Session' : 'Morceau'), 160);
                foreach ($currentTracks as &$track) {
                    if (hash_equals((string)($track['library_id'] ?? ''), $libraryId)) {
                        // Only presentation changes: audio_rel, slug and checksum stay stable.
                        $track['title'] = $newTitle;
                        $track['kind'] = $kind;
                        $found = true;
                        break;
                    }
                }
                unset($track);
                if (!$found) {
                    $error = 'Ce son n existe pas dans la bibliotheque.';
                } elseif (!tracks_write_overrides($currentTracks)) {
                    $error = 'Les modifications n ont pas pu etre enregistrees.';
                } else {
                    $_SESSION['library_flash'] = 'Titre et type mis à jour.';
                    header('Location: ' . site_path('admin_tracks_path', '/coulisses-sons.php'), true, 303);
                    exit;
                }
            }
        } elseif ($action === 'toggle') {
            $libraryId = (string)($_POST['library_id'] ?? '');
            $makeActive = ((string)($_POST['active'] ?? '0')) === '1';
            $found = false;
            foreach ($currentTracks as &$track) {
                if (hash_equals((string)($track['library_id'] ?? ''), $libraryId)) {
                    if ($makeActive && !is_file((string)(nets_track_resolve($track)['audio_file'] ?? ''))) {
                        $error = 'Le fichier audio est introuvable : activation impossible.';
                        break;
                    }
                    $track['active'] = $makeActive;
                    $track['locked'] = true;
                    $found = true;
                    break;
                }
            }
            unset($track);

            if ($error !== null) {
                // Keep the activation error.
            } elseif (!$found) {
                $error = 'Ce son n existe pas dans la bibliotheque.';
            } elseif (!tracks_write_overrides($currentTracks)) {
                $error = 'Le changement d etat n a pas pu etre enregistre.';
            } else {
                $_SESSION['library_flash'] = $makeActive
                    ? 'Son active sur le site.'
                    : 'Son desactive. Le fichier reste conserve dans la bibliotheque.';
                header('Location: ' . site_path('admin_tracks_path', '/coulisses-sons.php'), true, 303);
                exit;
            }
        } else {
            $error = 'Action inconnue.';
        }
    }
}

$activeCount = count(array_filter($currentTracks, 'nets_track_is_active'));
$uploadLimit = nets_upload_limit_bytes();
$title = 'coulisses - bibliotheque de sons - nets-musique.digital';
$admin_current = 'morceaux';
ob_start();
?>

<div class="page-head">
  <div>
    <div class="crumbs">coulisses <b>/</b> bibliotheque de sons</div>
    <h1>Bibliothèque de sons</h1>
    <p>Un fichier importe est conserve sous un nom interne unique. Il ne peut ensuite etre ni remplace, ni modifie, ni supprime depuis les coulisses.</p>
    <p class="muted muted-spaced">Tu peux modifier le titre et le type, puis <b>activer</b> ou <b>désactiver</b> la présence publique du son.</p>
  </div>
  <div class="ascii-mark" aria-hidden="true">:: audio ::
importe / verrouille</div>
</div>

<?php if ($flash !== ''): ?>
  <div class="notice notice-good"><?= site_h($flash) ?></div>
<?php elseif ($error !== null): ?>
  <div class="notice notice-alert"><?= site_h($error) ?></div>
<?php endif; ?>

<section class="card library-import-card">
  <div class="card-head">
    <h2>Importer un son termine</h2>
    <span class="card-sub">limite actuelle : <?= site_h(nets_format_bytes($uploadLimit)) ?></span>
  </div>
  <div class="card-body">
    <form method="post" enctype="multipart/form-data" class="library-import-form" id="library-import-form">
      <input type="hidden" name="csrf" value="<?= site_h($_SESSION['admin_csrf'] ?? '') ?>">
      <input type="hidden" name="action" value="import">
      <input type="hidden" name="duration_seconds" id="library-duration-seconds" value="">
      <input type="hidden" name="MAX_FILE_SIZE" value="<?= (int)$uploadLimit ?>">

      <div class="field library-file-field">
        <label class="label" for="library-audio">Fichier audio termine</label>
        <input id="library-audio" type="file" name="audio" accept=".mp3,audio/mpeg" required>
        <div class="muted field-help">MP3 uniquement. Le contenu est verifie avant stockage.</div>
      </div>

      <div class="field">
        <label class="label" for="library-kind">Type</label>
        <select id="library-kind" name="kind">
          <option value="fragment">Morceau</option>
          <option value="session">Session</option>
        </select>
      </div>

      <div class="field">
        <label class="label" for="library-title">Titre <span class="muted">(facultatif)</span></label>
        <input id="library-title" type="text" name="title" maxlength="160" placeholder="Morceau ou Session si vide">
      </div>

      <div class="library-import-summary" id="library-import-summary" aria-live="polite">
        Le son sera importe <b>inactif</b>, puis verrouille.
      </div>

      <div class="form-actions">
        <button type="submit" class="btn primary">Importer dans la bibliotheque</button>
      </div>
    </form>
  </div>
</section>

<section class="card library-card">
  <div class="card-head">
    <h2>Sons conserves</h2>
    <span class="card-sub"><?= count($currentTracks) ?> au total / <?= $activeCount ?> actif<?= $activeCount > 1 ? 's' : '' ?></span>
  </div>
  <div class="card-body flush">
    <div class="sound-library">
      <?php if ($currentTracks === []): ?><p class="muted">Aucun son importé. Ajoute un MP3 pour commencer.</p><?php endif; ?>
      <?php foreach ($currentTracks as $track): ?>
        <?php
          $resolved = nets_track_resolve(array_merge(
              $defaultTracksById[strtolower((string)($track['slug'] ?? ''))] ?? [],
              $track
          ));
          $audioFile = (string)($resolved['audio_file'] ?? '');
          $exists = is_file($audioFile);
          $active = nets_track_is_active($track);
          $kind = (($track['kind'] ?? 'fragment') === 'session') ? 'session' : 'fragment';
          $fileSize = (int)($track['file_size'] ?? ($exists ? filesize($audioFile) : 0));
          $importedAt = trim((string)($track['imported_at'] ?? ''));
        ?>
        <article class="library-sound <?= $kind === 'session' ? 'is-session' : 'is-fragment' ?><?= $active ? ' is-active' : ' is-inactive' ?>">
          <div class="library-sound-main">
            <div class="library-sound-title">
              <span class="kind-flag <?= $kind === 'session' ? 'blue' : 'red' ?>">&#9679;</span>
              <strong><?= site_h((string)($track['title'] ?? $track['slug'] ?? 'son')) ?></strong>
              <span class="status-chip <?= $active ? 'status-approved' : 'status-hidden' ?>"><?= $active ? 'actif' : 'inactif' ?></span>
              <span class="library-lock" title="Fichier audio protégé">&#128274; audio protégé</span>
            </div>
            <div class="library-sound-meta">
              <span><?= $kind === 'session' ? 'Session' : 'Morceau' ?></span>
              <span><?= site_h((string)($track['subtitle'] ?? '')) ?></span>
              <span><?= site_h((string)($track['year'] ?? '')) ?></span>
              <span><?= site_h((string)($track['original_name'] ?? basename($audioFile))) ?></span>
              <?php if ($fileSize > 0): ?><span><?= site_h(nets_format_bytes($fileSize)) ?></span><?php endif; ?>
              <?php if ($importedAt !== ''): ?><span>importe le <?= site_h(substr($importedAt, 0, 10)) ?></span><?php endif; ?>
            </div>
            <div class="library-integrity <?= $exists ? 'is-ok' : 'is-missing' ?>">
              <?= $exists ? 'fichier prive present' : 'fichier audio introuvable' ?>
              <?php if (!empty($track['source_sha256'])): ?>
                <code><?= site_h(substr((string)$track['source_sha256'], 0, 16)) ?>...</code>
              <?php endif; ?>
            </div>
          </div>

          <form method="post" class="library-edit-form">
            <input type="hidden" name="csrf" value="<?= site_h($_SESSION['admin_csrf'] ?? '') ?>">
            <input type="hidden" name="action" value="edit">
            <input type="hidden" name="library_id" value="<?= site_h((string)($track['library_id'] ?? '')) ?>">
            <label>Titre <input type="text" name="title" maxlength="160" value="<?= site_h((string)($track['title'] ?? '')) ?>" placeholder="Morceau ou Session si vide"></label>
            <label>Type <select name="kind">
              <option value="fragment"<?= $kind === 'fragment' ? ' selected' : '' ?>>Morceau</option>
              <option value="session"<?= $kind === 'session' ? ' selected' : '' ?>>Session</option>
            </select></label>
            <button type="submit" class="btn ghost">Enregistrer</button>
          </form>
          <form method="post" class="library-toggle-form">
            <input type="hidden" name="csrf" value="<?= site_h($_SESSION['admin_csrf'] ?? '') ?>">
            <input type="hidden" name="action" value="toggle">
            <input type="hidden" name="library_id" value="<?= site_h((string)($track['library_id'] ?? '')) ?>">
            <input type="hidden" name="active" value="<?= $active ? '0' : '1' ?>">
            <button type="submit" class="btn <?= $active ? 'ghost' : 'primary' ?>"<?= !$exists && !$active ? ' disabled' : '' ?>>
              <?= $active ? 'Desactiver' : 'Activer' ?>
            </button>
          </form>
        </article>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<div class="form-actions">
  <a href="/preferences.php" target="_blank" rel="noopener" class="btn ghost">Voir les preferences d'ecoute</a>
</div>

<?php
$page_content = ob_get_clean();
include __DIR__ . '/../inc/admin_layout.php';
