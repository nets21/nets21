<?php
declare(strict_types=1);
require_once __DIR__ . '/../inc/admin_auth.php';
require_once __DIR__ . '/../inc/content_overrides.php';
if (!defined('NETS_ATELIER_ENTRY')) { header('Location: /coulisses.php'); exit; }
admin_require_login();
$groups = json_decode((string)file_get_contents(__DIR__ . '/../data/editor-groups.json'), true) ?: [];
$current = content_read_overrides();
$error = null; $saved = false;
if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
  if (!hash_equals((string)($_SESSION['admin_csrf'] ?? ''), (string)($_POST['csrf'] ?? ''))) {
    http_response_code(400); $error = 'Rechargez la page avant de réessayer.';
  } else {
    $payload = $current;
    foreach ($groups as $fields) foreach ($fields as $key => $label) {
      if (!array_key_exists($key, $_POST)) continue;
      $value = trim(str_replace(["\r\n", "\r"], "\n", (string)$_POST[$key]));
      if ($key === 'card_payment_url' && $value !== '' && !preg_match('~^https://buy\.stripe\.com/[A-Za-z0-9_/-]+$~D', $value)) {
        $error = 'Le lien de paiement doit commencer par https://buy.stripe.com/.'; break 2;
      }
      $payload[$key] = is_array($content[$key] ?? null)
        ? ($value === '' ? [] : preg_split('/\n[ \t]*\n/', $value))
        : $value;
    }
    if ($error === null) {
      if (content_write_overrides($payload)) { $current = $payload; $saved = true; }
      else $error = 'Les textes n’ont pas pu être enregistrés. Vérifiez les permissions du dossier data.';
    }
  }
}
$title = 'Coulisses — textes du site'; $admin_current = 'textes';
ob_start(); ?>
<div class="page-head"><div><h1>Textes du site</h1><p>Les textes sont regroupés par page. Séparez les paragraphes par une ligne vide. Vous pouvez vider un champ pour retirer son contenu.</p><p>Le lien Stripe affiche le bouton par carte uniquement lorsqu’il est renseigné. Configurez le paiement ponctuel dans Stripe. Les titres, descriptions et liens des cubes se modifient dans « Cubes ».</p></div></div>
<?php if ($saved): ?><div class="notice notice-good">Textes enregistrés.</div><?php endif; ?>
<?php if ($error): ?><div class="notice notice-alert"><?= site_h($error) ?></div><?php endif; ?>
<form method="post" class="editor-form">
<input type="hidden" name="csrf" value="<?= site_h($_SESSION['admin_csrf'] ?? '') ?>">
<?php foreach ($groups as $group => $fields): ?>
<details class="card" <?= $group !== 'Autres textes existants' ? 'open' : '' ?>><summary class="card-head"><?= site_h($group) ?></summary><div class="card-body">
<?php foreach ($fields as $key => $label):
$value = $current[$key] ?? $content[$key] ?? '';
$text = is_array($value) ? implode("\n\n", $value) : (string)$value;
?>
<div class="field"><label class="label" for="field-<?= site_h($key) ?>"><?= site_h($label) ?></label>
<textarea id="field-<?= site_h($key) ?>" name="<?= site_h($key) ?>" rows="<?= min(22, max(3, substr_count($text, "\n") + 3)) ?>"><?= site_h($text) ?></textarea></div>
<?php endforeach; ?></div></details>
<?php endforeach; ?>
<div class="form-actions"><button class="btn primary" type="submit">Enregistrer les textes</button><a class="btn ghost" href="/" target="_blank" rel="noopener">Voir le site</a></div></form>
<?php $page_content = ob_get_clean(); include __DIR__ . '/../inc/admin_layout.php';
