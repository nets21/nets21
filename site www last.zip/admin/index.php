<?php
declare(strict_types=1);
require_once __DIR__ . '/../inc/admin_auth.php';
require_once __DIR__ . '/../inc/db.php';
require_once __DIR__ . '/../inc/visits.php';

if (!defined('NETS_ATELIER_ENTRY')) {
  header('Location: ' . site_path('admin_home_path', '/coulisses-espace.php'), true, 302);
  exit;
}

admin_require_login();

$title = 'coulisses — tableau de bord — nets-musique.digital';
$admin_current = 'dashboard';

$stats = admin_guestbook_stats();
$visit_stats = site_visits_stats();

// Activité récente (5 derniers événements sur les présences)
$store = guestbook_read_store();
$events = [];
foreach ($store['entries'] as $e) {
  if (!empty($e['created_at']))  { $events[] = ['t' => (int)$e['created_at'],  'kind' => 'posted',   'entry' => $e]; }
  if (!empty($e['approved_at'])) { $events[] = ['t' => (int)$e['approved_at'], 'kind' => 'approved', 'entry' => $e]; }
  if (!empty($e['replied_at']))  { $events[] = ['t' => (int)$e['replied_at'],  'kind' => 'replied',  'entry' => $e]; }
}
usort($events, static fn($a, $b) => $b['t'] <=> $a['t']);
$events = array_slice($events, 0, 6);

function admin_time_ago(int $t): string {
  if ($t <= 0) return '—';
  $d = time() - $t;
  if ($d < 60) return 'à l’instant';
  if ($d < 3600) return 'il y a ' . (int)floor($d/60) . ' min';
  if ($d < 86400) return 'il y a ' . (int)floor($d/3600) . ' h';
  if ($d < 86400*7) return 'il y a ' . (int)floor($d/86400) . ' j';
  return date('Y-m-d', $t);
}

function admin_event_label(string $kind): string {
  return match ($kind) {
    'posted'   => 'nouveau message',
    'approved' => 'publié',
    'replied'  => 'réponse',
    default    => $kind,
  };
}

$path_home     = site_path('admin_home_path', '/coulisses-espace.php');
$path_gb       = site_path('admin_guestbook_path', '/coulisses-presences.php');
$path_logout   = site_path('admin_logout_path', '/coulisses-sortie.php');
$path_textes   = site_path('admin_texts_path', '/coulisses-textes.php');
$path_cubes    = site_path('admin_cubes_path', '/coulisses-cubes.php');
$path_notes    = site_path('admin_notes_path', '/coulisses-notes.php');

$guestbook_file = __DIR__ . '/../data/guestbook.json';
$gb_size = is_file($guestbook_file) ? filesize($guestbook_file) : 0;
$gb_mtime = is_file($guestbook_file) ? filemtime($guestbook_file) : 0;

ob_start(); ?>
<div class="page-head">
  <div>
    <div class="crumbs">coulisses <b>/</b> tableau de bord</div>
    <h1>Coulisses du site</h1>
  </div>
</div>

<section class="kpi-grid">
  <div class="kpi is-good">
    <div class="kpi-label">Visites</div>
    <div class="kpi-value"><?= number_format((int)$visit_stats['total'], 0, ',', ' ') ?></div>
    <div class="kpi-trend"><?= (int)$visit_stats['today'] ?> aujourd'hui &middot; <?= (int)$visit_stats['last_7_days'] ?> sur 7 jours</div>
  </div>
  <div class="kpi<?= $stats['pending'] > 0 ? ' is-alert' : ' is-good' ?>">
    <div class="kpi-label">En attente</div>
    <div class="kpi-value"><?= (int)$stats['pending'] ?> <small>message<?= $stats['pending'] > 1 ? 's' : '' ?></small></div>
    <div class="kpi-trend"><?= $stats['pending'] > 0 ? 'à modérer dès que possible' : 'boîte de modération vide' ?></div>
  </div>
  <div class="kpi is-good">
    <div class="kpi-label">Publiés</div>
    <div class="kpi-value"><?= (int)$stats['approved'] ?></div>
    <div class="kpi-trend"><?= (int)$stats['replied'] ?> avec une réponse du site</div>
  </div>
  <div class="kpi">
    <div class="kpi-label">Total</div>
    <div class="kpi-value"><?= (int)$stats['total'] ?></div>
    <div class="kpi-trend">présences publiées</div>
  </div>
  <div class="kpi">
    <div class="kpi-label">Dernière activité</div>
    <div class="kpi-value"><?= $stats['last_mod'] ? site_h(admin_time_ago($stats['last_mod'])) : '—' ?></div>
    <div class="kpi-trend">
      <?php if ($gb_mtime): ?>
        guestbook.json · <?= number_format($gb_size/1024, 1, ',', ' ') ?> Ko
      <?php else: ?>
        aucune donnée encore
      <?php endif; ?>
    </div>
  </div>
</section>

<section class="card visits-card">
  <div class="card-head">
    <h2>Visites par page</h2>
    <span class="card-sub">depuis toujours</span>
  </div>
  <div class="card-body flush">
    <?php if (empty($visit_stats['pages'])): ?>
      <div class="empty"><div class="big">0</div>aucune visite enregistrée pour l’instant</div>
    <?php else: ?>
      <div class="activity">
        <?php foreach ($visit_stats['pages'] as $visit_path => $visit_count): ?>
          <div class="activity-row visit-page-row">
            <span class="when"><?= number_format((int)$visit_count, 0, ',', ' ') ?></span>
            <span class="what"><a href="<?= site_h((string)$visit_path) ?>" target="_blank" rel="noopener"><?= site_h((string)$visit_path) ?></a></span>
            <span class="tag">depuis toujours</span>
          </div>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </div>
</section>

<section class="two-col">
  <div class="card">
    <div class="card-head">
      <h2>Activité récente</h2>
      <span class="card-sub">6 derniers événements</span>
      <div class="card-head-actions">
        <a href="<?= site_h($path_gb) ?>" class="btn small ghost">ouvrir les présences</a>
      </div>
    </div>
    <div class="card-body flush">
      <?php if (!$events): ?>
        <div class="empty"><div class="big">∅</div>aucune activité pour l’instant</div>
      <?php else: ?>
        <div class="activity">
          <?php foreach ($events as $ev):
            $e = $ev['entry']; $kind = $ev['kind']; ?>
            <div class="activity-row">
              <span class="when"><?= site_h(admin_time_ago($ev['t'])) ?></span>
              <span class="what">
                <?php if ($kind === 'posted'): ?>
                  <b><?= site_h((string)$e['name']) ?></b> a laissé un message — <i>« <?= site_h(mb_substr((string)$e['body'], 0, 70)) ?><?= mb_strlen((string)$e['body']) > 70 ? '…' : '' ?> »</i>
                <?php elseif ($kind === 'approved'): ?>
                  Message <b>#<?= (int)$e['id'] ?></b> de <?= site_h((string)$e['name']) ?> publié
                <?php else: ?>
                  Réponse enregistrée à <b>#<?= (int)$e['id'] ?> <?= site_h((string)$e['name']) ?></b>
                <?php endif; ?>
              </span>
              <span class="tag"><?= site_h(admin_event_label($kind)) ?></span>
            </div>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    </div>
  </div>

  <div class="card">
    <div class="card-head"><h2>Raccourcis</h2></div>
    <div class="card-body">
      <div class="quick-links">
        <a href="<?= site_h($path_cubes) ?>"><span class="qk-label">Renommer les cubes</span><span class="qk-path">noms / ordre / contenu</span></a>
        <a href="<?= site_h($path_notes) ?>"><span class="qk-label">Ouvrir le pense-bête</span><span class="qk-path">directions / notes privées</span></a>
        <a href="<?= site_h($path_textes) ?>"><span class="qk-label">Gérer le signal doux</span><span class="qk-path">Signal doux / textes</span></a>
        <a href="<?= site_h($path_gb) ?>"><span class="qk-label">Relire les présences</span><span class="qk-path"><?= site_h($path_gb) ?></span></a>
        <a href="/" target="_blank" rel="noopener"><span class="qk-label">Aperçu visiteur — accueil</span><span class="qk-path">/</span></a>
        <a href="/chat.php" target="_blank" rel="noopener"><span class="qk-label">Aperçu visiteur — présences</span><span class="qk-path">/chat.php</span></a>
      </div>
    </div>
  </div>
</section>

<?php $page_content = ob_get_clean(); include __DIR__ . '/../inc/admin_layout.php';
