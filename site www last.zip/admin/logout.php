<?php
declare(strict_types=1);
require_once __DIR__ . '/../inc/admin_auth.php';

if (!defined('NETS_ATELIER_ENTRY')) {
  header('Location: ' . site_path('admin_logout_path', '/coulisses-sortie.php'), true, 302);
  exit;
}

admin_logout();
header('Location: ' . site_path('admin_login_path', '/coulisses.php'));
exit;
