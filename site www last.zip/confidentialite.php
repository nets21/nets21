<?php
declare(strict_types=1);
require_once __DIR__ . '/inc/site.php';
$title = $site['brand_main'] . ' :: confidentialite';
ob_start(); ?>

<div class="panel">
  <div class="kicker">Confiance</div>
  <h1><?= site_h($content['privacy_title'] ?? 'Confidentialité sobre') ?></h1>
  <p class="lede"><?= site_h($content['privacy_intro'] ?? '') ?></p>
</div>

<div class="panel subtle">
  <h2>Ce que le site garde</h2>
  <ul class="info-list">
    <?php foreach (($content['privacy_lines'] ?? []) as $line): ?>
      <li><?= site_h($line) ?></li>
    <?php endforeach; ?>
  </ul>
</div>

<div class="panel subtle">
  <h2>Contact volontaire</h2>
  <div class="prose">
    <p>Si un échange doit exister, il commence par un geste volontaire : écrire un e-mail, laisser une présence, ou passer plus tard par une porte clairement nommée.</p>
    <p>Le site peut rester silencieux tant qu’aucun contact n’a de sens.</p>
  </div>
  <div class="cta">
    <a class="btn" href="/preferences.php">Retour aux préférences d’écoute</a>
    <a class="btn ghost" href="/chat.php">Écrire via le site</a>
  </div>
</div>

<?php $page_content = ob_get_clean(); include __DIR__ . '/inc/layout.php';
