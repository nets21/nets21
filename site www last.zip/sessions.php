<?php
declare(strict_types=1);
require_once __DIR__ . '/inc/site.php';
require_once __DIR__ . '/inc/media.php';
$title = $site['brand_main'] . ' :: sessions';
ob_start(); ?>

<div class="panel hero-panel tone-blue">
  <div class="portal-mini">
    <span class="portal-dot blue">●</span><span>sessions</span>
    <span class="portal-sep">//</span>
    <span class="portal-dot red">●</span><span>fragments</span>
    <span class="portal-sep">//</span>
    <span class="portal-name"><?= site_h($content['brand_poetic']) ?></span>
  </div>
  <h1>Sessions</h1>
  <p class="lede">Des performances longues construites avec Ableton.</p>
</div>

<div class="panel tone-blue">
  <h2>Écouter les sessions</h2>
  <div class="prose">
    <?php foreach (($content['sessions_intro_lines'] ?? []) as $line): ?>
      <p><?= site_h($line) ?></p>
    <?php endforeach; ?>
  </div>

  <div class="notice">
    <strong>Ecoute sur le site</strong> : la forme reste entiere dans le lecteur. Pas de telechargement public ; les envois plus directs se decident plus tard, au cas par cas.
  </div>

  <?php if (empty($content['sessions'])): ?>
    <div class="notice">
      <strong>Aucune session publiée pour le moment.</strong>
      Vous pouvez découvrir les fragments en attendant.
    </div>
  <?php else: ?>
    <div class="list">
      <?php foreach ($content['sessions'] as $item): ?>
      <?php $full = site_find_track((string)$item['id']); ?>
      <?php $_ots = $full ? track_opentimestamps_url($full) : ''; ?>
      <?php $_sessionMode = (($item['session_mode'] ?? 'hybrid') === 'ableton') ? 'Ableton seul' : 'session hybride'; ?>
      <div class="row">
        <img class="track-cover-thumb" src="<?= site_h(track_cover_url($full ?: $item)) ?>" alt="" loading="lazy">
        <div class="when"><?= site_h($item['year']) ?></div>
        <div class="what">
          <div class="title"><?= site_h($item['title']) ?></div>
          <div class="track-mode"><?= site_h($_sessionMode) ?></div>
          <div class="sub"><?= site_h($item['subtitle']) ?></div>
        </div>
        <div class="actions">
          <button type="button" class="btn small js-track" data-track-id="<?= site_h($item['id']) ?>">ecouter</button>
          <?php if ($_ots !== ''): ?>
            <a class="proof-link" href="/preuves.php#<?= site_h($full['slug'] ?? $item['id']) ?>">[ preuve de date ]</a>
          <?php endif; ?>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>

  <div class="cta">
    <a class="btn" href="/listen.php">Ecoute & soutien</a>
    <a class="btn ghost" href="/fragments.php">Voir aussi les morceaux rouges</a>
  </div>
</div>

<?php $page_content = ob_get_clean(); include __DIR__ . '/inc/layout.php';
